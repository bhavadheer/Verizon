﻿function stsDropdown() {
    jQuery('.vzbs-dropdown').each(function (index, value) {

        //gets number of elements to fix the overflow
        var len = jQuery(this).find(jQuery('.dropdown-menu li')).length;

        if (len > 8) {
            jQuery(this).find('.dropdown-menu').addClass('adjust-block');
        }

        //takes cares of user selections
        jQuery('.vzbs-dropdown').eq(index).find(jQuery('.dropdown-menu li')).bind('click', function () {
            //removes selected globally and applies selected on list item click
            jQuery(this).parent().find(jQuery('li')).removeClass('selected');
            jQuery(this).addClass('selected');

            //getting span
            var cache = jQuery(this).parent().prev().children('span');

            //displays value on button
            jQuery(this).parent().prev().text(jQuery(this).text()).append(cache);

            //updates value on input field
            jQuery(this).parent().prev().prev('input[type="hidden"]').val(jQuery(this).data('id'));
            jQuery(this).parent().prev().prev('input[type="hidden"]').trigger('change');
        });
    });
}

function stsDropdownMul() {
    jQuery('.vzbs-dropdown').each(function (index, value) {

        //gets number of elements to fix the overflow
        var len = jQuery(this).find(jQuery('.dropdown-menu li')).length;

        if (len > 8) {
            jQuery(this).find('.dropdown-menu').addClass('adjust-block');
        }

        //takes cares of user selections
        jQuery('.vzbs-dropdown').eq(index).find(jQuery('.mulSelect')).bind('click', function () {
            //removes selected globally and applies selected on list item click
            jQuery(this).parent().find(jQuery('li')).removeClass('selected');
            jQuery(this).addClass('selected');

            //getting span
            var cache = jQuery(this).parent().prev().children('span');

            //displays value on button
            jQuery(this).parent().prev().text(jQuery(this).text()).append(cache);

            //updates value on input field
            jQuery(this).parent().prev().prev('input[type="hidden"]').val(jQuery(this).data('value'));
            jQuery(this).parent().prev().prev('input[type="hidden"]').trigger('change');
        });
    });
}

function StringtoInt(string) {
    switch (string.toLowerCase().trim()) {
        case "true": case "yes": return 1;
        case "false": case "no": case null: return 0;
        default: return 0;
    }
}

function formatJSONDate(jsonDate, formatType) {
    //formatType = formatType || 'datetime';
    var parsedDate = moment(jsonDate);
    var formattedDate;
    if (formatType == '') {
        formattedDate = parsedDate.format('DD/MM/YYYY hh:mm:ss A');
    }
    else {
        formattedDate = parsedDate.format('DD/MM/YYYY');
    }

    return formattedDate;
}