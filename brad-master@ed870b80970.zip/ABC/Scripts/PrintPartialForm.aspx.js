﻿$(document).ready(function () {
    LoadDropdown('ulForm', 'rdpFormType');
    $('#btnLoadSection').click(function () {
        var formId = $('#hdnForm').val();
        var sectionId = $('#hdnSection').val();
        var formInstance = $('#txtFormInstance').val();
        if (formId != '' && sectionId != '' && formInstance != '') {
            LoadFormPrint(formId, sectionId, formInstance);
        }
        else {
            alert("Please select Form, Section and Form Instance to load.");
        }
    });

    $('#btnClear').click(function () {
        //$("#ulForm").empty();
        //$('#hdnForm').val('');
        //$("#ulSection").empty();
        //$('#hdnSection').val('');
        //LoadDropdown('ulForm', 'rdpFormType');
        //$('#formText').html('Select <span class="vzcaret"></span>');
        //$('#Sectiontext').html('Select <span class="vzcaret"></span>');
        //$('#txtFormInstance').val('');
        //$('#loadFrame').empty();
        var url = window.location.href;
        if (url.indexOf('#') == url.length - 1) {
            url = url.substring(0, url.length - 1);
        }
        window.location.href = url;
    });
});

function LoadDropdown(uList, dropdownType) {

    var jsonText = '';
    //var stsId = $('#MainContent_hiLoggedInStsId').val();
    if (dropdownType != '') {
        jsonText = JSON.stringify({ ddType: dropdownType });
    }
    else {
        jsonText = {};
    }
    $.ajax({
        type: "POST",
        url: "PrintPartialForm.aspx/LoadComboBox",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            var teams = eval('(' + r.d + ')');
            var listItems = "";
            $('#' + uList).empty();
            for (var index = 0; index < teams.length; index++) {
                listItems = '<li data-id=\'' + teams[index].FormID + '\'><a onclick="LoadSectionDropdown(\'ulSection\',' + teams[index].FormID + ')" href=\'#\'>' + teams[index].Name + '</a></li>';
                $('#' + uList).append(listItems);
                listItems = "";
            }
            stsDropdown();
        },
        complete: function (r) {
        }
    });
}

function LoadSectionDropdown(uList, dropdownType) {
    var jsonText = '';
    var stsId = $('#MainContent_hiLoggedInStsId').val();
    if (dropdownType != '') {
        jsonText = JSON.stringify({ ddType: dropdownType, stsId: stsId });
    }
    else {
        jsonText = {};
    }
    $.ajax({
        type: "POST",
        url: "PrintPartialForm.aspx/LoadComboBox",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            var teams = eval('(' + r.d + ')');
            var listItems = "";
            $('#' + uList).empty();
            for (var index = 0; index < teams.length; index++) {
                listItems = '<li data-id=\'' + teams[index].SectionId + '\'><a href=\'#\'>' + teams[index].SectionDescription + '</a></li>';
                $('#' + uList).append(listItems);
                listItems = "";
            }
            stsDropdown();
        },
        complete: function (r) {
        }
    });
}

function LoadFormPrint(formId, sectionId, formInstance) {
    $('#loadFrame').load('DummyPage.aspx?FormId=' + formId + '&SectionId=' + sectionId + '&formInstance=' + formInstance);
}