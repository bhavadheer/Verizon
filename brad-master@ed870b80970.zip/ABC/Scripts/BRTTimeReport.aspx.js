﻿$(document).ready(function () {
    $(".loader").hide();
    LoadDropdownCategories('ulBusinessRel', 'BusinessRelationship');
    LoadReport('quesTable');

    $('#aFilter').click(function () {
        LoadReport('quesTable');
    });
    $('#aClear').click(function () {
        $('#txtFormInstance').val("");
        LoadReport('quesTable');
    });
});

//$(window).load(function () {
//    $(".loader").fadeOut(10000);
//});


function LoadReport(datatableId) {
    $(".loader").show();
    var stsId = $('#MainContent_hiLoggedInStsId').val();
    var forminstance = $('#txtFormInstance').val();
    var businessRel = $('#BusinessRelText').text().trim();
    if (businessRel == "Select") {
        businessRel = "";
    }
    var jsonText = JSON.stringify({
        businessRel: businessRel,
        formInstance: forminstance
    });

    $.ajax({
        type: "POST",
        url: "BRTTimeReport.aspx/LoadReport",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            var table = "";
            var $tableId = $('#' + datatableId);

            if (r == "none") {

                $tableId.bootstrapTable('destroy');
                table = "<tr style='font-weight: bold'><td>No records</td></tr>"
                $("#" + datatableId).html(table);
                $("#" + datatableId).children("tbody").css("text-align", 'center');
                $("#" + datatableId).addClass("table table-hover");

            } else {
                $('#aExport').show();
                $('#aExport').attr("href", "../Helper/ExcelHandler.ashx?criteria=" + businessRel + "&formInstance=" + forminstance + "&exportType=BRTTimeReport");
                $("#" + datatableId).children("tbody").css("text-align", 'left');
                var dataSource = eval(r.d);
                $($tableId).hide();
                $tableId.bootstrapTable('destroy');
                $tableId.bootstrapTable({
                    method: 'get',
                    columns: [
                            {
                                field: 'FormInstance', title: 'Form Instance', width: 1, align: 'center', sortable: true, formatter: function (value, row, index) {
                                    if (value == null || value == "") {
                                        return ['<span>N/A</span>']
                                    }
                                    return ['<span>' + value
                                        + '</span>'];
                                }
                            },
                            {
                                field: 'SectionName', title: 'Section Name', align: 'center', sortable: true, width: 1, formatter: function (value, row, index) {
                                    if (value == null || value == "") {
                                        return ['<span>0</span>']
                                    }
                                    else {
                                        return ['<span>' + value
                                        + '</span>'];
                                    }

                                }
                            },
                            {
                                field: 'QuestionText', title: 'Question Text', align: 'left', sortable: true, formatter: function (value, row, index) {
                                    if (value == null || value == "") {
                                        return ['<span>N/A</span>']
                                    }
                                    else {
                                        return ['<span>' + value
                                            + '</span>'];
                                    }
                                }
                            },
                            {
                                field: 'oldvalue', title: 'Old Value', align: 'left', sortable: true, formatter: function (value, row, index) {
                                    if (value == null || value == "") {
                                        return ['<span></span>']
                                    }
                                    else {
                                        return ['<span>' + value
                                            + '</span>'];
                                    }
                                }
                            },
                            {
                                field: 'newvalue', title: 'New Value', width: 500, align: 'left', sortable: true, formatter: function (value, row, index) {
                                    if (value == null || value == "") {
                                        return ['<span></span>']
                                    }
                                    else {
                                        return ['<span>' + value
                                            + '</span>'];
                                    }
                                }
                            },
                            {
                                field: 'actionbyStsId', title: 'Action By', align: 'left', sortable: true, formatter: function (value, row, index) {
                                    if (value == null || value == "") {
                                        return ['<span>N/A</span>']
                                    }
                                    else {
                                        return ['<span>' + value
                                            + '</span>'];
                                    }
                                }
                            },
                            {
                                field: 'actiondate', title: 'Action Date', align: 'left', sortable: true, formatter: function (value, row, index) {
                                    if (value == null || value == "") {
                                        return ['<span>N/A</span>']
                                    }
                                    else {
                                        return ['<span>' + formatJSONDate(value, '')
                                            + '</span>'];
                                    }
                                }
                            },
                    ],
                    onSort: function (name, order) {

                    },

                    data: dataSource,
                    cache: false,
                    //height: 400,
                    pagination: true,
                    pageSize: 100,
                    pageList: [100, 200, 300],
                    search: false,
                    showColumns: false,
                    showRefresh: false,
                    minimumCountColumns: 2,
                });
                $($tableId).fadeIn();
            }
        },
        complete: function (r) {
            $(".loader").hide();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            var jsonResponse = JSON.parse(jqXHR.responseText);
            alert('Internal error occurred [' + jsonResponse.d + ']\n Please try again!');
        }
    });
}

function LoadDropdownCategories(uList, category) {
    var jsonText = '';
    jsonText = JSON.stringify({ ddType: category });
    $.ajax({
        type: "POST",
        url: "BRTTimeReport.aspx/LoadComboBox",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            var teams = eval('(' + r.d + ')');
            var listItems = "";
            $('#' + uList).empty();
            for (var index = 0; index < teams.length; index++) {
                listItems = '<li data-id=\'' + teams[index].DDId + '\'><a href=\'#\'>' + teams[index].DisplayValue + '</li>';
                $('#' + uList).append(listItems);
                listItems = "";
            }
            stsDropdown();
        },
        complete: function (r) {
        }
    });
}