//
//  Global scripts Initialization
// -------------------------------------------------- 
jQuery(document).ready(function($) {

    // -------------------------
    // Global Menu
    // -------------------------
    $('.navbar .dropdown').each(function() {
        $(this).mouseover(function() {
            $('body').addClass('vzbs-menu-overflow')
        });
        $(this).mouseout(function() {
            $('body').removeClass('vzbs-menu-overflow');
        });
    });

    // -------------------------
    // Mobile devices being targetted
    // -------------------------
    var windowWidth = $(document).width();
    if(windowWidth <= 767){

        /* Mobile - Global Menu Toggle */
        $('.navbar .dropdown > a').each(function() {
            $(this).on('click touch', function (e) {
                e.preventDefault();
                if  ($(this).parent().hasClass("mobile-expanded")){
                    $(this).parent().removeClass("mobile-expanded");
                }
                else{
                    $('.navbar .dropdown').removeClass('mobile-expanded');
                    $(this).parent().addClass('mobile-expanded');    
                }
            });
        });

        /* Mobile - Help and Feedback tabs*/
        var HFelm = jQuery('#help-feedback');
        if(HFelm.length === 1){
            HFelm.hide();
            HFelm.clone().appendTo('body > div.container').addClass('mobile-help-feedback');
        }

    }

    // -------------------------
    // Global Header - Logo alignments for multiple scenarios
    // -------------------------
    var appName = $('#vz-app-name');
    if (appName.length == 0)
        $('.navbar-header .navbar-brand').show();

    var navbarToggle = $('.navbar-header .navbar-toggle');
    if (navbarToggle.length == 0)
        $('.navbar-header .navbar-brand').css('margin', '0px');

    // -------------------------
    // Tree Menu
    // -------------------------

    $('.tree-toggler').click(function(e) {
        e.preventDefault();
        $(this).parent().parent().children('.tree.stem').toggle();
        $("span", this).toggleClass("fa-plus fa-minus");
    });

    // -------------------------
    // Tooltip
    // -------------------------

    $('[data-toggle="tooltip"]').tooltip();

    //modal
    $('.modal').on('shown.bs.modal', function(e) {
        $('.modal-body').scrollTop(0);
    });

    // -------------------------
    // Timepicker
    // -------------------------
    $('.timepicker input').each(function() {
        $(this).click(function() {
            $(this).timepicker('showWidget')
        });
    });

    //data-placeholder fields
    $('input.data-placeholder').each(function() {
        $(this).parent('.form-group').css('position', 'relative')
        $(this).attr('placeholder', $(this).attr('data-placeholder'));
        $(this).after("<span class='placeholder-label hidden' >" + $(this).attr('placeholder') + "</span>");
        $(this).keyup(function() {
            if ($(this).val() != '') $(this).next().removeClass('hidden');
            else $(this).next().addClass('hidden');
        });
    });

    //just in case, user refreshes page.
    $('input.data-placeholder').keyup();

    //**************radio-checkboxes*****************--

    $('.vzbs-checkbox label > input').each(function() {
        $(this).hover().parent('label').toggleClass('vzbs-checkbox-hovered-label');
        $(this).click(function() {
            $(this).parent('label').toggleClass('vzbs-checkbox-checked-label');
        });

    });

    $('.vzbs-radio label > input').each(function() {
        $(this).hover().parent('label').toggleClass('vzbs-radio-hovered-label');
        $(this).click(function() {
            $(this).parent('label').toggleClass('vzbs-radio-checked-label');
        });

    });



    /* Wizard Tabs */
    $('a[data-toggle="tab"]').on('show.bs.tab', function (e) {
      var $target = $(e.target);
      if ($target.parent().hasClass('disabled')) {
        return false;
      }
    });
    $(".next-step").click(function (e) {
      var $active = $('.wizard .nav-tabs li.active');
      $active.next().removeClass('disabled');
      nextTab($active);
    });
    $(".prev-step").click(function (e) {
        var $active = $('.wizard .nav-tabs li.active');
        prevTab($active);
    });

    function nextTab(elem) {
        $(elem).next().find('a[data-toggle="tab"]').click();
    }
    function prevTab(elem) {
     $(elem).prev().find('a[data-toggle="tab"]').click();
    }


    /*  List - Grid View toggle */
    $('#vzbs-list-view').click(function(event) {
        event.preventDefault();
        $('#vzbs-list-grid-view .list-item').removeClass('grid-group-item');
        $('#vzbs-list-grid-view .list-item').addClass('list-group-item');
    });
    $('#vzbs-grid-view').click(function(event) {
        event.preventDefault();
        $('#vzbs-list-grid-view .list-item').removeClass('list-group-item');
        $('#vzbs-list-grid-view .list-item').addClass('grid-group-item');
    });

    /* Scroll to Top */
    if ($('#vzbs-toTop').length != 0){
        $(window).scroll(function () {
            console.log('backtotop');
            if ($(this).scrollTop() != 0) {
                $('#vzbs-toTop').fadeIn();
            } else {
                $('#vzbs-toTop').fadeOut();
            }
        }); 
        $('#vzbs-toTop').click(function(){
            $("html, body").animate({ scrollTop: 0 }, 600);
            return false;
        });
    }

}); //document.ready close

//-------------------
//  vzdropdown
//-------------------

function vzbsDropdown() {
     jQuery('.vzbs-dropdown').each(function(index, value) {
        //gets number of elements to fix the overflow
        var len = jQuery(this).find(jQuery('.dropdown-menu li')).length;
        if (len > 8) {
            jQuery(this).find('.dropdown-menu').addClass('adjust-block');
        }
        //takes cares of user selections

        var list = jQuery('.vzbs-dropdown .dropdown-menu li');
        jQuery(list).each(function(){
            jQuery(this).on('touchstart, click', function(){
                jQuery(this).parent().find(jQuery('li')).removeClass();
                jQuery(this).addClass('selected');
                var selectedText = jQuery(this).text();
                jQuery(this).parent().parent().children('button').html(selectedText).append('<span class="vzcaret"></span>');
                jQuery(this).parents('input[type="hidden"]').val(selectedText);
            });
        })
    });
}