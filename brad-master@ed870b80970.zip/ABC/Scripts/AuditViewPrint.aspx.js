﻿$(document).ready(function () {
    $(".txtFromDate").datepicker({
        format: 'dd/mm/yyyy',
        minDate: new Date()
    });

    $('#txtFromDate')
        .datepicker({
            format: 'dd/mm/yyyy',
            minDate: new Date()
        })
        .on('changeDate', function (ev) {
            $('#txtFromDate').datepicker('hide');
        });

    $('#txtFromDate')
        .datepicker({
            format: 'dd/mm/yyyy',
            minDate: new Date()
        })
        .on('click', function (ev) {
            $('#txtFromDate').datepicker('show');
        });

    $(".txtToDate").datepicker({
        format: 'dd/mm/yyyy',
        minDate: new Date()
    });

    $('#txtToDate')
        .datepicker({
            format: 'dd/mm/yyyy',
            minDate: new Date()
        })
        .on('changeDate', function (ev) {
            $('#txtToDate').datepicker('hide');
        });

    $('#txtToDate')
        .datepicker({
            format: 'dd/mm/yyyy',
            minDate: new Date()
        })
        .on('click', function (ev) {
            $('#txtToDate').datepicker('show');
        });

    $(".loader").hide();
    //LoadFormGrid('formTable');
    $('#btnExport').hide();
    $('#btnSearch').click(function () {
        LoadFormGrid('formTable');
    });
    $('#btnClear').click(function () {
        $('#txtFromDate').val('');
        $('#txtToDate').val('');
    });
});

function LoadDetails(td, formInstance) {
    var table = $('#formTable');
    var tr = $(td).closest('tr');

    if (tr.hasClass('shown')) {
        // This row is already open - close it
        tr.remove("test");
        $('.test').remove();
        tr.removeClass('shown');
    }
    else {
        // Open this row
        format(formInstance, tr);
        tr.addClass('shown');
    }
}

function format(d, maintr) {
    var resultText = '';
    var jsonText = '';
    jsonText = JSON.stringify({ formInstance: d });
    $.ajax({
        type: "POST",
        url: "AuditViewPrint.aspx/GetAuditViewPrint",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            if (r.d != "") {
                var rr = eval(r.d);
                resultText += '<table class="table table-hover table-striped">';
                resultText += ' <thead><tr><th>User Name</th><th>Action</th><th>Action Date</th></tr></thead>';
                for (var f = 0; f < rr.length; f++) {
                    var tr = '<tr><td>' + rr[f]['LoggedInUser'] + '</td><td>' + rr[f]['Event'] + '</td><td>' + formatJSONDate(rr[f]['EventDateTime'], '') + '</td></tr>';
                    resultText += tr;
                };
                resultText += '</table>';
                maintr.after('<tr class="test"><td colspan="6">' + resultText + '</td></tr>');
            }
        },
        complete: function (r) {
        }
    });
}

function LoadFormGrid(datatableId) {
    var fromDate = $('#txtFromDate').val();
    var toDate = $('#txtToDate').val();
    if (fromDate != '' && toDate != '') {
        var jsonText = JSON.stringify({ fromDate: fromDate, toDate: toDate });
        $(".loader").show();
        $.ajax({
            type: "POST",
            url: "AuditViewPrint.aspx/LoadForms",
            data: jsonText,
            contentType: 'application/json; charset=utf-8',
            dataType: 'JSON',
            success: function (r) {
                var table = "";
                var $tableId = $('#' + datatableId);

                if (r == "none") {

                    $tableId.bootstrapTable('destroy');
                    table = "<tr style='font-weight: bold'><td>No records</td></tr>"
                    $("#" + datatableId).html(table);
                    $("#" + datatableId).children("tbody").css("text-align", 'center');
                    $("#" + datatableId).addClass("table table-hover");

                } else {

                    $("#" + datatableId).children("tbody").css("text-align", 'left');
                    var dataSource = eval(r.d);
                    $($tableId).hide();
                    $tableId.bootstrapTable('destroy');
                    $tableId.bootstrapTable({
                        method: 'get',
                        columns: [
                                {
                                    field: 'FormInstance', title: '', width: 1, addClass: 'details-control', align: 'center', sortable: false, formatter: function (value, row, index) {
                                        return ['<span class="vz-icon vz-icon-announcement" style="cursor:pointer" title="Click on the icon to expand" onclick="LoadDetails(this,\'' + value + '\')"></span>'];
                                    }
                                },
                                {
                                    field: 'FormInstance', title: 'Form Instance', width: 1, align: 'center', sortable: false, formatter: function (value, row, index) {
                                        if (value == null) {
                                            return ['<span></span>']
                                        }
                                        return ['<span>' + value
                                            + '</span>'];
                                    }
                                },
                                {
                                    field: 'LegalName', title: 'Company Legal Name', width: 10, align: 'center', sortable: true, formatter: function (value, row, index) {
                                        if (value == null || value == "") {
                                            return ['<span></span>']
                                        }
                                        return ['<span>' + value
                                            + '</span>'];
                                    }
                                },
                                {
                                    field: 'AnalystName', title: 'BRT Analyst', align: 'center', sortable: true, width: 1, formatter: function (value, row, index) {
                                        if (value == null || value == "") {
                                            return ['<span></span>']
                                        }
                                        else {
                                            return ['<span>' + value
                                            + '</span>'];
                                        }

                                    }
                                },
                                {
                                    field: 'CreateDate', title: 'Date Form Submitted', width: 1, align: 'left', sortable: true, formatter: function (value, row, index) {
                                        if (value == null || value == "") {
                                            return ['<span></span>']
                                        }
                                        return ['<span>' + formatJSONDate(value,'')
                                            + '</span>'];
                                    },
                                },
                        ],
                        onSort: function (name, order) {

                        },

                        data: dataSource,
                        cache: false,
                        pagination: true,
                        pageSize: 20,
                        pageList: [20, 40, 60],
                        search: false,
                        showColumns: false,
                        showRefresh: false,
                        minimumCountColumns: 2,
                    });
                    $($tableId).fadeIn();
                    var forminstance = 'ABC-17-001389';
                    $('#btnExport').show();
                    $('#btnExport').attr("href", "../Helper/ExcelHandler.ashx?FromDate=" + fromDate + "&ToDate=" + toDate + "&exportType=AuditViewPrint");
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                var jsonResponse = JSON.parse(jqXHR.responseText);
                alert('Internal error occurred [' + jsonResponse.d + ']\n Please try again!');
            },
            complete: function (r) { $(".loader").hide(); }
        });
    }
    else {
        alert("Please enter all dates");
    }
}