﻿$(document).ready(function () {
    LoadDropdown('ulForm', 'rdpFormType');
    $('#btnLoadQuestions').click(function () {
        var formId = $('#hdnForm').val();
        var sectionId = $('#hdnSection').val();
        if (formId != '' && sectionId != '') {
            LoadFormQuestions('quesTable', formId, sectionId);
        }
        else {
            alert("Please select Form and Section to load Questions.");
        }
    });

    $('#btnShowNew').click(function () {
        $('#tableDiv').toggle();
        $('#addFormDiv').toggle();
        LoadDropdown('ulAddForm', 'rdpFormType', true);
        LoadSectionDropdownMul('ulAddSection');
        LoadAnsCtrlValues('ulAnsCtrlType', 'AnswerControlType');
        LoadDropdownCategories('ulAddDDIdentifier');
    });

    $('#btnAddCancel').click(function () {
        $('#tableDiv').toggle();
        $('#addFormDiv').toggle();
        ClearAddFormQuestion();
    });

    $('#btnCancel').click(function () {
        $('#tableDiv').toggle();
        $('#formDiv').toggle();
    });

    $('#btnSave').click(function () {
        //txtQuestionText
        if ($('#txtQuestionText').val() == "") {
            alert('Please enter Question Text');
        }
        else {
            SaveQuestion();
        }

    });

    $('#btnAdd').click(function () {
        //txtQuestionText
        var validateResult = validateNewQuestion();
        if (validateResult == "") {
            AddQuestion();
        }
        else {
            alert(validateResult);
        }
    });

    $('#icEditIdentifier').click(function () {
        var identifierValue = $('#lblDDIdentifier').html();
        LoadDDModal(identifierValue);
    });

    $('#chkIsRequired').on('switchChange.bootstrapSwitch', function () {
        $("#hdnIsRequired").val($('#chkIsRequired').bootstrapSwitch('state'));
    });

    $('#chkAddIsRequired').bootstrapSwitch('state', false);

    $('#chkAddIsRequired').on('switchChange.bootstrapSwitch', function () {
        $("#hdnAddIsRequired").val($('#chkAddIsRequired').bootstrapSwitch('state'));
    });

    $('#btnSaveDDValues').click(function () {
        SaveDDValues('ddList', 'Update');
    });

    $('#btnAddNewDD').click(function () {
        AddNewTextBoxes('ddList');
    });
    $('#btnAddDD').click(function () {
        AddNewTextBoxes('ddNewList');
    });

    $('#btnSaveDD').click(function () {
        SaveDDValues('ddNewList', 'Insert');
    });

    $('#btnUpdateQuestionOrder').click(function () {
        UpdateSectionQuestionOrder();
    });

    $('#btnDDClear').click(function () {
        ClearInsertDD();
    });
});

function validateNewQuestion() {
    var resultString = '';
    var questionText = $('#txtAddQuestionText').val();
    if (questionText == "") {
        resultString = resultString + "Please enter Question Text. \n";
    }
    var ulAddForm = $('#ulAddForm');
    GetMultiSelectValues(ulAddForm);
    var formId = $('#hdnAddForm').val();
    if (formId == "") {
        resultString = resultString + "Please select Form. \n";
    }
    var ulAddSection = $('#ulAddSection');
    GetMultiSelectValues(ulAddSection);
    var sectionId = $('#hdnAddSection').val();
    if (sectionId == "") {
        resultString = resultString + "Please select Section. \n";
    }

    var ansCtrlType = $('#hdnAnsCtrlType').val();
    if (ansCtrlType == "") {
        resultString = resultString + "Please select Answer Control Type. \n";
    }
    if (ansCtrlType == 4 || ansCtrlType == 6 || ansCtrlType == 823) {
        var ddIdentifier = $('#hdnAddDDIdentifier').val();
        if (ddIdentifier == "") {
            resultString = resultString + "Please select Dropdown Identifier. \n";
        }
    }
    return resultString;
}

function LoadAnsCtrlValues(uList, dropdownType) {
    var jsonText = '';
    var stsId = $('#MainContent_hiLoggedInStsId').val();
    if (dropdownType != '') {
        jsonText = JSON.stringify({ ddType: dropdownType, stsId: stsId });
    }
    else {
        jsonText = {};
    }
    $.ajax({
        type: "POST",
        url: "AmendQuestion.aspx/LoadDropDownValues",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            var teams = eval('(' + r.d + ')');
            var listItems = "";
            $('#' + uList).empty();
            for (var index = 0; index < teams.length; index++) {
                listItems = '<li data-id=\'' + teams[index].DDId + '\'><a onclick="ShowHideDDIdentifier(\'' + teams[index].Description + '\')" href=\'#\'>' + teams[index].Description + '</a></li>';
                $('#' + uList).append(listItems);
                listItems = "";
            }
            stsDropdown();
        },
        complete: function (r) {
            if (uList == 'ulPriority') {
                priComplete = true;
                checkFinished();
            }
        }
    });
}

function ShowHideDDIdentifier(ctrlType) {
    if (ctrlType == 'Check Box' || ctrlType == 'Drop down' || ctrlType == 'Radio') {
        $('#divAddDDIdentifier').show();
    }
    else {
        $('#divAddDDIdentifier').hide();
    }
}

function LoadDropdownCategories(uList) {
    var jsonText = '';
    var stsId = $('#MainContent_hiLoggedInStsId').val();
    jsonText = {};
    $.ajax({
        type: "POST",
        url: "AmendQuestion.aspx/GetAllDDCategories",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            var teams = eval('(' + r.d + ')');
            var listItems = "";
            $('#' + uList).empty();
            for (var index = 0; index < teams.length; index++) {
                listItems = '<li data-id=\'' + teams[index].Category + '\'><a onclick="LoadDDCategories(\'' + teams[index].Category + '\')" href=\'#\'>' + teams[index].Category + '</li>';
                $('#' + uList).append(listItems);
                listItems = "";
            }
            stsDropdown();
        },
        complete: function (r) {
            if (uList == 'ulPriority') {
                priComplete = true;
                checkFinished();
            }
        }
    });
}

function LoadDropdown(uList, dropdownType, addCheckbox) {
    addCheckbox = addCheckbox || false;

    var jsonText = '';
    var stsId = $('#MainContent_hiLoggedInStsId').val();
    if (dropdownType != '') {
        jsonText = JSON.stringify({ ddType: dropdownType, stsId: stsId });
    }
    else {
        jsonText = {};
    }
    $.ajax({
        type: "POST",
        url: "AmendQuestion.aspx/LoadComboBox",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            var teams = eval('(' + r.d + ')');
            var listItems = "";
            $('#' + uList).empty();
            for (var index = 0; index < teams.length; index++) {
                if (!addCheckbox) {
                    listItems = '<li data-id=\'' + teams[index].FormID + '\'><a onclick="LoadSectionDropdown(\'ulSection\',' + teams[index].FormID + ')" href=\'#\'>' + teams[index].Name + '</a></li>';
                }
                else {
                    listItems = '<li data-id=\'' + teams[index].FormID + '\'><input onclick="StopResponse()" type="checkbox"/>&nbsp;' + teams[index].Name + '</li>';
                }
                $('#' + uList).append(listItems);
                listItems = "";
            }
            stsDropdown();
        },
        complete: function (r) {
            if (uList == 'ulPriority') {
                priComplete = true;
                checkFinished();
            }
        }
    });
}

function StopResponse() {
    return false;
}

function LoadSectionDropdown(uList, dropdownType) {
    var jsonText = '';
    var stsId = $('#MainContent_hiLoggedInStsId').val();
    if (dropdownType != '') {
        jsonText = JSON.stringify({ ddType: dropdownType, stsId: stsId });
    }
    else {
        jsonText = {};
    }
    $.ajax({
        type: "POST",
        url: "AmendQuestion.aspx/LoadComboBox",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            var teams = eval('(' + r.d + ')');
            var listItems = "";
            $('#' + uList).empty();
            for (var index = 0; index < teams.length; index++) {
                listItems = '<li data-id=\'' + teams[index].SectionId + '\'><a href=\'#\'>' + teams[index].SectionDescription + '</a></li>';
                $('#' + uList).append(listItems);
                listItems = "";
            }
            stsDropdown();
        },
        complete: function (r) {
            if (uList == 'ulPriority') {
                priComplete = true;
                checkFinished();
            }
        }
    });
}

function LoadSectionDropdownMul(uList) {
    var jsonText = '';

    jsonText = {};
    $.ajax({
        type: "POST",
        url: "AmendQuestion.aspx/GetAllSections",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            var teams = eval('(' + r.d + ')');
            var listItems = "";
            $('#' + uList).empty();
            for (var index = 0; index < teams.length; index++) {
                //listItems = '<li data-id=\'' + teams[index].SectionID + '\'><a href=\'#\'>' + teams[index].SectionDescription + '</a></li>';
                listItems = '<li data-id=\'' + teams[index].SectionID + '\'><input type="checkbox"/>&nbsp;' + teams[index].SectionDescription + '</li>';
                $('#' + uList).append(listItems);
                listItems = "";
            }
            stsDropdown();
        },
        complete: function (r) {
            if (uList == 'ulPriority') {
                priComplete = true;
                checkFinished();
            }
        }
    });
}

function LoadFormQuestions(datatableId, formId, sectionId) {
    var stsId = $('#MainContent_hiLoggedInStsId').val();
    var jsonText = JSON.stringify({
        formId: formId,
        sectionId: sectionId,
        stsId: stsId
    });

    $.ajax({
        type: "POST",
        url: "AmendQuestion.aspx/LoadFormQuestions",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            var table = "";
            var $tableId = $('#' + datatableId);

            if (r == "none") {

                $tableId.bootstrapTable('destroy');
                table = "<tr style='font-weight: bold'><td>No records</td></tr>"
                $("#" + datatableId).html(table);
                $("#" + datatableId).children("tbody").css("text-align", 'center');
                $("#" + datatableId).addClass("table table-hover");

            } else {
                $('#btnUpdateQuestionOrder').show();
                $("#" + datatableId).children("tbody").css("text-align", 'left');
                var dataSource = eval(r.d);
                $($tableId).hide();
                $tableId.bootstrapTable('destroy');
                $tableId.bootstrapTable({
                    method: 'get',
                    columns: [
                            {
                                field: 'Id', title: 'Edit', width: 1, align: 'center', sortable: false, formatter: function (value, row, index) {
                                    if (value == null) {
                                        return ['<span>N/A</span>']
                                    }
                                    return ['<span><i class="vz-icon vz-icon-create" style="cursor:pointer" title="Edit" onclick=LoadForEdit(' + value + ') ></i></span>'];
                                }
                            },
                            {
                                field: 'QuestionNumber', title: 'S.No.', width: 1, align: 'center', sortable: true, formatter: function (value, row, index) {
                                    if (value == null || value == "") {
                                        return ['<span>N/A</span>']
                                    }
                                    return ['<span>' + value
                                        + '</span>'];
                                }
                            },
                            {
                                field: 'IsRequired', title: 'IsRequired', align: 'center', sortable: true, width: 1, formatter: function (value, row, index) {
                                    if (value == null || value == "") {
                                        return ['<span>0</span>']
                                    }
                                    else {
                                        return ['<span>' + value
                                        + '</span>'];
                                    }

                                }
                            },
                            {
                                field: 'AnswerControlType', title: 'Control Type', align: 'center', sortable: true, width: 1, formatter: function (value, row, index) {
                                    if (value == null || value == "") {
                                        return ['<span>0</span>']
                                    }
                                    else {
                                        return ['<span>' + value
                                        + '</span>'];
                                    }

                                }
                            },
                            {
                                field: 'Question', title: 'Question Text', width: 500, align: 'left', sortable: true, formatter: function (value, row, index) {
                                    if (value == null || value == "") {
                                        return ['<span>N/A</span>']
                                    }
                                    return ['<span>' + value
                                        + '</span>'];
                                },
                                editable: {
                                    type: 'text'
                                }

                            },
                            {
                                field: 'FormSectionID', title: 'Form SectionID', align: 'left', display: false, sortable: true, formatter: function (value, row, index) {
                                    if (value == null || value == "") {
                                        return ['<span>N/A</span>']
                                    }
                                    return ['<span><input type="hidden" value="' + value + '"/>' + value
                                        + '</span>'];
                                },
                                editable: {
                                    type: 'text'
                                }

                            },
                            {
                                field: 'QNo', title: 'Question Order', align: 'center', sortable: true, width: 1, formatter: function (value, row, index) {
                                    if (value == null || value == "") {
                                        return ['<span>0</span>']
                                    }
                                    else {
                                        return ['<input type="text" class="form-control" value="' + value + '" />'];
                                    }

                                }
                            }
                    ],
                    onSort: function (name, order) {

                    },

                    data: dataSource,
                    cache: false,
                    //height: 400,
                    pagination: true,
                    pageSize: 100,
                    pageList: [100, 200, 300],
                    search: false,
                    showColumns: false,
                    showRefresh: false,
                    minimumCountColumns: 2,
                });
                $($tableId).fadeIn();
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            var jsonResponse = JSON.parse(jqXHR.responseText);
            alert('Internal error occurred [' + jsonResponse.Message + ']\n Please try again!');
        }
    });
}

function LoadForEdit(questionId) {
    $('#tableDiv').toggle();
    $('#formDiv').toggle();
    $('#lblFormName').html($('#formText')[0].innerText);
    $('#lblSectionName').html($('#Sectiontext')[0].innerText);

    var jsonText = '';
    var stsId = $('#MainContent_hiLoggedInStsId').val();
    jsonText = JSON.stringify({ questionId: questionId, stsId: stsId });
    $.ajax({
        type: "POST",
        url: "AmendQuestion.aspx/LoadFormQuestionById",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            var dataSource = eval(r.d);
            $('#hdnQuestionId').val(dataSource[0].FormQuestionID);
            $('#txtQuestionText').val(dataSource[0].QuestionText);
            $('#chkIsRequired').bootstrapSwitch('state', dataSource[0].IsRequired);
            $('#lblAnswerType').html(dataSource[0].AnswerControlType);
            if (dataSource[0].DropDownIdentifier != null) {
                $('#divDDIdentifier').show();
                $('#lblDDIdentifier').html(dataSource[0].DropDownIdentifier);
            }
            else {
                $('#divDDIdentifier').hide();
            }
        },
        complete: function (r) {
        }
    });
}

function SaveQuestion() {
    var questionId = $('#hdnQuestionId').val();
    //if (documentId == '') {
    //    documentId = -1;
    //}
    var questionText = $('#txtQuestionText').val();
    var isRequired = StringtoInt($('#hdnIsRequired').val());

    var jsonText = JSON.stringify({
        questionId: questionId,
        questionText: questionText,
        isRequired: isRequired
    });

    $.ajax({
        type: "POST",
        url: "AmendQuestion.aspx/UpdateformQuestion",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (result) {
            //result = JSON.stringify(result);
            var formId = $('#hdnForm').val();
            var sectionId = $('#hdnSection').val();
            LoadFormQuestions('quesTable', formId, sectionId);
            $('#tableDiv').toggle();
            $('#formDiv').toggle();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            var jsonResponse = JSON.parse(jqXHR.responseText);
            alert('Internal error occurred [' + jsonResponse.Message + ']\n Please try again!');
        }
    });
}

function AddQuestion() {
    var ulAddForm = $('#ulAddForm');
    GetMultiSelectValues(ulAddForm);
    var formId = $('#hdnAddForm').val();
    var ulAddSection = $('#ulAddSection');
    GetMultiSelectValues(ulAddSection);
    var sectionId = $('#hdnAddSection').val();
    var questionText = $('#txtAddQuestionText').val();
    var isRequired = StringtoInt($('#hdnAddIsRequired').val());
    var ansCtrlType = $('#hdnAnsCtrlType').val();
    var ddIdentifier = $('#hdnAddDDIdentifier').val();

    var jsonText = JSON.stringify({
        questionText: questionText,
        ansControlType: ansCtrlType,
        ddIdentifier: ddIdentifier,
        isRequired: isRequired,
        formId: formId,
        sectionId: sectionId
    });

    $.ajax({
        type: "POST",
        url: "AmendQuestion.aspx/InsertformQuestion",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (result) {
            alert("Question added successfully");
            ClearAddFormQuestion();
            //SetSelectValueDD('ulForm', formId);
            //SetSelectValueDD('ulSection', sectionId);
            //LoadFormQuestions('quesTable', formId, sectionId);
            //$('#tableDiv').toggle();
            //$('#addFormDiv').toggle();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            var jsonResponse = JSON.parse(jqXHR.responseText);
            alert('Internal error occurred [' + jsonResponse.Message + ']\n Please try again!');
        }
    });
}

function ClearAddFormQuestion() {
    $("#ulAddForm").empty();
    $("#ulAddSection").empty();
    $("#hdnAddQuestionId").val('');
    $("#txtAddQuestionText").val('');
    $('#ulAnsCtrlType').empty();
    $('#divAddDDIdentifier').hide();
    $('#ddAddList').empty();
    $('#ulAddDDIdentifier').empty();
    LoadDropdown('ulAddForm', 'rdpFormType', true);
    LoadSectionDropdownMul('ulAddSection');
    LoadAnsCtrlValues('ulAnsCtrlType', 'AnswerControlType');
    LoadDropdownCategories('ulAddDDIdentifier');
    $('.dropdown-toggle').html('Select <span class="vzcaret"></span>');
}

function LoadDDModal(identifierValue) {
    var jsonText = '';
    jsonText = JSON.stringify({ category: identifierValue });
    $.ajax({
        type: "POST",
        url: "AmendQuestion.aspx/GetAllDropDownDataByCategory",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            $('#lblPopDDIdentifier').html(identifierValue);
            var dataSource = eval(r.d);
            var ddListControl = $('#ddList');
            ddListControl.empty();
            for (var index = 0; index < dataSource.length; index++) {
                var newDiv = $(document.createElement("div"))
                            .attr("id", "divDynaValues" + index)
                            .attr("class", "form-group");

                var newHiddenVal;
                newHiddenVal = $(document.createElement("input"))
                            .attr("type", "hidden")
                            .attr("id", "hitextbox" + index)

                newHiddenVal.val(dataSource[index].DDId + ":" + dataSource[index].DisplayValue);
                newDiv.append(newHiddenVal);

                var newtxtDiv = $(document.createElement("div"))
                            //.attr("id", "divDynaValues")
                            .attr("class", "col-md-10");

                var newTextBox;
                newTextBox = $(document.createElement("input"))
                            .attr("type", "text")
                            .attr("id", "textbox" + index)
                            .attr("name", "textbox")
                            .attr("class", "form-control")
                            .attr("onchange", "UpdateHiddenValue('hitextbox" + index + "','textbox" + index + "')");

                newTextBox.val(dataSource[index].DisplayValue);
                newtxtDiv.append(newTextBox);
                newDiv.append(newtxtDiv);


                var newIcDiv = $(document.createElement("div"))
                            //.attr("id", "divDynaValues")
                            .attr("class", "col-md-1");
                var minusIcon = '<a onclick="RemoveDiv(\'divDynaValues' + index + '\')"><i id="minusIC' + index + '" class="glyphicon glyphicon-minus" Title="Remove Entry"></i></a>';
                newIcDiv.append(minusIcon);
                newDiv.append(newIcDiv);

                ddListControl.append(newDiv);
            }
        },
        complete: function (r) {
        }
    });
}

function SaveDDValues(ddListCtrl, iType) {
    var Contain = "";
    var isValid = true;
    var isValidText = "";

    $("#" + ddListCtrl + " input[type=text]").each(function () {
        if ($(this).val() != "") {

            var regex = new RegExp("^[a-zA-Z0-9 &$-()/,+.]+$");
            if (regex.test($(this).val())) {
                return true;
            }
            else {
                isValid = false;
                isValidText = "Invalid Text";
            }
        }
        else {
            isValid = false;
        }
    });
    if (iType == "Insert") {
        var catText = $('#txtDDIdentifier').val();
        if (catText == '') {
            isValid = false;
        }
    }
    if (isValid) {
        $("#" + ddListCtrl + " input[type=hidden]").each(function () {
            Contain += $(this).val() + "$";
        });

        if (iType == "Update") {
            var catText = $('#lblPopDDIdentifier').html();
        }
        else if (iType == "Insert") {
            catText = $('#txtDDIdentifier').val();
        }

        var jsonText = JSON.stringify({
            category: catText,
            ddValues: Contain.substr(0, Contain.length - 1)
        });

        $.ajax({
            type: "POST",
            url: "AmendQuestion.aspx/UpdateDropdownValues",
            data: jsonText,
            contentType: 'application/json; charset=utf-8',
            dataType: 'JSON',
            success: function (result) {
                if (iType == "Update") {
                    var formId = $('#hdnForm').val();
                    var sectionId = $('#hdnSection').val();
                    LoadFormQuestions('quesTable', formId, sectionId);
                    $('#tableDiv').toggle();
                    $('#formDiv').toggle();
                }
                if (iType == "Insert") {
                    ClearInsertDD();
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                var jsonResponse = JSON.parse(jqXHR.responseText);
                alert('Internal error occurred [' + jsonResponse.Message + ']\n Please try again!');
            }
        });
    }
    else {
        if (isValidText != "") {
            alert("Please remove any special characters in the textboxes.");
        }
        else {
            alert("Please fill all fields.");
        }
        if (iType == "Update") {
            $('#myModal').modal({ show: true });
        }
    }
}

function AddNewTextBoxes(ddListCtrl) {
    var counter = $("#" + ddListCtrl + " input[type=text]").length;
    counter = counter + 1;
    var ddListControl = $('#' + ddListCtrl);
    var newDiv = $(document.createElement("div"))
                            .attr("id", "divDynaValues" + counter)
                            .attr("class", "form-group");

    var newHiddenVal;
    newHiddenVal = $(document.createElement("input"))
                .attr("type", "hidden")
                .attr("id", "hitextbox" + counter)

    newHiddenVal.val("-1:Test");
    newDiv.append(newHiddenVal);

    var newtxtDiv = $(document.createElement("div"))
                           //.attr("id", "divDynaValues")
                           .attr("class", "col-md-10");

    var newTextBox;
    newTextBox = $(document.createElement("input"))
                .attr("type", "text")
                .attr("id", "textbox" + counter)
                .attr("name", "textbox")
                .attr("class", "form-control")
                .attr("onchange", "UpdateHiddenValue('hitextbox" + counter + "','textbox" + counter + "')");

    newtxtDiv.append(newTextBox);
    newDiv.append(newtxtDiv);


    var newIcDiv = $(document.createElement("div"))
                .attr("class", "col-md-1");
    var minusIcon = '<a onclick="RemoveDiv(\'divDynaValues' + counter + '\')"><i id="minusIC' + counter + '" class="glyphicon glyphicon-minus"  Title="Remove Entry"></i></a>';
    newIcDiv.append(minusIcon);
    newDiv.append(newIcDiv);

    ddListControl.append(newDiv);
}

function RemoveDiv(divId) {
    var div = $("#" + divId);
    var hiControl = $("#" + divId + " input[type=hidden]");
    var idText = hiControl.val().split(':')[0]
    if (idText != -1) {
        DeleteEntry(idText, div);
    }
    else {
        div.remove();
    }
}

function DeleteEntry(ddId, divcontrol) {
    var jsonText = JSON.stringify({
        ddId: ddId
    });

    $.ajax({
        type: "POST",
        url: "AmendQuestion.aspx/DeleteDropdownVal",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (result) {
            var dataSource = eval(result.d);
            for (var index = 0; index < dataSource.length; index++) {
                if (dataSource[index].Result == "Deleted") {
                    alert("Deleted Successfully...");
                    divcontrol.remove();
                }
                else if (dataSource[index].Result == "Inusage") {
                    alert("Cannot delete the entry.It is in usage by an existing Form...");
                }
            }

        },
        error: function (jqXHR, textStatus, errorThrown) {
            var jsonResponse = JSON.parse(jqXHR.responseText);
            alert('Internal error occurred [' + jsonResponse.Message + ']\n Please try again!');
        }
    });
}

function UpdateHiddenValue(hiControl, txtControl) {//, isDelete
    //isDelete = isDelete || 0;
    var hiControl1 = $("#" + hiControl);
    var idText = hiControl1.val().split(':')[0]
    var valText = hiControl1.val().split(':')[1];
    var isActive = hiControl1.val().split(':')[2];
    var txtControl1 = $("#" + txtControl);
    var txtControl1Val = txtControl1.val();

    var finalVal = idText + ":" + txtControl1Val;
    //if (isDelete == 1) {
    //    finalVal = idText + ":" + txtControl1Val + ":0";
    //}
    hiControl1.val(finalVal);
}

function SetSelectValueDD($element, value) {
    // other code
    $element.find("li").filter(function () {
        if (($(this).data('id') == value) || ($(this).text() == value)) {
            //getting span
            var cache = $(this).parent().prev().children('span');
            $(this).parent().prev().text($(this).text()).append(cache);
            //updates value on input field
            $(this).parent().prev().prev('input[type="hidden"]').val(value);
            return true;
        }
    }).addClass('selected');
}

function GetMultiSelectValues($element) {
    var oldValue = "";
    $element.find("li").filter(function () {
        var hdnCtrl = $(this).parent().prev().prev('input[type="hidden"]');
        var checkbox = $(this).find('input[type="checkbox"]');
        if (checkbox.prop('checked')) {
            hdnCtrl.val(oldValue + "|" + $(this).data('id'));
            oldValue = hdnCtrl.val();
        }
    });
}

function LoadDDCategories(identifierValue) {
    var jsonText = '';
    jsonText = JSON.stringify({ category: identifierValue });
    $.ajax({
        type: "POST",
        url: "AmendQuestion.aspx/GetAllDropDownDataByCategory",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            $('#lblPopDDIdentifier').html(identifierValue);
            var dataSource = eval(r.d);
            var ddListControl = $('#ddAddList');
            ddListControl.empty();
            for (var index = 0; index < dataSource.length; index++) {
                var newDiv = $(document.createElement("div"))
                            .attr("id", "divShowValues" + index)
                            .attr("class", "section-divider-bottom");
                newDiv.html(dataSource[index].DisplayValue);

                ddListControl.append(newDiv);
            }
        },
        complete: function (r) {
        }
    });
}

function UpdateSectionQuestionOrder() {
    var combinedSectionInfo = '';
    $('#quesTable tr').each(function (i, row) {
        if (i == 0) return; // skip first row
        var $row = $(row),
            $hidField = $row.find('input[type="hidden"]'),
            $textField = $row.find('input[type="text"]');
        combinedSectionInfo += $hidField.val() + ';' + $textField.val() + '^';
    });
    if (combinedSectionInfo != '') {
        var jsonText = '';
        jsonText = JSON.stringify({ sectionOrderInfo: combinedSectionInfo });
        $.ajax({
            type: "POST",
            url: "AmendQuestion.aspx/UpdateSectionQuestionOrder",
            data: jsonText,
            contentType: 'application/json; charset=utf-8',
            dataType: 'JSON',
            success: function (r) {
                var dataSource = eval(r.d);

                if (dataSource == true) {
                    alert('Updated Successfully.');
                    var formId = $('#hdnForm').val();
                    var sectionId = $('#hdnSection').val();
                    LoadFormQuestions('quesTable', formId, sectionId);
                }
            },
            complete: function (r) {
            }
        });
    }
}

function ClearInsertDD() {
    $('#txtDDIdentifier').val('');
    $('#ddNewList').html('');
}