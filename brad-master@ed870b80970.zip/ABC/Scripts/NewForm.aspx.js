﻿$(document).ready(function () {
    $(".loader").hide();
    LoadDropdown('ulForm');
    $('#btnSave').click(function () {
        $(".loader").show();
        CreateNewForm();
    });

    $('#btnClear').click(function () {
        ClearForm();
    });
});

function LoadDropdown(uList) {
    var jsonText = '';
    jsonText = {};
    $.ajax({
        type: "POST",
        url: "NewForm.aspx/LoadComboBox",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            var teams = eval('(' + r.d + ')');
            var listItems = "";
            $('#' + uList).empty();
            for (var index = 0; index < teams.length; index++) {
                listItems = '<li data-id=\'' + teams[index].FormID + '\'><a onclick="LoadFormQuestions(' + teams[index].FormID + ')" href=\'#\'>' + teams[index].Name + '</a></li>';
                $('#' + uList).append(listItems);
                listItems = "";
            }
            stsDropdown();
        },
        complete: function (r) {
        }
    });
}

function LoadFormQuestions(formId) {
    var jsonText = JSON.stringify({
        formId: formId
    });

    $.ajax({
        type: "POST",
        url: "NewForm.aspx/GetQuestionstoLoad",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            AddCtrlsToForm(r.d);
            $('#divButtons').show();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            var jsonResponse = JSON.parse(jqXHR.responseText);
            alert('Internal error occurred [' + jsonResponse.d + ']\n Please try again!');
        }
    });
}

function AddCtrlsToForm(ctrlString) {
    var rr = eval(ctrlString);
    var quesTable = $('#quesTable');
    $('#quesTable tbody > tr').remove();
    quesTable.children("tbody").css("text-align", 'left');
    var tabRow = "";
    for (var key in rr) {
        quesTable.append('<tr id="Row' + (key + 1) + '"></tr>')
        if (rr[key].AnsCtrlType == "Free Form") {
            tabRow = "<td width=1 align=center>" + (parseInt(key) + 1) + "</td><td><lable name='Question" + rr[key].FormSectionId + "' class='control-label'>" + rr[key].QuestionText + "</label></td><td class='responseTd'><input type='hidden' id='hdn" + rr[key].FormSectionId + "' value='" + rr[key].FormSectionId + "'/><textarea  id='Response" + rr[key].FormSectionId + "' name='Response" + rr[key].FormSectionId + "' rows='4' spellcheck='true' autocorrect='on' class='form-control' " + ((rr[key].IsRequired) ? "required='true'" : "") + "/></td>";
        }
        else if (rr[key].AnsCtrlType == "Drop down") {
            //tabRow = "<td width=1 align=center>" + (key + 1) + "</td><td><lable name='Question" + rr[key].FormSectionId + "' class='control-label'>" + rr[key].QuestionText + "</label></td><td class='responseTd'><input type='hidden' id='hdn" + rr[key].FormSectionId + "' value='" + rr[key].FormSectionId + "'/><select id='Response" + rr[key].FormSectionId + "' onmousedown=\"LoadDropdownByCategory('Response" + rr[key].FormSectionId + "','" + rr[key].DropdownIdentifier + "')\"></select></td>";
            tabRow = "<td width=1 align=center>" + (parseInt(key) + 1) + "</td><td><lable name='Question" + rr[key].FormSectionId + "' class='control-label'>" + rr[key].QuestionText + "</label></td><td class='responseTd'><input type='hidden' id='hdn" + rr[key].FormSectionId + "' value='" + rr[key].FormSectionId + "'/><select id='Response" + rr[key].FormSectionId + "' " + ((rr[key].IsRequired) ? "required='true'" : "") + ">" + rr[key].DDOptions + "</select></td>";

        }
        else if (rr[key].AnsCtrlType == "Date") {
            tabRow = "<td width=1 align=center>" + (parseInt(key) + 1) + "</td><td><lable name='Question" + rr[key].FormSectionId + "' class='control-label'>" + rr[key].QuestionText + "</label></td><td class='responseTd'><input type='hidden' id='hdn" + rr[key].FormSectionId + "' value='" + rr[key].FormSectionId + "'/><input type='text'  id='Response" + rr[key].FormSectionId + "' name='Response" + rr[key].FormSectionId + "' class='form-control' onfocusout='CheckValidUKDate(\"Response" + rr[key].FormSectionId + "\");'/></td>";
        }
        $('#Row' + (key + 1)).html(tabRow);
    }
}

function LoadDropdownByCategory(ddctrl, category) {
    var jsonText = '';
    jsonText = JSON.stringify({ category: category });
    var s = '';
    $.ajax({
        type: "POST",
        url: "NewForm.aspx/LoadDropdownByCategory",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            var teams = eval('(' + r.d + ')');

            s += "<option value='-1'>Select</option>";
            for (var index = 0; index < teams.length; index++) {
                s += "<option value='" + teams[index].DDId + "'>" + teams[index].DisplayValue + "</option>";
            }
            $('#' + ddctrl).html(s);
        },
        complete: function (r) {
        }
    });
}

function CreateNewForm() {
    var hdnval = '';
    var txtarea;
    var ddlCtrl;
    var txtval = '';
    var ddlval = '';
    var finalResultString = '';
    var validatestring = '';
    $("#quesTable tbody tr").each(function () {
        hdnval = $(this).find("td.responseTd").find('input[type="hidden"]').val();
        txtarea = $(this).find("td.responseTd").find('textarea');//.val();
        if (txtarea.prop('required')) {
            if (txtarea.val() == '') {
                txtarea.addClass('dyn_field_yellow');
                validatestring = "Fields in yellow background are Required to create new form.";
            }
        }
        txtval = txtarea.val();
        dateval = $(this).find("td.responseTd").find('input[type="text"]').val();
        //ddlCtrl = $(this).find("td.responseTd").find('select > option:selected');
        ddlCtrl = $(this).find("td.responseTd").find('select');
        if (ddlCtrl.prop('required')) {
            var txt = ddlCtrl.find('option:selected');
            if (txt.val() == '' || txt.val() == '-1') {
                ddlCtrl.addClass('dyn_field_yellow');
                validatestring = "Fields in yellow background are Required to create new form.";
            }
        }
        ddlval = ddlCtrl.find('option:selected').val();
        //ddlval = $(this).find("td.responseTd").find('select > option:selected').val();
        if (hdnval && txtval) {
            finalResultString += hdnval + '^' + txtval;
        }
        else if (hdnval && dateval) {
            finalResultString += hdnval + '^' + dateval;
        }
        else if (hdnval && ddlval) {
            finalResultString += hdnval + '^' + ddlval;
        }
        if (hdnval && (txtval || ddlval || dateval)) {
            finalResultString += '|';
        }
    });
    if (validatestring == '') {
        var hdnFormId = $('#hdnForm').val();
        var jsonText = '';
        jsonText = JSON.stringify({
            inputData: finalResultString,
            formId: hdnFormId
        });
        $.ajax({
            type: "POST",
            url: "NewForm.aspx/InsertUserPartialForm",
            data: jsonText,
            contentType: 'application/json; charset=utf-8',
            dataType: 'JSON',
            beforeSend: function () {
                $(".loader").hide();
                $(".loader").show();
            },
            success: function (r) {
                if (r.d != 'Error') {
                    alert('Form created successfuly: ' + r.d);
                }
            },
            complete: function (r) {
                $(".loader").hide();
            }
        });
    }
    else {
        alert(validatestring);
        $(".loader").hide();
    }
}

function ClearForm() {
    var url = window.location.href;
    if (url.indexOf('#') == url.length - 1) {
        url = url.substring(0, url.length - 1);
    }
    window.location.href = url;
}

function CheckValidUKDate(datectrl) {
    var dateStr = $('#' + datectrl).val();
    if (!moment(dateStr, "DD/MM/YYYY").isValid()) {
        alert("Please enter Valid date");
        $('#' + datectrl).addClass('dyn_field_yellow')
    }
}