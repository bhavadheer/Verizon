﻿$(document).ready(function () {
    LoadSections('sectionTable');

    LoadDropdown('ulForm', 'rdpFormType', 'ulSection', 'lstBox1');

    LoadDropdown('ulForm2', 'rdpFormType', 'ulSection2', 'lstBox2');

    $('#btnSectionCancel').click(function () {
        $('#sectionTableDiv').toggle();
        $('#sectionUpdateDiv').toggle();
    });

    $('#btnSectionSave').click(function () {
        UpdateSections();
    });

    $('#btnSaveSecOrder').click(function () {
        UpdateSectionOrder();
    });

    $('#btnRight').click(function (e) {
        var selectedOpts = $('#lstBox1 option:selected');
        if (selectedOpts.length == 0) {
            alert("Nothing to move.");
            e.preventDefault();
        }

        $('#lstBox2').append($(selectedOpts).clone());
        $(selectedOpts).remove();
        e.preventDefault();
    });

    $('#btnAllRight').click(function (e) {
        var selectedOpts = $('#lstBox1 option');
        if (selectedOpts.length == 0) {
            alert("Nothing to move.");
            e.preventDefault();
        }

        $('#lstBox2').append($(selectedOpts).clone());
        $(selectedOpts).remove();
        e.preventDefault();
    });

    $('#btnLeft').click(function (e) {
        var selectedOpts = $('#lstBox2 option:selected');
        if (selectedOpts.length == 0) {
            alert("Nothing to move.");
            e.preventDefault();
        }

        $('#lstBox1').append($(selectedOpts).clone());
        $(selectedOpts).remove();
        e.preventDefault();
    });

    $('#btnAllLeft').click(function (e) {
        var selectedOpts = $('#lstBox2 option');
        if (selectedOpts.length == 0) {
            alert("Nothing to move.");
            e.preventDefault();
        }

        $('#lstBox1').append($(selectedOpts).clone());
        $(selectedOpts).remove();
        e.preventDefault();
    });

    $('#btnFormSectionSave').click(function () {
        UpdateFormSection();
    });

    $('#btnFormSectionCancel').click(function () {
        ClearFormSection();
    });
});

function LoadSections(datatableId) {
    var jsonText = {};

    $.ajax({
        type: "POST",
        url: "AmendSections.aspx/LoadSections",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            var table = "";
            var $tableId = $('#' + datatableId);

            if (r == "none") {

                $tableId.bootstrapTable('destroy');
                table = "<tr style='font-weight: bold'><td>No records</td></tr>"
                $("#" + datatableId).html(table);
                $("#" + datatableId).children("tbody").css("text-align", 'center');
                $("#" + datatableId).addClass("table table-hover");

            } else {

                $("#" + datatableId).children("tbody").css("text-align", 'left');
                var dataSource = eval(r.d);
                $($tableId).hide();
                $tableId.bootstrapTable('destroy');
                $tableId.bootstrapTable({
                    method: 'get',
                    columns: [
                            {
                                field: 'SectionID', title: 'Edit', width: 1, align: 'center', sortable: false, formatter: function (value, row, index) {
                                    if (value == null) {
                                        return ['<span>N/A</span>']
                                    }
                                    return ['<span><input type="hidden" value="' + value + '"/><i class="vz-icon vz-icon-create" style="cursor:pointer" title="Edit" onclick=LoadForEdit(' + value + ') ></i></span>'];
                                }
                            },
                            {
                                field: 'SectionName', title: 'Section Name', width: 1, align: 'center', sortable: true, formatter: function (value, row, index) {
                                    if (value == null || value == "") {
                                        return ['<span>N/A</span>']
                                    }
                                    return ['<span>' + value
                                        + '</span>'];
                                }
                            },
                            {
                                field: 'SectionDescription', title: 'Description', align: 'center', sortable: true, width: 1, formatter: function (value, row, index) {
                                    if (value == null || value == "") {
                                        return ['<span>N/A</span>']
                                    }
                                    else {
                                        return ['<span>' + value
                                        + '</span>'];
                                    }

                                }
                            },
                            {
                                field: 'SectionOrder', title: 'Section Order', align: 'center', sortable: true, width: 1, formatter: function (value, row, index) {
                                    if (value == null || value == "") {
                                        return ['<span>0</span>']
                                    }
                                    else {
                                        return ['<input type="text" class="form-control" value="' + value + '" />'];
                                    }

                                }
                            }
                    ],
                    onSort: function (name, order) {

                    },

                    data: dataSource,
                    cache: false,
                    pagination: true,
                    pageSize: 50,
                    pageList: [50, 100, 200, 300],
                    search: false,
                    showColumns: false,
                    showRefresh: false,
                    minimumCountColumns: 2,
                });
                $($tableId).fadeIn();
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            var jsonResponse = JSON.parse(jqXHR.responseText);
            alert('Internal error occurred [' + jsonResponse.d + ']\n Please try again!');
        }
    });
}

function LoadForEdit(sectionId) {
    $('#sectionTableDiv').toggle();
    $('#sectionUpdateDiv').toggle();

    var jsonText = '';
    jsonText = JSON.stringify({ sectionID: sectionId });
    $.ajax({
        type: "POST",
        url: "AmendSections.aspx/LoadSectionForEdit",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            var dataSource = eval(r.d);
            $('#hdnSectionId').val(dataSource[0].SectionID);
            $('#txtSectionName').val(dataSource[0].SectionName);
            $('#txtSectionDesc').val(dataSource[0].SectionDescription);
        },
        complete: function (r) {
        }
    });
}

function UpdateSections() {
    var sectionId = $('#hdnSectionId').val();
    var sectionName = $('#txtSectionName').val();
    var sectionDesc = $('#txtSectionDesc').val();
    $(".loader").show();
    var jsonText = '';
    jsonText = JSON.stringify({ sectionID: sectionId, sectionName: sectionName, sectionDesc: sectionDesc });
    $.ajax({
        type: "POST",
        url: "AmendSections.aspx/UpdateSection",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            var dataSource = eval(r.d);
            alert('Updated Successfully.');
        },
        complete: function (r) {
            $(".loader").hide();
        }
    });
}

function UpdateSectionOrder() {
    var combinedSectionInfo = '';
    $('#sectionTable tr').each(function (i, row) {
        if (i == 0) return; // skip first row
        var $row = $(row),
            $hidField = $row.find('input[type="hidden"]'),
            $textField = $row.find('input[type="text"]');
        combinedSectionInfo += $hidField.val() + ';' + $textField.val() + '^';
    });
    if (combinedSectionInfo != '') {
        var jsonText = '';
        jsonText = JSON.stringify({ sectionOrderInfo: combinedSectionInfo });
        $.ajax({
            type: "POST",
            url: "AmendSections.aspx/UpdateSectionOrder",
            data: jsonText,
            contentType: 'application/json; charset=utf-8',
            dataType: 'JSON',
            success: function (r) {
                var dataSource = eval(r.d);
                if (dataSource == true) {
                    alert('Updated Successfully.');
                    LoadSections('sectionTable');
                }
            },
            complete: function (r) {
            }
        });
    }
}

function LoadDropdown(uList, dropdownType, depSections, depList) {
    var jsonText = '';
    if (dropdownType != '') {
        jsonText = JSON.stringify({ ddType: dropdownType });
    }
    else {
        jsonText = {};
    }
    $.ajax({
        type: "POST",
        url: "AmendSections.aspx/LoadComboBox",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            var teams = eval('(' + r.d + ')');
            var listItems = "";
            $('#' + uList).empty();
            for (var index = 0; index < teams.length; index++) {
                listItems = '<li data-id=\'' + teams[index].FormID + '\'><a onclick="LoadSectionDropdown(\'' + depSections + '\',' + teams[index].FormID + ', \'' + depList + '\' )" href=\'#\'>' + teams[index].Name + '</a></li>';
                $('#' + uList).append(listItems);
                listItems = "";
            }
            stsDropdown();
        },
        complete: function (r) {
            if (uList == 'ulPriority') {
                priComplete = true;
                checkFinished();
            }
        }
    });
}

function StopResponse() {
    return false;
}

function LoadSectionDropdown(uList, dropdownType, depList) {
    var jsonText = '';
    if (dropdownType != '') {
        jsonText = JSON.stringify({ ddType: dropdownType });
    }
    else {
        jsonText = {};
    }
    $.ajax({
        type: "POST",
        url: "AmendSections.aspx/LoadComboBox",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            var teams = eval('(' + r.d + ')');
            var listItems = "";
            $('#' + uList).empty();
            for (var index = 0; index < teams.length; index++) {
                listItems = '<li data-id=\'' + teams[index].SectionId + '\'><a onclick="LoadQuestions(' + dropdownType + ',' + teams[index].SectionId + ',\'' + depList + '\')" href=\'#\'>' + teams[index].SectionDescription + '</a></li>';
                $('#' + uList).append(listItems);
                listItems = "";
            }
            stsDropdown();
        },
        complete: function (r) {
            if (uList == 'ulPriority') {
                priComplete = true;
                checkFinished();
            }
        }
    });
}

function LoadQuestions(formId, sectionId, depList) {

    var jsonText = JSON.stringify({
        formId: formId,
        sectionId: sectionId
    });

    $.ajax({
        type: "POST",
        url: "AmendSections.aspx/LoadFormQuestions",
        data: jsonText,
        contentType: 'application/json; charset=utf-8',
        dataType: 'JSON',
        success: function (r) {
            var teams = eval('(' + r.d + ')');
            var listItems = "";
            $('#' + depList).empty();
            for (var index = 0; index < teams.length; index++) {
                listItems = '<option data-id="' + teams[index].FormSectionID + '" value="' + teams[index].Id + '" title="' + teams[index].Question + '">' + teams[index].Question + '</option>';
                $('#' + depList).append(listItems);
                listItems = "";
            }
        },
        complete: function (r) {

        }
    });
}

function UpdateFormSection() {
    var options = [];
    var formId1 = $('#hdnForm').val();
    var formId2 = $('#hdnForm2').val();
    if (formId1 == formId2) {
        var sectionId1 = $('#hdnSection').val();
        var sectionId = $('#hdnSection2').val();
        if (sectionId1 != sectionId) {
            $("#lstBox2 option").each(function (i) {
                options.push($(this).data("id"));
            });
            $(".loader").show();
            var formSectionID = options.join();

            var jsonText = JSON.stringify({
                newSectionID: sectionId,
                formSectionId: formSectionID
            });

            $.ajax({
                type: "POST",
                url: "AmendSections.aspx/UpdateFormSection",
                data: jsonText,
                contentType: 'application/json; charset=utf-8',
                dataType: 'JSON',
                success: function (r) {
                    var dataSource = eval(r.d);

                    alert('Updated Successfully.');
                },
                complete: function (r) {
                    $(".loader").hide();
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    $(".loader").hide();
                    var jsonResponse = JSON.parse(jqXHR.responseText);
                    alert('Internal error occurred [' + jsonResponse.Message + ']\n Please try again!');
                }
            });
        }
        else {
            alert("Sections cannot be same to move Questions.");
        }
    }
    else {
        alert("Forms should be same to move Questions.");
    }
}

function ClearFormSection() {
    $("#ulForm").empty();
    $("#ulForm2").empty();
    $("#ulSection").empty();
    $("#ulSection2").empty();
    $('#lstBox1').empty();
    $('#lstBox2').empty();
    LoadDropdown('ulForm', 'rdpFormType', 'ulSection', 'lstBox1');
    LoadDropdown('ulForm2', 'rdpFormType', 'ulSection2', 'lstBox2');
    $('.dropdown-toggle').html('Select <span class="vzcaret"></span>');
}