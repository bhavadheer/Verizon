﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using BusinessLogicLayer;
using Common;


namespace ABC
{
    [Serializable]
    public class Navigation
    {
        #region " Public Properties "
        public String LoginVzidOrEid { get; set; }
        public Int32 LoggedInStsId { get; set; }
        public String LoggedInVzid { get; set; }
        public String UserName { get; set; }
        public String DefaultPage { get; set; }
        public String LogoutPage { get; set; }
        public String UserEmail { get; set; }
        public String UserPhone { get; set; }
        public RoleType CurrentRole { get; set; }
        public RoleType HighestRole { get; set; }
        public List<RoleType> RoleList { get; set; }
        public List<Location> UserAreas { get; set; }
        public String IPAddress { get; set; }

        public int ShowDelete { get; set; }
        #endregion

        #region " Private Constructor "
        private Navigation()
        {
            Reset();
        }
        #endregion

        #region " Public Instance "
        /// <summary>
        /// Navigation
        /// </summary>
        public static Navigation Current
        {
            get
            {
                Navigation session = (Navigation)HttpContext.Current.Session["__Navigation__"];

                if (session == null)
                {
                    session = new Navigation();
                    HttpContext.Current.Session["__Navigation__"] = session;
                }

                return session;
            }
        }
        #endregion

        #region " Public Methods "

        #region " GetUserNavigation "
        /// <summary>
        /// GetUserNavigation
        /// </summary>
        /// <param name="vzidOrEid"></param>
        public void GetUserNavigation(string vzidOrEid, string clientIP)
        {
            //Reset User Info When Relogging In
            if (!String.IsNullOrEmpty(vzidOrEid) && vzidOrEid != LoginVzidOrEid)
            {
                Reset();

                using (NavigationManager navMgr = new NavigationManager(Global.ABCConnectionString))
                {
                    using (DataTable dt = navMgr.GetUserCredentials(vzidOrEid))
                    {
                        if (dt != null && dt.Rows.Count > 0)
                        {
                            //Set logged in user info
                            LoginVzidOrEid = vzidOrEid;
                            LoggedInVzid = dt.Rows[0]["vzid"].ToString().ToLower().Trim();
                            LoggedInStsId = Convert.ToInt32(dt.Rows[0]["StsId"]);
                            UserName = dt.Rows[0]["FirstName"].ToString().Trim() + " " + dt.Rows[0]["LastName"].ToString().Trim();
                            UserEmail = dt.Rows[0]["Email"].ToString();
                            CurrentRole = EnumHelper.GetEnumTypeFromString<RoleType>(dt.Rows[0]["RoleID"].ToString(), RoleType.NotSet);
                            RoleList = navMgr.GetUserRoles(Navigation.Current.LoggedInStsId);
                            HighestRole = RoleList.OrderByDescending(x => Convert.ToInt32(x)).FirstOrDefault();
                            UserAreas = navMgr.GetUserAreas(Navigation.Current.LoggedInStsId, CurrentRole);
                            IPAddress = clientIP;
                            ShowDelete = Convert.ToInt32(dt.Rows[0]["ShowDelete"]);
                            //HttpContext.Current.Session["SsoLoginVzid"] = Convert.ToString(dt.Rows[0]["vzid"]).Trim().ToLower();
                            //HttpContext.Current.Session["SsoLoginStsId"] = Convert.ToString(dt.Rows[0]["StsId"]).Trim().ToLower();
                            //HttpContext.Current.Session["Role"] = Convert.ToString(dt.Rows[0]["Role"]).Trim();
                            ////Set logged in user info
                            //HttpContext.Current.Session["userName"] = Convert.ToString(dt.Rows[0]["FirstName"]).Trim() + " " + Convert.ToString(dt.Rows[0]["LastName"]).Trim();
                            ////    Session["eId"] = Convert.ToString(dt.Rows[0]["Eid"]).Trim();
                            //HttpContext.Current.Session["currentUserRole"] = dt.Rows[0]["RoleId"].ToString();
                            //HttpContext.Current.Session["currentUserRoleName"] = dt.Rows[0]["RoleName"].ToString();
                            HttpRequest request = HttpContext.Current.Request;

                            if (request.Url != null && request.QueryString["request"] != null && request.QueryString["request"].ToString() != string.Empty)
                            {
                                DefaultPage = request.Url.ToString();
                            }
                            else
                            {
                                if (dt.Rows[0]["DefaultPage"] != null)
                                {
                                    DefaultPage = dt.Rows[0]["DefaultPage"].ToString();
                                }
                            }
                            int rst = navMgr.SaveUserAccessHistory(vzidOrEid, UserName, "login", LoggedInStsId, clientIP);
                        }
                    }
                }
            }
        }
        #endregion

        #region " Reset "
        /// <summary>
        /// Reset
        /// </summary>
        public void Reset()
        {
            //Set Defaults
            LoginVzidOrEid = String.Empty;
            LoggedInStsId = -1;
            LoggedInVzid = String.Empty;
            UserName = String.Empty;
            UserEmail = String.Empty;
            DefaultPage = LogoutPage = "~/Home/Logout.aspx";
            CurrentRole = RoleType.NotSet;
            RoleList = new List<RoleType>();
            UserAreas = new List<Location>();
        }
        #endregion

        #endregion
    }
}