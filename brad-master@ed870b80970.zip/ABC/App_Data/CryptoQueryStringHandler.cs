using System.Collections.Specialized;
using System.Text;
using System.Web.Configuration;

namespace Verizon.QueryStringEncryption
{
    /// <summary>
    /// This class contains methods to en-/decrypt query strings.
    /// </summary>
    public static class CryptoQueryStringHandler
    {
        /// <summary>
        /// Encrypt query strings from string array.
        /// </summary>
        /// <param name="unencryptedValues">Unencrypted query strings in the format 'param=value'.</param>
        /// <param name="key">Key, being used to encrypt.</param>
        /// <returns></returns>
        public static string EncryptQueryStrings(string[] unencryptedValues, string key)
        {
            string sb = string.Join("&", unencryptedValues);

            return string.Concat("request=", Encryption64.Encrypt(sb, key));
        }

        /// <summary>
        /// Encrypt query strings from name value collection.
        /// </summary>
        /// <param name="unencryptedValues">Unencrypted query strings.</param>
        /// <param name="key">Key, being used to encrypt.</param>
        /// <returns></returns>
        public static string EncryptQueryStrings(NameValueCollection unencryptedValues, string key)
        {
            StringBuilder sb = new StringBuilder();

            foreach (string stringKey in unencryptedValues.Keys)
            {
                if (sb.Length > 0) sb.Append("&");
                sb.Append(string.Format("{0}={1}", stringKey, unencryptedValues[stringKey]));
            }

            return string.Concat("request=", Encryption64.Encrypt(sb.ToString(), key));
        }

        /// <summary>
        /// Decrypt query string.
        /// </summary>
        /// <param name="encryptedValues">Encrypted query string.</param>
        /// <param name="key">Key, being used to decrypt.</param>
        /// <remarks>The query string object replaces '+' character with an empty character.</remarks>
        /// <returns></returns>
        public static string DecryptQueryStrings(string encryptedValues, string key)
        {
            return Encryption64.Decrypt(encryptedValues.Replace(" ", "+"), key);
        }

        /// <summary>
        /// Get Decrypted query string.
        /// </summary>
        /// <returns>Returns decrypted strings in an array</returns>
        public static NameValueCollection GetDecryptedQueryStrings(string encryptedQueryString)
        {
            string cryptoKey = WebConfigurationManager.AppSettings["CryptoKey"];
            string decryptedQueryString = CryptoQueryStringHandler.DecryptQueryStrings(encryptedQueryString, cryptoKey);

            string[] strArray = decryptedQueryString.Split('&');

            NameValueCollection decryptedQueryStrings = new NameValueCollection();

            if (strArray.Length != 0)
            {
                for (int i = 0; i < strArray.Length; i++)
                {
                    string[] strSubArray = strArray[i].Split('=');
                    if (strSubArray[0] != null && strSubArray[1] != null)
                    {
                        decryptedQueryStrings.Add(strSubArray[0], strSubArray[1]);
                    }
                }
            }

            return decryptedQueryStrings;

        }
    }
}