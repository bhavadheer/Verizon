﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogicLayer;
using Common;


namespace ABC.ISS
{
    public partial class LocationPicker : System.Web.UI.UserControl
    {
        #region " Private Properties "
        private List<Location> _SelectedLocations
        {
            get
            {
                if(ViewState["SelectedLocations"] == null)
                {
                    ViewState["SelectedLocations"] = new List<Location>();
                }

                return (List<Location>)ViewState["SelectedLocations"];
            }
            set
            {
                ViewState["SelectedLocations"] = value;
            }
        }

        private List<Location> _AllLocations
        {
            get
            {
                if(ViewState["AllLocations"] == null)
                {
                    ViewState["AllLocations"] = new List<Location>();
                }

                return (List<Location>)ViewState["AllLocations"];
            }
            set
            {
                ViewState["AllLocations"] = value;
            }
        }

        protected enum CheckTriState
        {
            UnChecked = 0,
            Checked = 1,
            Mixed = 2
        }

        private const string CheckedStyle = "<span class='fa fa-check-square-o'>&nbsp;{0}</span>";
        private const string UnCheckedStyle = "<span class='fa fa-square-o'>&nbsp;{0}</span>";
        private const string MixedCheckedStyle = "<span class='fa fa-square'>&nbsp;{0}</span>";
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                using (NavigationManager nav = new NavigationManager(Global.ICEConnectionString))
                {
                    _AllLocations.Clear();
                    _AllLocations.AddRange(nav.GetAllUserAreas(RoleType.Administrator));
                }

                LoadLocationTree();
            }
        }

        public List<Location> SelectedLocations()
        {
            return _SelectedLocations;
        }

        #region " tvLocations Methods "

        #region " LoadLocationTree "
        /// <summary>
        /// LoadLocationTree
        /// </summary>
        protected void LoadLocationTree()
        {
            List<Location> allCountry = _AllLocations.GroupBy(e => e.CountryCode).Select(x => x.First()).ToList();

            foreach (Location ploc in allCountry)
            {
                TreeNode countryNode = new TreeNode()
                {
                    Text = String.Format(UnCheckedStyle, ploc.CountryCode),
                    Value = ploc.CountryCode,
                    SelectAction = TreeNodeSelectAction.Select,
                    Target = "Javascript:Void();"
                };
                tvLocations.Nodes.Add(countryNode);

                List<Location> countryLocations = _AllLocations.Where(e => e.CountryCode == ploc.CountryCode).ToList();
                foreach (Location cloc in countryLocations)
                {
                    TreeNode childNode = new TreeNode()
                    {
                        Text = String.Format(UnCheckedStyle, cloc.LocationCode),
                        Value = cloc.LocationCode,
                        SelectAction = TreeNodeSelectAction.Select,
                        Target = "Javascript:Void();"
                    };

                    countryNode.ChildNodes.Add(childNode);
                }
            }
        }
        #endregion

        #region " CheckParentNode "
        /// <summary>
        /// CheckParentNode
        /// </summary>
        /// <param name="node"></param>
        protected void CheckParentNode(TreeNode node)
        {
            if (node != null)
            {
                switch(CheckChildNodes(node))
                {
                    case CheckTriState.Checked:
                        node.Checked = true;
                        node.Text = String.Format(CheckedStyle, node.Value);
                        break;

                    case CheckTriState.UnChecked:
                        node.Checked = false;
                        node.Text = String.Format(UnCheckedStyle, node.Value);
                        break;

                    case CheckTriState.Mixed:
                        node.Checked = false;
                        node.Text = String.Format(MixedCheckedStyle, node.Value);
                        break;
                }

                //Check Ancestors - Not really needed since we only have 2 levels
                //if(node.Parent != null)
                //{
                //    CheckParentNode(node.Parent);
                //}
            }
        }
        #endregion

        #region " CheckChildNodes "
        /// <summary>
        /// CheckChildNodes
        /// </summary>
        /// <param name="node"></param>
        /// <returns>CheckTriState</returns>
        protected CheckTriState CheckChildNodes(TreeNode node)
        {
            int unchkCount = 0;
            int chkCount = 0;

            foreach (TreeNode child in node.ChildNodes)
            {
                if (child.Checked)
                {
                    chkCount++;
                }
                else
                {
                    unchkCount++;
                }
            }

            CheckTriState cts = chkCount > 0 ? (unchkCount > 0 ? CheckTriState.Mixed : CheckTriState.Checked) : CheckTriState.UnChecked;

            return cts;
        }
        #endregion

        #region " SelectNode "
        /// <summary>
        /// SelectNode
        /// </summary>
        /// <param name="node"></param>
        protected void SelectNode(TreeNode node)
        {
            if (!node.Checked)
            {
                node.Checked = true;
                node.Text = String.Format(CheckedStyle, node.Value);

                //Add Location to Selected
                Location foundLoc = _AllLocations.SingleOrDefault(s => s.LocationCode == node.Value);
                if (foundLoc != null)
                {
                    _SelectedLocations.Add(foundLoc);
                }

                //Select Children
                foreach (TreeNode c in node.ChildNodes)
                {
                    SelectNode(c);
                }
            }
        }
        #endregion

        #region " UnSelectNode "
        /// <summary>
        /// UnSelectNode
        /// </summary>
        /// <param name="node"></param>
        protected void UnSelectNode(TreeNode node)
        {
            if (node.Checked)
            {
                node.Checked = false;
                node.Text = String.Format(UnCheckedStyle, node.Value);

                //Remove Location from Selected
                Location foundLoc = _AllLocations.SingleOrDefault(s => s.LocationCode == node.Value);
                if (foundLoc != null)
                {
                    _SelectedLocations.Remove(foundLoc);
                }

                //UnSelect Children
                foreach (TreeNode c in node.ChildNodes)
                {
                    UnSelectNode(c);
                }
            }
        }
        #endregion

        #region " tvLocations_SelectedNodeChanged "
        /// <summary>
        /// tvLocations_SelectedNodeChanged
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void tvLocations_SelectedNodeChanged(object sender, EventArgs e)
        {
            switch (tvLocations.SelectedNode.Checked)
            {
                case true:
                    UnSelectNode(tvLocations.SelectedNode);
                    CheckParentNode(tvLocations.SelectedNode.Parent);
                    break;

                case false:
                    SelectNode(tvLocations.SelectedNode);
                    CheckParentNode(tvLocations.SelectedNode.Parent);
                    break;
            }

            //Reset Node after
            tvLocations.SelectedNode.Selected = false;
        }
        #endregion

        #endregion
    }
}