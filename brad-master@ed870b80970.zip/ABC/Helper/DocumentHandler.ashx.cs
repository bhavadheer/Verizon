﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ABC.ISS
{
    /// <summary>
    /// Summary description for DocumentHandler
    /// </summary>
    public class DocumentHandler : IHttpHandler
    {
        #region " Private Properties "
        private string DocumentId { get; set; }
        private string DocumentType { get; set; }
        
        #endregion

        public void ProcessRequest(HttpContext context)
        {
            context.Response.Clear();

            LoadDefaults(context);

            if(!String.IsNullOrEmpty(DocumentId) && !String.IsNullOrEmpty(DocumentType))
            {
                context.Response.ContentType = "application/pdf";
                context.Response.WriteFile(@"C:\Users\v115275\Documents\Visual Studio 2013\Projects\userguide.pdf");
            }
            else
            {
                context.Response.ContentType = "text/plain";
                context.Response.Write("<p>Invalid Document</p>");
            }
        }

        protected void LoadDefaults(HttpContext context)
        {
            if(context.Request.QueryString["DocumentType"] != null)
            {
                DocumentType = context.Request.QueryString["DocumentType"].ToString();
            }
            if(context.Request.QueryString["DocumentId"] != null)
            {
                DocumentId = context.Request.QueryString["DocumentId"].ToString();
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}