﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Web;

namespace ABC.ISS
{
    /// <summary>
    /// Summary description for ImageHandler
    /// </summary>
    public class ImageHandler : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.Clear();

            if (!String.IsNullOrEmpty(context.Request.QueryString["ImageID"]))
            {
                int id = Int32.Parse(context.Request.QueryString["ImageID"]);

                Image image = GetImage(id);

                // Of course set this to whatever your format is of the image
                context.Response.ContentType = "image/jpeg";
                // Save the image to the OutputStream
                image.Save(context.Response.OutputStream, ImageFormat.Jpeg);
            }
            else
            {
                context.Response.ContentType = "text/plain";
                context.Response.Write("<p>Need a valid id</p>");
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        private Image GetImage(int id)
        {
            Image i;

            switch (id)
            {
                case 1:
                    {
                        i = Image.FromFile(@"C:\Users\Public\Pictures\Sample Pictures\Chrysanthemum.jpg");
                    }
                    break;

                case 2:
                    {
                        i = Image.FromFile(@"C:\Users\Public\Pictures\Sample Pictures\Desert.jpg");
                    }
                    break;

                case 3:
                    {
                        i = Image.FromFile(@"C:\Users\Public\Pictures\Sample Pictures\Jellyfish.jpg");
                    }
                    break;

                default:
                    {
                        i = Image.FromFile(@"C:\Users\Public\Pictures\Sample Pictures\Koala.jpg");
                    }
                    break;
            }
            
            return i;
        }
    }
}