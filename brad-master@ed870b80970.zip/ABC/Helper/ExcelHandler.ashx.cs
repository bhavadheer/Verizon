﻿using BusinessLogicLayer;
using Common;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;

namespace ABC.Helper
{
    /// <summary>
    /// Summary description for ExcelHandler
    /// </summary>
    public class ExcelHandler : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            try
            {
                var fileName = string.Empty;

                switch (context.Request["exportType"])
                {
                    case "BRTTimeReport":
                        using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                        {
                            using (var dt = dm.GetBRTTimeReportExport(context.Request["criteria"], context.Request["formInstance"]))
                            {
                                fileName = Path.Combine(Global.TempPathForFile, "BRTTimeReport" + DateTime.Now.GetTimeStamp() + ".xlsx");
                                dt.ExportToExcelJquery(fileName);
                            }
                        }
                        break;
                    case "AuditViewPrint":
                        using (FormManager dm = new FormManager(Global.ABCConnectionString))
                        {
                            //var FormDate = ;
                            //var ToDate = context.Request["ToDate"];
                            var ci = System.Globalization.CultureInfo.CreateSpecificCulture("en-GB");
                            var FormDate = context.Request["FromDate"] == "" ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(DateTime.Parse(context.Request["FromDate"], ci.DateTimeFormat).ToString("d"));
                            var ToDate = context.Request["ToDate"] == "" ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(DateTime.Parse(context.Request["ToDate"], ci.DateTimeFormat).ToString("d"));
                            using (var dt = dm.GetAuditViewPrintExport(FormDate, ToDate))
                            {
                                fileName = Path.Combine(Global.TempPathForFile, "AuditViewPrint" + DateTime.Now.GetTimeStamp() + ".xlsx");
                                dt.ExportToExcelJquery(fileName);
                            }
                        }
                        break;
                }

            }
            catch (Exception ex)
            {
                ExceptionPolicy.HandleException(ex, Global.ApplicationLayerPolicy);
            }
        }

        public static DataTable ConvertToDataTable<T>(IList<T> data)
        {
            var properties = TypeDescriptor.GetProperties(typeof(T));
            var table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);

            foreach (T item in data)
            {
                var row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }
            return table;
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}