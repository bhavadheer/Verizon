﻿using BusinessLogicLayer;
using Common;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ABC.ABCForm
{
    public partial class AmendQuestion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                hiLoggedInVzid.Value = Navigation.Current.LoggedInVzid;// Convert.ToString(Session["SsoLoginVzid"]);
                hiLoggedInStsId.Value = Convert.ToString(Navigation.Current.LoggedInStsId);
            }
        }

        #region " ProcessException "

        protected static void ProcessException(Exception inEx, string inFunctionName, string inSPName, int stsId)
        {
            var userName = string.Empty;
            if (Navigation.Current.UserName != null)
            {
                userName = Navigation.Current.UserName;
            }
            var excep = new ABCException
            {
                StsId = stsId,
                Name = userName,
                MethodName = inFunctionName,
                SpName = inSPName,
                PageName = "AmendQuestion.aspx.cs"
            };
            inEx.HelpLink = ABCException.GetMoreInfoForException(excep);
            ExceptionPolicy.HandleException(inEx, Global.ApplicationLayerPolicy);
        }

        #endregion

        #region " DataTableToJSONWithJavaScriptSerializer "
        public static string DataTableToJSONWithJavaScriptSerializer(DataTable table)
        {
            var jsSerializer = new JavaScriptSerializer
            {
                MaxJsonLength = Int32.MaxValue
            };
            var parentRow = new List<Dictionary<string, object>>();
            Dictionary<string, object> childRow;
            foreach (DataRow row in table.Rows)
            {
                childRow = new Dictionary<string, object>();
                foreach (DataColumn col in table.Columns)
                {
                    childRow.Add(col.ColumnName, row[col]);
                }
                parentRow.Add(childRow);
            }
            return jsSerializer.Serialize(parentRow);
        }
        #endregion

        #region " Web Methods "
        #region " LoadDropDown "
        /** \private    LoadDropDown 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
        */
        [WebMethod]
        public static string LoadComboBox(string ddType, int stsId)
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    var roleId = ((Int32)Navigation.Current.CurrentRole).ToString();// Session["currentUserRole"] != null ? Convert.ToString(Session["currentUserRole"]) : string.Empty;
                    // rdpFormSection is dependent on the selected rdpFormType dropDown
                    if (ddType == "rdpFormType")
                    {
                        using (var _dt1 = dm.GetFormsDropDownList())
                        {
                            if (_dt1 != null && _dt1.Rows.Count > 0)
                            {
                                result = DataTableToJSONWithJavaScriptSerializer(_dt1);
                            }
                        }
                    }
                    else
                    {
                        using (var _dt = dm.GetFormSectionDropDownList(Convert.ToInt32(ddType), Convert.ToInt32(roleId), 2))
                        {
                            result = DataTableToJSONWithJavaScriptSerializer(_dt);
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "LoadComboBox", "qry_GetFormsDropDown", stsId);
            }
            return result;
        }
        #endregion

        #region " LoadDropDownValues "
        /** \private    LoadDropDown 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
        */
        [WebMethod]
        public static string LoadDropDownValues(string ddType, int stsId)
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            try
            {
                #region " Try Block "
                /**Create DashboardManager object and bind values to dropdowns*/
                using (DropDownDataManager dmanager = new DropDownDataManager(Global.ABCConnectionString))
                {
                    var _dt1 = dmanager.GetAllDropDownDataByCategory(ddType);
                    if (_dt1 != null && _dt1.Rows.Count > 0)
                    {
                        result = DataTableToJSONWithJavaScriptSerializer(_dt1);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "LoadDropDownValues", "qry_GetDropdownDataByCategory", stsId);
            }
            return result;
        }
        #endregion

        #region " LoadFormQuestions "
        /** \private    LoadDropDown 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
*/
        [WebMethod]
        public static string LoadFormQuestions(int formId, int sectionId, int stsId)
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    var roleId = (Int32)Navigation.Current.CurrentRole;

                    using (var _dt1 = dm.GetFormQuestions(formId, sectionId, roleId))
                    {
                        if (_dt1 != null && _dt1.Rows.Count > 0)
                        {
                            result = DataTableToJSONWithJavaScriptSerializer(_dt1);
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "LoadFormQuestions", "qry_FormQuestionsBySectionId", stsId);
            }
            return result;
        }
        #endregion

        #region " LoadFormQuestionById "
        /** \private    LoadDropDown 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
*/
        [WebMethod]
        public static string LoadFormQuestionById(int questionId, int stsId)
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    var roleId = (Int32)Navigation.Current.CurrentRole;

                    using (var _dt1 = dm.GetFormQuestionById(questionId))
                    {
                        if (_dt1 != null && _dt1.Rows.Count > 0)
                        {
                            result = DataTableToJSONWithJavaScriptSerializer(_dt1);
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "LoadFormQuestionById", "qry_FormQuestionsById", stsId);
            }
            return result;
        }
        #endregion

        #region " UpdateformQuestion "
        /** \private    UpdateformQuestion 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
*/
        [WebMethod]
        public static string UpdateformQuestion(int questionId, string questionText, int isRequired)
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    dm.UpdateFormQuestions(questionId, questionText, isRequired, stsId);
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "UpdateformQuestion", "upd_FormQuestions", stsId);
            }
            return result;
        }
        #endregion

        #region " GetAllDropDownDataByCategory "
        [WebMethod]
        public static string GetAllDropDownDataByCategory(string category)
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (DropDownDataManager dm = new DropDownDataManager(Global.ABCConnectionString))
                {
                    var _dt1 = dm.GetAllDropDownDataByCategory(category);
                    if (_dt1 != null && _dt1.Rows.Count > 0)
                    {
                        result = DataTableToJSONWithJavaScriptSerializer(_dt1);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "GetAllDropDownDataByCategory", "qry_GetDropdownDataByCategory", stsId);
            }
            return result;
        }
        #endregion

        #region " UpdateDropdownValues "
        /** \private    UpdateDropdownValues 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
*/
        [WebMethod]
        public static string UpdateDropdownValues(string category, string ddValues)
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            var vzId = Navigation.Current.LoggedInVzid;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (DropDownDataManager dm = new DropDownDataManager(Global.ABCConnectionString))
                {
                    dm.UpdateDropdownData(category, ddValues, vzId);
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "UpdateDropdownValues", "upd_DropdownValues", stsId);
            }
            return result;
        }
        #endregion

        #region " DeleteDropdownVal "
        /** \private    DeleteDropdownVal 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
*/
        [WebMethod]
        public static string DeleteDropdownVal(int ddId)
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            var vzId = Navigation.Current.LoggedInVzid;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (DropDownDataManager dm = new DropDownDataManager(Global.ABCConnectionString))
                {
                    var _dt1 = dm.DeleteDropdownVal(ddId, vzId);
                    if (_dt1 != null && _dt1.Rows.Count > 0)
                    {
                        result = DataTableToJSONWithJavaScriptSerializer(_dt1);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "DeleteDropdownVal", "del_DropdownVal", stsId);
            }
            return result;
        }
        #endregion

        #region " GetAllDDCategories "
        [WebMethod]
        public static string GetAllDDCategories()
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (DropDownDataManager dm = new DropDownDataManager(Global.ABCConnectionString))
                {
                    var _dt1 = dm.GetDropDownCategories();
                    if (_dt1 != null && _dt1.Rows.Count > 0)
                    {
                        result = DataTableToJSONWithJavaScriptSerializer(_dt1);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "GetAllDDCategories", "qry_GetDropdownCategories", stsId);
            }
            return result;
        }
        #endregion

        #region " GetAllSections "
        [WebMethod]
        public static string GetAllSections()
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (DropDownDataManager dm = new DropDownDataManager(Global.ABCConnectionString))
                {
                    var _dt1 = dm.GetSectionsDropDown();
                    if (_dt1 != null && _dt1.Rows.Count > 0)
                    {
                        result = DataTableToJSONWithJavaScriptSerializer(_dt1);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "GetAllSections", "qry_GetFormSectionDropDown", stsId);
            }
            return result;
        }
        #endregion

        #region " InsertformQuestion "
        /// <summary>
        /// InsertformQuestion
        /// </summary>
        /// <param name="questionText"></param>
        /// <param name="ansControlType"></param>
        /// <param name="ddIdentifier"></param>
        /// <param name="isRequired"></param>
        /// <param name="formId"></param>
        /// <param name="sectionId"></param>
        /// <returns></returns>
        [WebMethod]
        public static string InsertformQuestion(string questionText, int ansControlType, string ddIdentifier, int isRequired, string formId, string sectionId)
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    dm.InsertFormQuestions(questionText, ansControlType, ddIdentifier, isRequired, formId, sectionId, stsId);
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "UpdateformQuestion", "upd_FormQuestions", stsId);
            }
            return result;
        }
        #endregion

        [WebMethod]
        public static bool UpdateSectionQuestionOrder(string sectionOrderInfo)
        {
            var result = true;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (SectionManager dm = new SectionManager(Global.ABCConnectionString))
                {
                    dm.UpdateSectionQuestionOrder(sectionOrderInfo, stsId);
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "UpdateSectionQuestionOrder", "upd_SectionQuestionOrder", stsId);
                result = false;
            }
            return result;
        }

        #endregion
    }
}