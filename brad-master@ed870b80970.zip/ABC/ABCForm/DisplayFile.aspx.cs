﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using Telerik.Web.UI;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using BusinessLogicLayer;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using System.Collections.Specialized;
using Common;
using Verizon.QueryStringEncryption;

namespace ABC.ABCForm
{
    public partial class DisplayFile : System.Web.UI.Page
    {
        private int _attachmentId = -1;
        private string _attachmentName = string.Empty;
        private int _attachmentType = -1;
      
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Request.QueryString["request"] != null)
            {
                NameValueCollection decryptedQueryStrings = CryptoQueryStringHandler.GetDecryptedQueryStrings(Request.QueryString["request"]);
                //NameValueCollection decryptedQueryStrings = new NameValueCollection();
                //decryptedQueryStrings.Add("attachmentId", Request.QueryString["attachmentId"].ToString());
                //decryptedQueryStrings.Add("attachmentName", Request.QueryString["attachmentName"].ToString());

                if (decryptedQueryStrings["attachmentId"] != null && !string.IsNullOrEmpty(decryptedQueryStrings["attachmentId"]))
                {
                    int dummy;
                    if (!Int32.TryParse(decryptedQueryStrings["attachmentId"], out dummy))
                    {
                        _attachmentId = -1;
                    }
                    else
                    {
                        _attachmentId = dummy;
                    }
                }
                if (decryptedQueryStrings["attachmentType"] != null && !string.IsNullOrEmpty(decryptedQueryStrings["attachmentType"]))
                {
                    int dummy;
                    if (!Int32.TryParse(decryptedQueryStrings["attachmentType"], out dummy))
                    {
                        _attachmentType = -1;
                    }
                    else
                    {
                        _attachmentType = dummy;
                    }
                }
                if (decryptedQueryStrings["attachmentName"] != null && !string.IsNullOrEmpty(decryptedQueryStrings["attachmentName"]))
                {
                    _attachmentName = decryptedQueryStrings["attachmentName"];
                }

            }

            //int attachmentId = Convert.ToInt32(Request.QueryString["attachmentId"]);
            
            DataTable dt_AttachmentDataTable = new DataTable();
            DataTable dt_FileAttachments = new DataTable();            

            byte[] bFileData = new byte[0];  // The BLOB byte[] buffer to be filled by GetBytes.

            using (AttachmentManager am = new AttachmentManager(Global.ABCConnectionString))
            {
                using (System.Data.DataTable _dt = am.GetAttachmentsByID(_attachmentId))
                {
                    dt_AttachmentDataTable = _dt;
                }
            }
            if ((dt_AttachmentDataTable.Rows.Count > 0 && dt_AttachmentDataTable.Rows[0]["Attachment"].ToString().Length > 0))
            {
                string fileName = dt_AttachmentDataTable.Rows[0]["AttachmentName"].ToString();
                string fileExt = fileName.Substring(fileName.Length - 3);

                bFileData = (byte[])dt_AttachmentDataTable.Rows[0]["Attachment"];
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("Accept-Header", bFileData.Length.ToString());
                Response.AddHeader("Content-Length", bFileData.Length.ToString());
                Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);
                Response.AddHeader("Expires", "0");
                Response.AddHeader("Pragma", "cache");
                Response.AddHeader("Cache-Control", "private");
                
                //Set the output stream to the correct content type
                switch (fileExt)
                {
                    case "pdf":
                        Response.ContentType = "application/pdf";
                        break;
                    case "doc":
                        Response.ContentType = "application/msword";
                        break;
                    case "docx":
                        Response.ContentType = "application/msword";
                        break;
                    case "xls":
                        Response.ContentType = "application/vnd.ms-excel";
                        break;
                    case "xlsx":
                        Response.ContentType = "application/vnd.ms-excel";
                        break;
                    case "msg":
                        Response.ContentType = "application/vnd.ms-outlook";
                        break;
                }
                
                Response.AddHeader("Accept-Ranges", "bytes");
                Response.BinaryWrite(bFileData);
                try { Response.End(); }
                catch { }
            } 
        }
    }
}
