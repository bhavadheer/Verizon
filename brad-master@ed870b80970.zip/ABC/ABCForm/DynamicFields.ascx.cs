﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using BusinessLogicLayer;
using Common;
using System.Web.Services;
using System.Web.Script.Services;
using System.Data;
using System.IO;
using System.Collections.Specialized;
using Verizon.QueryStringEncryption;
using System.Text.RegularExpressions;
using System.Configuration;
using System.Globalization;
using System.Web.Configuration;

namespace ABC.ABCForm
{
    public partial class DynamicFields : System.Web.UI.UserControl
    {
        #region " Public Properties "

        public int SectionId { get; set; }

        public int FormId { get; set; }

        public int Count { get; set; }

        private bool _ReadOnly = false;
        public bool ReadOnly
        {
            get
            {
                return _ReadOnly;
            }
            set
            {
                _ReadOnly = value;
            }
        }

        private string FormInstance
        {
            get
            {
                if (Session["FormInstance"] != null)
                {
                    return Session["FormInstance"].ToString();
                }

                return string.Empty;
            }
            set
            {
                Session["FormInstance"] = value;
            }
        }

        private bool _IsValid = true;
        public bool IsValid
        {
            get { return _IsValid; }
            private set { _IsValid = value; }
        }

        #region " Answers "
        /// <summary>
        /// Answers
        /// </summary>
        public IEnumerable<DynamicField> Answers
        {
            get
            {
                var ans = new List<DynamicField>();

                using (ControlFinder<HiddenField> hfcf = new ControlFinder<HiddenField>())
                {
                    hfcf.FindChildControlsRecursive(phDynFields);

                    var btnList = hfcf.FoundControls;
                    foreach (HiddenField hf in btnList)
                    {
                        using (var dynamicField = new DynamicField { Id = hf.ID, Form = FormId, Sec = SectionId, CtrlType = DynControlType.Button, Text = hf.Value, FieldData = hf.Value })
                        {
                            ans.Add(dynamicField);
                        }
                    }
                }

                using (ControlFinder<RadAsyncUpload> aucf = new ControlFinder<RadAsyncUpload>())
                {
                    aucf.FindChildControlsRecursive(phDynFields);

                    var uploadList = aucf.FoundControls;
                    foreach (RadAsyncUpload uf in uploadList)
                    {
                        using (var dynamicField = new DynamicField { Id = uf.ID, Form = FormId, Sec = SectionId, CtrlType = DynControlType.Attachment, Text = uf.UploadedFiles.Count.ToString(), FieldData = uf.UploadedFiles })
                        {
                            ans.Add(dynamicField);
                        }
                    }
                }

                using (ControlFinder<CheckBoxList> cbcf = new ControlFinder<CheckBoxList>())
                {
                    cbcf.FindChildControlsRecursive(phDynFields);
                    var chkList = cbcf.FoundControls;
                    foreach (CheckBoxList cb in chkList)
                    {
                        var _checked = String.Join(",", cb.Items.OfType<ListItem>().Where(r => r.Selected).Select(r => r.Text));
                        using (var dynamicField = new DynamicField { Id = cb.ID, Form = FormId, Sec = SectionId, CtrlType = DynControlType.CheckBox, Text = cb.Text, FieldData = _checked })
                        {
                            ans.Add(dynamicField);
                        }
                    }
                }

                using (ControlFinder<RadDatePicker> dpkcf = new ControlFinder<RadDatePicker>())
                {
                    dpkcf.FindChildControlsRecursive(phDynFields);
                    var dpkList = dpkcf.FoundControls;
                    foreach (RadDatePicker dp in dpkList)
                    {
                        var temp = string.Empty;
                        if (dp.SelectedDate != null)
                        {
                            var dt = Convert.ToDateTime(dp.SelectedDate);
                            temp = dt.ToShortDateString();
                        }
                        using (var dynamicField = new DynamicField { Id = dp.ID, Form = FormId, Sec = SectionId, CtrlType = DynControlType.DatePicker, Text = temp, FieldData = temp })
                        {
                            ans.Add(dynamicField);
                        }
                    }
                }

                using (ControlFinder<DropDownList> ddcf = new ControlFinder<DropDownList>())
                {
                    ddcf.FindChildControlsRecursive(phDynFields);
                    var ddList = ddcf.FoundControls;
                    foreach (DropDownList dd in ddList)
                    {
                        using (var dynamicField = new DynamicField { Id = dd.ID, Form = FormId, Sec = SectionId, CtrlType = DynControlType.DropDown, Text = dd.Text, FieldData = dd.SelectedValue })
                        {
                            ans.Add(dynamicField);
                        }
                    }
                }

                using (ControlFinder<RadioButtonList> rblcf = new ControlFinder<RadioButtonList>())
                {
                    rblcf.FindChildControlsRecursive(phDynFields);
                    var rblList = rblcf.FoundControls;
                    foreach (RadioButtonList rbl in rblList)
                    {
                        using (var dynamicField = new DynamicField { Id = rbl.ID, Form = FormId, Sec = SectionId, CtrlType = DynControlType.Radio, Text = rbl.Text, FieldData = rbl.SelectedValue })
                        {
                            ans.Add(dynamicField);
                        }
                    }
                }

                using (ControlFinder<TextBox> tbcf = new ControlFinder<TextBox>())
                {
                    tbcf.FindChildControlsRecursive(phDynFields);
                    var tbList = tbcf.FoundControls;
                    foreach (TextBox tb in tbList)
                    {
                        using (var dynamicField = new DynamicField { Id = tb.ID, Form = FormId, Sec = SectionId, CtrlType = DynControlType.TextBox, Text = tb.Text, FieldData = tb.Text })
                        {
                            ans.Add(dynamicField);
                        }
                    }
                }

                return ans;
            }
        }
        #endregion

        #region " Validation "
        /// <summary>
        /// Validation
        /// </summary>
        public int Validation
        {
            get
            {
                var badCount = 0;

                //ToDo: Button Editing - Check HiddenField
                //ControlFinder<HiddenField> hfcf = new ControlFinder<HiddenField>();
                //hfcf.FindChildControlsRecursive(phDynFields);
                //IEnumerable<HiddenField> btnList = hfcf.FoundControls;
                //foreach (HiddenField hf in btnList)
                //{
                //    if (String.IsNullOrEmpty(hf.Value))
                //    {
                //        ((Button)((TableCell)hf.Parent).FindControl(String.Format("{0}_btn", hf.ID))).CssClass = "dyn_field_yellow";
                //        badCount++;
                //    }
                //    else
                //    {
                //        ((Button)((TableCell)hf.Parent).FindControl(String.Format("{0}_btn", hf.ID))).CssClass = String.Empty;
                //    }
                //}

                using (ControlFinder<CheckBoxList> cbcf = new ControlFinder<CheckBoxList>())
                {
                    cbcf.FindChildControlsRecursive(phDynFields);
                    var chkList = cbcf.FoundControls;
                    foreach (CheckBoxList cb in chkList)
                    {
                        var _checked = String.Join(",", cb.Items.OfType<ListItem>().Where(r => r.Selected).Select(r => r.Text));
                        if (cb.Attributes["isrequired"] == "true" && String.IsNullOrEmpty(_checked))
                        {
                            ((CheckBoxList)cb).CssClass = "dyn_field_yellow";
                            badCount++;
                        }
                        else
                        {
                            ((CheckBoxList)cb).CssClass = String.Empty;
                        }
                    }
                }

                using (ControlFinder<RadDatePicker> dpkcf = new ControlFinder<RadDatePicker>())
                {
                    dpkcf.FindChildControlsRecursive(phDynFields);
                    var dpkList = dpkcf.FoundControls;
                    foreach (RadDatePicker dp in dpkList)
                    {
                        if (dp.Attributes["isrequired"] == "true" && dp.SelectedDate == null)
                        {
                            ((RadDatePicker)dp).DateInput.CssClass = "dyn_field_yellow";
                            ((RadDatePicker)dp).CssClass = "dyn_field_yellow";
                            badCount++;
                        }
                        else
                        {
                            ((RadDatePicker)dp).DateInput.CssClass = String.Empty;
                            ((RadDatePicker)dp).CssClass = string.Empty;
                        }
                    }
                }

                using (ControlFinder<DropDownList> ddcf = new ControlFinder<DropDownList>())
                {
                    ddcf.FindChildControlsRecursive(phDynFields);
                    var ddList = ddcf.FoundControls;
                    //var dddd = ddList.Select(a => a.Attributes["isrequired"] == "true");
                    foreach (DropDownList dd in ddList)
                    {
                        if (dd.Attributes["isrequired"] == "true" && (String.IsNullOrEmpty(dd.SelectedValue) || dd.SelectedIndex == 0))
                        {
                            ((DropDownList)dd).CssClass = "dyn_field_yellow";
                            badCount++;
                        }
                        else
                        {
                            ((DropDownList)dd).CssClass = String.Empty;
                        }
                    }
                }

                using (ControlFinder<RadioButtonList> rblcf = new ControlFinder<RadioButtonList>())
                {
                    rblcf.FindChildControlsRecursive(phDynFields);
                    var rblList = rblcf.FoundControls;
                    foreach (RadioButtonList rbl in rblList)
                    {
                        if (rbl.Attributes["isrequired"] == "true" && String.IsNullOrEmpty(rbl.SelectedValue))
                        {
                            ((RadioButtonList)rbl).CssClass = "dyn_field_yellow";
                            badCount++;
                        }
                        else
                        {
                            ((RadioButtonList)rbl).CssClass = String.Empty;
                        }
                    }
                }

                using (ControlFinder<TextBox> tbcf = new ControlFinder<TextBox>())
                {
                    tbcf.FindChildControlsRecursive(phDynFields);
                    var tbList = tbcf.FoundControls;
                    foreach (TextBox tb in tbList)
                    {
                        if (tb.Attributes["isrequired"] == "true" && String.IsNullOrEmpty(tb.Text))
                        {
                            ((TextBox)tb).CssClass = "dyn_field_yellow";
                            badCount++;
                        }
                        else
                        {
                            ((TextBox)tb).CssClass = String.Empty;
                        }
                    }
                }
                return badCount;
            }
        }
        #endregion

        #endregion

        #region " Events "

        #region " Page_Init "
        /// <summary>
        /// Page_Init
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Init(object sender, EventArgs e)
        {
            var roleId = Convert.ToInt32(Navigation.Current.CurrentRole);
            using (FormManager refMgr = new FormManager(Global.ABCConnectionString))
            {
                var dynamicFields = refMgr.GetDynamicFields(FormId, SectionId, roleId, FormInstance);

                Count = dynamicFields.Count();

                SetDynamicFields(dynamicFields);

                if (Session["NewAddedFields"] != null)
                {
                    SetExtraControls();
                }
            }
        }
        #endregion

        #region " Page_Load "
        /// <summary>
        /// Page_Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Session["NewAddedFields"] = null;
            }
        }
        #endregion

        #endregion

        #region " Protected Methods "

        #region " SetDynamicFields "
        /// <summary>
        /// SetDynamicFields
        /// </summary>
        /// <param name="dynamicFields"></param>
        protected void SetDynamicFields(IEnumerable<DynamicField> dynamicFields)
        {
            var badCount = 0;
            using (Table base_tbl = new Table())
            {
                base_tbl.CssClass = "table table-bordered";

                //Header Row - Column Titles
                using (TableHeaderRow tr = new TableHeaderRow())
                {
                    using (TableHeaderCell th = new TableHeaderCell())
                    {
                        using (var label = new Label { Text = "S.No" })
                        {
                            th.Controls.Add(label);
                        }
                        th.Width = Unit.Percentage(5);
                        tr.Controls.Add(th);
                    }

                    using (TableHeaderCell th = new TableHeaderCell())
                    {
                        using (var label = new Label { Text = "Question" })
                        {
                            th.Controls.Add(label);
                        }
                        th.Width = Unit.Percentage(75);
                        tr.Controls.Add(th);
                    }
                    using (TableHeaderCell td = new TableHeaderCell())
                    {
                        using (var label = new Label { Text = "Response" })
                        {
                            td.Controls.Add(label);
                        }
                        td.Width = Unit.Percentage(20);
                        tr.Controls.Add(td);
                    }
                    base_tbl.Controls.Add(tr);
                }

                foreach (DynamicField df in dynamicFields)
                {
                    switch (df.CtrlType)
                    {
                        case DynControlType.Attachment://Create Row
                            {
                                using (TableRow tr = new TableRow())
                                {

                                    //Column 1
                                    using (TableCell th = new TableCell())
                                    {
                                        using (var label = new Label { Text = String.Format("{0}", df.QuestionNumber) })
                                        {
                                            th.Controls.Add(label);
                                        }
                                        tr.Controls.Add(th);
                                    }

                                    //Column 2
                                    using (TableCell th = new TableCell())
                                    {
                                        using (var label = new Label { Text = df.Text })
                                        {
                                            th.Controls.Add(label);
                                        }
                                        tr.Controls.Add(th);
                                    }

                                    //Column 3
                                    if (!ReadOnly)
                                    {
                                        //Edit Cell
                                        var td = new TableCell();
                                        var upload = new RadAsyncUpload
                                        {
                                            //Button btn = new Button();
                                            ID = df.Id.ToString(),
                                            MultipleFileSelection = Telerik.Web.UI.AsyncUpload.MultipleFileSelection.Automatic,
                                            OnClientFilesUploaded = "SetFormDataCheck",
                                            ClientIDMode = ClientIDMode.Static
                                        };
                                        upload.Localization.Select = "Attach File";
                                        upload.TemporaryFolder = Path.Combine(Global.TempPathForFile, "UploadTemp");
                                        var ext = ".pdf,.doc,.docx,.xls,.xlsx,.msg,.txt,.jpg,.htm,.html";
                                        upload.AllowedFileExtensions = ext.Split(',').ToArray();
                                        //upload.TargetFolder = Global.TempPathForFile;
                                        //SetButton(btn, df.BtnType);
                                        td.Controls.Add(upload);

                                        #region " Creating a grid to show the attached files "

                                        var gridAttachments = new RadGrid
                                        {
                                            ID = "gridAttachments" + df.Id.ToString(),
                                            AutoGenerateColumns = false,
                                            GridLines = GridLines.None
                                        };
                                        //gridAttachments.MasterTableView.Width = Unit.Percentage(100);
                                        gridAttachments.MasterTableView.DataKeyNames = new string[] { "AttachmentId" };
                                        var boundColumn = new GridBoundColumn
                                        {
                                            DataField = "AttachmentId",
                                            UniqueName = "AttachmentId",
                                            Display = false
                                        };
                                        gridAttachments.MasterTableView.Columns.Add(boundColumn);
                                        var nameColumn = new GridHyperLinkColumn
                                        {
                                            DataTextField = "AttachmentName",
                                            UniqueName = "AttachmentName",
                                            HeaderText = "Attachment Name"
                                        };
                                        gridAttachments.MasterTableView.Columns.Add(nameColumn);

                                        var deletebtn = new GridButtonColumn
                                        {
                                            UniqueName = "DeleteColumn",
                                            Text = "Delete",
                                            CommandName = "Delete",
                                            HeaderText = "Delete",
                                            ButtonType = GridButtonColumnType.ImageButton,
                                            ConfirmText = "Are you sure to Delete this Attachment?",
                                            ImageUrl = "../Content/images/Delete.gif"
                                        };
                                        gridAttachments.MasterTableView.Columns.Add(deletebtn);
                                        gridAttachments.ItemCommand += new GridCommandEventHandler(gridAttachments_ItemCommand);
                                        gridAttachments.ItemDataBound += new GridItemEventHandler(gridAttachments_ItemDataBound);
                                        //gridAttachments.NeedDataSource += new GridNeedDataSourceEventHandler(grdAttachments_NeedDataSource);
                                        gridAttachments.Visible = false;
                                        #endregion

                                        if (!String.IsNullOrEmpty(FormInstance))
                                        {
                                            using (AttachmentManager am = new AttachmentManager(Global.ABCConnectionString))
                                            {
                                                using (DataTable _dt = am.LoadAttachments(Convert.ToInt32(df.Id.ToString()), FormInstance, (int)AttachmentIdentifier.QuestionLevel))
                                                {
                                                    if (_dt != null && _dt.Rows.Count > 0)
                                                    {

                                                        gridAttachments.DataSource = _dt;
                                                        gridAttachments.DataBind();
                                                        gridAttachments.Visible = true;
                                                    }
                                                }
                                            }
                                        }
                                        td.Controls.Add(gridAttachments);
                                        tr.Controls.Add(td);

                                        //HiddenField hf = new HiddenField();
                                        //hf.ID = "att" + df.Id.ToString();
                                        //td.Controls.Add(hf);
                                        //tr.Controls.Add(td);
                                        if (!df.IsReadonly)
                                        {
                                            upload.Enabled = false;
                                        }
                                    }
                                    else
                                    {
                                        //ReadOnly Cell
                                        using (TableCell td = new TableCell())
                                        {
                                            if (!String.IsNullOrEmpty(FormInstance))
                                            {
                                                using (AttachmentManager am = new AttachmentManager(Global.ABCConnectionString))
                                                {
                                                    using (DataTable _dt = am.LoadAttachments(Convert.ToInt32(df.Id.ToString()), FormInstance, (int)AttachmentIdentifier.QuestionLevel))
                                                    {
                                                        if (_dt != null && _dt.Rows.Count > 0)
                                                        {
                                                            for (int i = 0; i < _dt.Rows.Count; i++)
                                                            {
                                                                var lnkAttachmentName = new HyperLink();
                                                                var parameters = new NameValueCollection();
                                                                parameters.Add("attachmentId", RemoveInvalidChar(_dt.Rows[i]["AttachmentId"].ToString()));
                                                                parameters.Add("attachmentName", RemoveInvalidChar(_dt.Rows[i]["AttachmentName"].ToString()));
                                                                var querystring = EncryptQueryString(parameters);
                                                                var urlstring = "~/ABCForm/DisplayFile.aspx?" + querystring;
                                                                lnkAttachmentName.Text = _dt.Rows[i]["AttachmentName"].ToString();
                                                                lnkAttachmentName.NavigateUrl = urlstring;
                                                                lnkAttachmentName.Target = "_blank";
                                                                td.Controls.Add(lnkAttachmentName);
                                                                using (var literalControl = new LiteralControl("<br />"))
                                                                {
                                                                    td.Controls.Add(literalControl);
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            //td.Controls.Add(new Label() { Text = df.FieldData.ToString() });
                                            tr.Controls.Add(td);
                                        }
                                    }

                                    //Add Row to Table
                                    base_tbl.Controls.Add(tr);
                                }
                            }
                            break;
                        case DynControlType.Button:
                            {
                                //Create Row
                                using (TableRow tr = new TableRow())
                                {

                                    //Column 1
                                    using (TableCell th = new TableCell())
                                    {
                                        using (var label = new Label { Text = String.Format("{0}", df.QuestionNumber) })
                                        {
                                            th.Controls.Add(label);
                                        }
                                        tr.Controls.Add(th);
                                    }

                                    //Column 2
                                    using (TableCell th = new TableCell())
                                    {
                                        using (var label = new Label { Text = df.Text })
                                        {
                                            th.Controls.Add(label);
                                        }
                                        tr.Controls.Add(th);
                                    }

                                    //Column 3
                                    if (!ReadOnly)
                                    {
                                        //Edit Cell
                                        var td = new TableCell();
                                        var btn = new Button
                                        {
                                            ID = df.Id.ToString(),
                                            Text = "Attach File"
                                        };
                                        SetButton(btn, df.BtnType);
                                        td.Controls.Add(btn);

                                        var hf = new HiddenField
                                        {
                                            ID = df.Id.ToString()
                                        };
                                        td.Controls.Add(hf);
                                        tr.Controls.Add(td);
                                        if (!df.IsReadonly)
                                        {
                                            btn.Enabled = false;
                                        }
                                    }
                                    else
                                    {
                                        //ReadOnly Cell
                                        using (TableCell td = new TableCell())
                                        {
                                            using (var label = new Label { Text = df.FieldData.ToString() })
                                            {
                                                td.Controls.Add(label);
                                            }
                                            tr.Controls.Add(td);
                                        }
                                    }

                                    //Add Row to Table
                                    base_tbl.Controls.Add(tr);
                                }
                            }
                            break;

                        case DynControlType.CheckBox:
                            {
                                //Create Row
                                var tr = new TableRow();

                                //Column 1
                                {
                                    var th = new TableCell();
                                    using (var label = new Label { Text = String.Format("{0}", df.QuestionNumber) })
                                    {
                                        th.Controls.Add(label);
                                    }
                                    tr.Controls.Add(th);
                                }

                                //Column 2
                                {
                                    var th = new TableCell();
                                    using (var label = new Label { Text = df.Text })
                                    {
                                        th.Controls.Add(label);
                                    }
                                    tr.Controls.Add(th);
                                }

                                //Column 3
                                if (!ReadOnly)
                                {
                                    var td = new TableCell();
                                    var cb1 = new CheckBoxList
                                    {
                                        ID = df.Id.ToString(),
                                        Width = Unit.Pixel(400),
                                        ClientIDMode = ClientIDMode.Static
                                    };
                                    if (!string.IsNullOrEmpty(df.DdType))
                                    {
                                        SetCheckBoxItems(cb1, df.DdType);
                                        if (!String.IsNullOrEmpty(df.FieldData.ToString()))
                                        {
                                            foreach (ListItem a in cb1.Items)
                                            {
                                                a.Attributes.Add("onChange", "SetFormDataCheck()");
                                                if (df.FieldData.ToString().Split(',').Contains(a.Value))
                                                {
                                                    a.Selected = true;
                                                }
                                            }
                                        }
                                        td.Controls.Add(cb1);
                                        tr.Controls.Add(td);
                                        if (df.IsRequired)
                                        {
                                            cb1.Attributes.Add("IsRequired", "true");
                                            if (cb1.SelectedItem == null)
                                            {
                                                ((CheckBoxList)cb1).CssClass = "dyn_field_yellow";
                                                badCount++;
                                            }
                                        }
                                    }
                                    //else
                                    //{
                                    //    cb1.Items.Add(new ListItem() { Text = "", Value = "1" });
                                    //}
                                    if (!df.IsReadonly)
                                    {
                                        cb1.Enabled = false;
                                    }
                                }
                                else
                                {
                                    //ReadOnly Cell
                                    var td = new TableCell();
                                    //td.Controls.Add(new Label() { Text = df.FieldData.ToString() });

                                    if (!String.IsNullOrEmpty(df.FieldData.ToString()) && df.FieldData.ToString() != "-1")
                                    {
                                        var cb1 = new CheckBoxList();
                                        SetCheckBoxItems(cb1, df.DdType);
                                        cb1.SelectedValue = df.FieldData.ToString();
                                        if (!string.IsNullOrEmpty(cb1.SelectedValue))
                                        {
                                            using (var label = new Label { Text = cb1.SelectedItem.Text })
                                            {
                                                td.Controls.Add(label);
                                            }
                                        }
                                    }
                                    tr.Controls.Add(td);
                                }

                                //Add Row to Table
                                base_tbl.Controls.Add(tr);
                            }
                            break;

                        case DynControlType.DatePicker:
                            {
                                //Create Row
                                var tr = new TableRow();

                                //Column 1
                                {
                                    var th = new TableCell();
                                    using (var label = new Label { Text = String.Format("{0}", df.QuestionNumber) })
                                    {
                                        th.Controls.Add(label);
                                    }
                                    tr.Controls.Add(th);
                                }

                                //Column 2
                                {
                                    var th = new TableCell();
                                    using (var label = new Label { Text = df.Text })
                                    {
                                        th.Controls.Add(label);
                                    }
                                    tr.Controls.Add(th);
                                }

                                //Column 3
                                if (!ReadOnly)
                                {
                                    var td = new TableCell();
                                    var rdp = new RadDatePicker();
                                    rdp.ID = df.Id.ToString();
                                    rdp.SkipMinMaxDateValidationOnServer = true;
                                    rdp.Width = Unit.Pixel(405);
                                    rdp.Culture = rdp.UKDate();
                                    rdp.ClientEvents.OnDateSelected = "SetFormDataCheck";
                                    //rdp.Attributes.Add("OnDateSelected", "SetFormDataCheck");
                                    if (!string.IsNullOrEmpty(df.FieldData.ToString()))
                                    {
                                        rdp.SelectedDate = Convert.ToDateTime(df.FieldData.ToString());
                                    }
                                    td.Controls.Add(rdp);
                                    tr.Controls.Add(td);
                                    if (df.IsRequired)
                                    {
                                        rdp.Attributes.Add("IsRequired", "true");
                                        if (rdp.SelectedDate == null || rdp.SelectedDate.GetValueOrDefault() == DateTime.MinValue)
                                        {
                                            ((RadDatePicker)rdp).CssClass = "dyn_field_yellow";
                                            ((RadDatePicker)rdp).DateInput.CssClass = "dyn_field_yellow";
                                            badCount++;
                                        }
                                    }
                                    if (!df.IsReadonly)
                                    {
                                        rdp.Enabled = false;
                                    }
                                }
                                else
                                {
                                    //ReadOnly Cell
                                    var td = new TableCell();
                                    if (!string.IsNullOrEmpty(df.FieldData.ToString()))
                                    {
                                        DateTime dt;
                                        var formats = new[] { "dd/MM/yyyy", "yyyy-MM-dd", "MM/dd/yyyy", "d/M/yyyy", "M/d/yyyy" };
                                        if (DateTime.TryParseExact(df.FieldData.ToString(), formats, CultureInfo.InvariantCulture, DateTimeStyles.None, out dt))
                                        {
                                            using (var label = new Label { Text = dt.Day > 12 ? dt.UKDate() : dt.ToShortDateString() })
                                            {
                                                td.Controls.Add(label);
                                            }
                                        }

                                        //DateTime dt = Convert.ToDateTime(df.FieldData.ToString());


                                    }
                                    tr.Controls.Add(td);
                                }

                                //Add Row to Table
                                base_tbl.Controls.Add(tr);
                            }
                            break;

                        case DynControlType.DropDown:
                            {
                                //Create Row
                                var tr = new TableRow();

                                //Column 1
                                {
                                    var th = new TableCell();
                                    using (var label = new Label { Text = String.Format("{0}", df.QuestionNumber) })
                                    {
                                        th.Controls.Add(label);
                                    }
                                    tr.Controls.Add(th);
                                }

                                //Column 2
                                {
                                    var th = new TableCell();
                                    using (var label = new Label { Text = df.Text })
                                    {
                                        th.Controls.Add(label);
                                    }
                                    tr.Controls.Add(th);
                                }

                                //Column 3
                                if (!ReadOnly)
                                {
                                    var td = new TableCell();
                                    var ddl = new DropDownList
                                    {
                                        ID = df.Id.ToString(),
                                        Width = Unit.Pixel(401),
                                        ClientIDMode = ClientIDMode.Static
                                    };
                                    using (FormManager fm = new BusinessLogicLayer.FormManager(Global.ABCConnectionString))
                                    {
                                        var dt = fm.CheckDropDownDependency(Convert.ToInt32(df.Id));
                                        if (dt != null && dt.Rows.Count > 0)
                                        {
                                            ddl.Attributes.Add("onChange", "SetISGRiskUserData('" + dt.Rows[0]["DepFromSectionID"].ToString() + "', '" + df.Id + "')");
                                        }
                                        else
                                        {
                                            ddl.Attributes.Add("onChange", "SetFormDataCheck()");
                                        }
                                    }
                                    LoadDropDownData(ddl, df.DdType);
                                    if (!String.IsNullOrEmpty(df.FieldData.ToString()))
                                        ddl.SelectedValue = df.FieldData.ToString();
                                    td.Controls.Add(ddl);
                                    tr.Controls.Add(td);
                                    if (df.IsRequired)
                                    {
                                        ddl.Attributes.Add("IsRequired", "true");
                                        if (ddl.SelectedIndex == 0)
                                        {
                                            ((DropDownList)ddl).CssClass = "dyn_field_yellow";
                                            badCount++;
                                        }
                                    }
                                    if (!df.IsReadonly)
                                    {
                                        ddl.Enabled = false;
                                    }
                                }
                                else
                                {
                                    //ReadOnly Cell
                                    var td = new TableCell();
                                    if (!String.IsNullOrEmpty(df.FieldData.ToString()) && df.FieldData.ToString() != "-1")
                                    {
                                        var ddl = new DropDownList();
                                        LoadDropDownData(ddl, df.DdType);
                                        ddl.SelectedValue = df.FieldData.ToString();
                                        using (var label = new Label { Text = ddl.SelectedItem.Text })
                                        {
                                            td.Controls.Add(label);
                                        }
                                    }
                                    tr.Controls.Add(td);
                                }

                                //Add Row to Table
                                base_tbl.Controls.Add(tr);
                            }
                            break;

                        case DynControlType.Radio:
                            {
                                //Create Row
                                var tr = new TableRow();

                                //Column 1
                                {
                                    var th = new TableCell();
                                    using (var label = new Label { Text = String.Format("{0}", df.QuestionNumber) })
                                    {
                                        th.Controls.Add(label);
                                    }
                                    tr.Controls.Add(th);
                                }

                                //Column 2
                                {
                                    var th = new TableCell();
                                    using (var label = new Label { Text = df.Text })
                                    {
                                        th.Controls.Add(label);
                                    }
                                    tr.Controls.Add(th);
                                }

                                //Column 3
                                if (!ReadOnly)
                                {
                                    var td = new TableCell();
                                    var rb1 = new RadioButtonList
                                    {
                                        ID = df.Id.ToString(),
                                        Width = Unit.Pixel(400),
                                        ClientIDMode = ClientIDMode.Static
                                    };
                                    //SetRadionButtonItems(rb1, df);
                                    td.Controls.Add(rb1);
                                    tr.Controls.Add(td);
                                    SetRadionButtonItems(rb1, df.DdType);// "RiskLevelCheck");
                                    if (!String.IsNullOrEmpty(df.FieldData.ToString()))
                                    {
                                        foreach (ListItem a in rb1.Items)
                                        {
                                            a.Attributes.Add("onChange", "SetFormDataCheck()");
                                            if (df.FieldData.ToString().Split(',').Contains(a.Value))
                                            {
                                                a.Selected = true;
                                            }
                                        }
                                    }
                                    if (df.IsRequired)
                                    {
                                        rb1.Attributes.Add("IsRequired", "true");
                                        if (rb1.SelectedItem == null)
                                        {
                                            ((RadioButtonList)rb1).CssClass = "dyn_field_yellow";
                                            badCount++;
                                        }
                                    }
                                    if (!df.IsReadonly)
                                    {
                                        rb1.Enabled = false;
                                    }
                                }
                                else
                                {
                                    //ReadOnly Cell
                                    var td = new TableCell();
                                    //td.Controls.Add(new Label() { Text = df.FieldData.ToString() });

                                    var cb1 = new RadioButtonList();
                                    SetRadionButtonItems(cb1, df.DdType);
                                    cb1.SelectedValue = df.FieldData.ToString();
                                    if (!string.IsNullOrEmpty(cb1.SelectedValue))
                                    {
                                        using (var label = new Label { Text = cb1.SelectedItem.Text })
                                        {
                                            td.Controls.Add(label);
                                        }
                                    }

                                    tr.Controls.Add(td);
                                }

                                //Add Row to Table
                                base_tbl.Controls.Add(tr);
                            }
                            break;

                        case DynControlType.TextBox:
                            {
                                //Create Row
                                var tr = new TableRow();

                                //Column 1
                                {
                                    var th = new TableCell();
                                    using (var label = new Label { Text = String.Format("{0}", df.QuestionNumber) })
                                    {
                                        th.Controls.Add(label);
                                    }
                                    tr.Controls.Add(th);
                                }

                                //Column 2
                                {
                                    var th = new TableCell();
                                    using (var label = new Label { Text = df.Text })
                                    {
                                        th.Controls.Add(label);
                                    }
                                    tr.Controls.Add(th);
                                }

                                //Column 3
                                if (!ReadOnly)
                                {
                                    var td = new TableCell();
                                    var tb = new TextBox
                                    {
                                        TextMode = TextBoxMode.MultiLine,
                                        Rows = 4,
                                        ID = df.Id.ToString(),
                                        ClientIDMode = ClientIDMode.Static
                                    };
                                    if (!string.IsNullOrEmpty(df.FieldData.ToString()))
                                        tb.Text = df.FieldData.ToString().HtmlDecode();
                                    tb.Width = Unit.Pixel(397);
                                    ((TextBox)tb).CssClass = "inputClass";
                                    if (df.IsRequired)
                                    {
                                        tb.Attributes.Add("IsRequired", "true");
                                        if (string.IsNullOrEmpty(tb.Text))
                                        {
                                            ((TextBox)tb).CssClass = "dyn_field_yellow";
                                            badCount++;
                                        }
                                    }
                                    tb.Attributes.Add("onChange", "SetFormDataCheck()");
                                    td.Controls.Add(tb);
                                    tr.Controls.Add(td);
                                    if (!df.IsReadonly)
                                    {
                                        tb.Enabled = false;
                                    }
                                }
                                else
                                {
                                    //ReadOnly Cell
                                    var td = new TableCell();
                                    using (var label = new Label { Text = df.FieldData.ToString().HtmlDecode() })
                                    {
                                        td.Controls.Add(label);
                                    }
                                    tr.Controls.Add(td);
                                }

                                //Add Row to Table
                                base_tbl.Controls.Add(tr);
                            }
                            break;
                        case DynControlType.FormNumber:
                            {
                                //Create Row
                                var tr = new TableRow();

                                //Column 1
                                {
                                    var th = new TableCell();
                                    using (var label = new Label { Text = String.Format("{0}", df.QuestionNumber) })
                                    {
                                        th.Controls.Add(label);
                                    }
                                    tr.Controls.Add(th);
                                }

                                //Column 2
                                {
                                    var th = new TableCell();
                                    using (var label = new Label { Text = df.Text })
                                    {
                                        th.Controls.Add(label);
                                    }
                                    tr.Controls.Add(th);
                                }

                                //Column 3
                                if (!ReadOnly)
                                {
                                    var td = new TableCell();
                                    var tb = new TextBox
                                    {
                                        ID = df.Id.ToString(),
                                        ClientIDMode = ClientIDMode.Static
                                    };
                                    if (!string.IsNullOrEmpty(df.FieldData.ToString()))
                                        tb.Text = df.FieldData.ToString().HtmlDecode();
                                    tb.Width = Unit.Pixel(397);
                                    ((TextBox)tb).CssClass = "inputClass";
                                    if (df.IsRequired)
                                    {
                                        tb.Attributes.Add("IsRequired", "true");
                                        if (string.IsNullOrEmpty(tb.Text))
                                        {
                                            ((TextBox)tb).CssClass = "dyn_field_yellow";
                                            badCount++;
                                        }
                                    }
                                    tb.Attributes.Add("onChange", "SetFormDataCheck()");
                                    td.Controls.Add(tb);
                                    if (!string.IsNullOrEmpty(df.FieldData.ToString()))
                                    {
                                        using (FormManager am = new FormManager(Global.ABCConnectionString))
                                        {
                                            var _dt = am.GetFormCompanyName(df.FieldData.ToString());
                                            if (_dt.Count > 0)
                                            {
                                                var index = 1;
                                                foreach (LinkedForms str in _dt)
                                                {
                                                    var navURL = SetNavigateURL(str.FormInstance.HtmlDecode(), str.LegalName.HtmlDecode());
                                                    if (!string.IsNullOrEmpty(navURL))
                                                    {

                                                        var ln = new HyperLink
                                                        {
                                                            ID = "lnk" + df.Id.ToString() + index.ToString(),
                                                            Target = "_blank",
                                                            NavigateUrl = navURL,
                                                            Text = str.LinkText
                                                        };
                                                        td.Controls.Add(ln);
                                                    }
                                                    index++;
                                                }
                                            }
                                        }

                                    }
                                    tr.Controls.Add(td);
                                    if (!df.IsReadonly)
                                    {
                                        tb.Enabled = false;
                                    }
                                }
                                else
                                {
                                    //ReadOnly Cell
                                    var td = new TableCell();
                                    //using (var label = new Label { Text = df.FieldData.ToString().HtmlDecode() })
                                    //{
                                    //    td.Controls.Add(label);
                                    //}
                                    //td.Controls.Add(new LiteralControl("&nbsp;&nbsp;"));
                                    if (!string.IsNullOrEmpty(df.FieldData.ToString()))
                                    {
                                        using (FormManager am = new FormManager(Global.ABCConnectionString))
                                        {
                                            var _dt = am.GetFormCompanyName(df.FieldData.ToString());
                                            if (_dt.Count > 0)
                                            {
                                                var index = 1;
                                                foreach (LinkedForms str in _dt)
                                                {
                                                    var navURL = SetNavigateURL(str.FormInstance.HtmlDecode(), str.LegalName.HtmlDecode());
                                                    if (!string.IsNullOrEmpty(navURL))
                                                    {

                                                        var ln = new HyperLink
                                                        {
                                                            ID = "lnk" + df.Id.ToString(),
                                                            Target = "_blank",
                                                            NavigateUrl = navURL,
                                                            Text = str.LinkText
                                                        };
                                                        td.Controls.Add(ln);
                                                    }
                                                    index++;
                                                }
                                            }
                                        }
                                    }
                                    tr.Controls.Add(td);
                                }

                                //Add Row to Table
                                base_tbl.Controls.Add(tr);
                            }
                            break;
                        case DynControlType.LinkedForms:
                            {
                                var tr = new TableRow();

                                //Column 1
                                {
                                    var th = new TableCell();
                                    using (var label = new Label { Text = String.Format("{0}", df.QuestionNumber) })
                                    {
                                        th.Controls.Add(label);
                                    }
                                    tr.Controls.Add(th);
                                }

                                //Column 2
                                {
                                    var th = new TableCell();
                                    using (var label = new Label { Text = df.Text })
                                    {
                                        th.Controls.Add(label);
                                    }
                                    tr.Controls.Add(th);
                                }
                                //Column 3
                                //if (!ReadOnly)
                                //{
                                var td = new TableCell();
                                if (!String.IsNullOrEmpty(FormInstance))
                                {
                                    using (FormManager am = new FormManager(Global.ABCConnectionString))
                                    {
                                        var _dt = am.GetLinkedForms(FormInstance);

                                        if (_dt.Count > 0)
                                        {
                                            var index = 1;
                                            foreach (LinkedForms str in _dt)
                                            {
                                                var navURL = SetNavigateURL(str.FormInstance.HtmlDecode(), str.LegalName, ReadOnly);
                                                if (!string.IsNullOrEmpty(navURL))
                                                {

                                                    var ln = new HyperLink
                                                    {
                                                        ID = "lnk" + df.Id.ToString() + index.ToString(),
                                                        Target = "_blank",
                                                        NavigateUrl = navURL,
                                                        Text = str.LinkText,
                                                        ClientIDMode = ClientIDMode.Static
                                                    };
                                                    td.Controls.Add(ln);
                                                    td.Controls.Add(new LiteralControl(@"<br />"));
                                                }
                                                index++;
                                            }
                                        }
                                        tr.Controls.Add(td);
                                    }
                                }
                                //}

                                //Add Row to Table
                                base_tbl.Controls.Add(tr);
                            }
                            break;
                    }
                }

                if (badCount > 0)
                {
                    IsValid = false;
                }
                //Footer Row
                {
                    var tr = new TableRow();

                    {
                        var th = new TableHeaderCell();
                        using (var label = new Label { Text = "&nbsp;" })
                        {
                            th.Controls.Add(label);
                        }
                        th.ColumnSpan = 3;
                        th.Width = Unit.Percentage(100);
                        tr.Controls.Add(th);
                    }

                    base_tbl.Controls.Add(tr);
                }

                phDynFields.Controls.Add(base_tbl);
            }
        }

        static string SetNavigateURL(string formId, string formName = "", bool isReadonly = false)
        {
            var returnUrl = string.Empty;
            var formArr = formId.Split('-');
            if (formArr.Length > 0)
            {
                var nvc_Querystring = new NameValueCollection();

                nvc_Querystring.Add("FormInstance", formId);
                nvc_Querystring.Add("LegalName", HttpUtility.UrlEncode(formName));
                if (isReadonly)
                {
                    nvc_Querystring.Add("ReadOnly", "true");
                }
                switch (formArr[0])
                {
                    case "ABC":
                        nvc_Querystring.Add("FormId", "1");
                        returnUrl = "../ABCForm/Form1.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]);
                        break;
                    case "VPS":
                        nvc_Querystring.Add("FormId", "2");
                        returnUrl = "../ABCForm/Form2.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]);
                        break;
                    case "Review":
                        nvc_Querystring.Add("FormId", "3");
                        returnUrl = "../ABCForm/Form3.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]);
                        break;
                    case "VPP":
                        nvc_Querystring.Add("FormId", "4");
                        returnUrl = "../ABCForm/Form4.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]);
                        break;
                    case "Supplementary":
                        nvc_Querystring.Add("FormId", "5");
                        returnUrl = "../ABCForm/Form5.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]);
                        break;
                }
            }
            return returnUrl;
        }

        void tb_TextChanged(object sender, EventArgs e)
        {
            var txtBox = (TextBox)sender;
            using (ControlFinder<RadPanelItem> rpControl = new ControlFinder<RadPanelItem>())
            {
                var rpi = (RadPanelItem)rpControl.FindParentControlsRecursive(txtBox);
                if (!rpi.Text.Contains("wild_card"))
                {
                    rpi.Text = rpi.Text + "<img src='../Content/images/wild_card.png' id='wild_card' class='translucent' width='12px' height='12px' alt='' />";
                }
            }
        }

        void imgButton_Click(object sender, ImageClickEventArgs e)
        {
            var ss = (ImageButton)sender;
            using (ControlFinder<Table> dfcf = new ControlFinder<Table>())
            {
                var base_tbl = (Table)dfcf.FindParentControlsRecursive(ss);
                var idCnt = base_tbl.Rows.Count - 1;
                using (ExtraField newField = new ExtraField())
                {
                    newField.Sec = SectionId;
                    newField.Form = FormId;
                    newField.Id = idCnt.ToString();
                    //newField.Text = tb.Text;
                    newField.QuestionField = DynControlType.TextBox;
                    //newField.FieldData = tbAns.Text;
                    newField.CtrlType = DynControlType.TextBox;
                    newField.ButtonField = DynControlType.Attachment;

                    List<ExtraField> newAddedFields;
                    if (Session["NewAddedFields"] != null)
                    {
                        newAddedFields = (List<ExtraField>)Session["NewAddedFields"];
                    }
                    else
                    {
                        newAddedFields = new List<ExtraField>();
                    }
                    newAddedFields.Add(newField);
                    Session["NewAddedFields"] = newAddedFields;

                    //SetExtraControls(base_tbl);
                }

                //phDynFields.Controls.Add(base_tbl);
            }
        }
        void imgButtonMinus_Click(object sender, ImageClickEventArgs e)
        {
            var ss = (ImageButton)sender;
            using (ControlFinder<Table> dfcf = new ControlFinder<Table>())
            {
                var base_tbl = (Table)dfcf.FindParentControlsRecursive(ss);
                base_tbl.Rows.RemoveAt(base_tbl.Rows.Count - 1);
            }
        }
        #endregion

        #region " SetButton "
        /// <summary>
        /// SetButton
        /// </summary>
        /// <param name="btn"></param>
        /// <param name="btt"></param>
        protected void SetButton(Button btn, DynButtonType btt)
        {
            switch (btt)
            {
                case DynButtonType.CompanyRegistrationAttachment:
                    break;
            }
        }
        #endregion

        #region " SetCheckBoxItems "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="cbl"></param>
        /// <param name="checkType"></param>
        protected void SetCheckBoxItems(CheckBoxList cbl, string checkType)
        {
            using (var dd = new DataTable())
            {
                using (DropDownDataManager ddManager = new DropDownDataManager(Global.ABCConnectionString))
                {
                    using (System.Data.DataTable _dt = ddManager.GetAllDropDownDataByCategory(checkType))
                    {
                        for (int i = 0; i < _dt.Rows.Count; i++)
                        {
                            cbl.Items.Add(new ListItem(_dt.Rows[i]["DisplayValue"].ToString(), _dt.Rows[i]["DDId"].ToString()));
                        }
                    }
                }
            }
        }
        #endregion

        #region " SetRadionButtonItems "
        /// <summary>
        /// SetRadionButtonItems
        /// </summary>
        /// <param name="rbl"></param>
        /// <param name="rbt"></param>
        protected void SetRadionButtonItems(RadioButtonList rbl, string rbt)
        {
            using (var dd = new DataTable())
            {
                using (DropDownDataManager ddManager = new DropDownDataManager(Global.ABCConnectionString))
                {
                    using (System.Data.DataTable _dt = ddManager.GetAllDropDownDataByCategory(rbt))
                    {
                        for (int i = 0; i < _dt.Rows.Count; i++)
                        {
                            rbl.Items.Add(new ListItem(_dt.Rows[i]["DisplayValue"].ToString(), _dt.Rows[i]["DDId"].ToString()));
                        }
                    }
                }
            }
        }
        #endregion

        #endregion

        #region " Private Methods "
        public void SetExtraControls()
        {
            var newQuestions = (List<ExtraField>)HttpContext.Current.Session["NewAddedFields"];

            var newTable = (Table)phDynFields.FindControl("ABCNewForm_1_1");//MainContent_rpb_Section_i0_Section1_ABCNewForm_1_1
            if (newTable != null)
            {
                var rowIndex = newQuestions.Count - 1;
                newTable.Rows[rowIndex].Visible = true;
            }
        }

        private void LoadDropDownData(DropDownList cmbBox, string ddType)
        {
            using (var dd = new DataTable())
            {
                using (DropDownDataManager ddManager = new DropDownDataManager(Global.ABCConnectionString))
                {
                    /* Add default value */
                    cmbBox.Items.Add(new ListItem("-- Choose Value --", "-1"));
                    using (System.Data.DataTable _dt = ddManager.GetAllDropDownDataByCategory(ddType))
                    {
                        for (int i = 0; i < _dt.Rows.Count; i++)
                        {
                            cmbBox.Items.Add(new ListItem(_dt.Rows[i]["DisplayValue"].ToString(), _dt.Rows[i]["DDId"].ToString()));
                        }
                    }


                }
            }

        }

        #region " EncryptQueryString "
        /// <summary>
        /// Encrypt Query String
        /// </summary>
        /// <param name="queryStrings"></param>
        /// <returns></returns>
        private string EncryptQueryString(NameValueCollection queryStrings)
        {
            var encryptedString = CryptoQueryStringHandler.EncryptQueryStrings(queryStrings, ConfigurationManager.AppSettings["CryptoKey"]);
            return encryptedString;
        }

        #endregion

        #region " RemoveInvalidChar "
        /** \private    RemoveInvalidChar    
         *  \details    Strips out all nonalphanumeric characters except periods (.) and hyphens (-), and returns the remaining string  
        */

        private string RemoveInvalidChar(string fileName)
        {
            try
            {
                return Regex.Replace(fileName, "[^\\w\\.-]", "");
            }
            catch
            {
                return string.Empty;
            }
        }
        #endregion

        private void btnDelAttachmentClick(object sender, EventArgs e)
        {
            using (AttachmentManager am = new AttachmentManager(Global.ABCConnectionString))
            {
                var btn = (ImageButton)sender;
                using (DataTable retRow = am.DeleteAttachment(Convert.ToInt32(btn.ID.Replace("btnDelAttachment", ""))))
                {
                    //Response.Redirect(Request.RawUrl);
                    //if ((int)retRow.Rows[0]["ErrorCode"] == 0)
                    //{
                    //    lblAttachmentMessage.Text = "Attachment Successfully Deleted";
                    //    lblAttachmentMessage.Style.Add(HtmlTextWriterStyle.Color, "Green");
                    //    //grdAttachments.Rebind();
                    //    grdAttachments_NeedDataSource(null, null);
                    //}
                }
            }
        }

        #region " grdAttachments_ItemDataBound "

        protected void gridAttachments_ItemDataBound(object sender, GridItemEventArgs e)
        {
            if (e.Item is GridDataItem)
            {
                var item = (GridDataItem)e.Item;


                var parameters = new NameValueCollection();
                parameters.Add("attachmentId", RemoveInvalidChar(item["AttachmentId"].Text));
                parameters.Add("attachmentName", RemoveInvalidChar(item["AttachmentName"].Text));
                var querystring = EncryptQueryString(parameters);
                var urlstring = "~/ABCForm/DisplayFile.aspx?" + querystring;
                var hLink = (HyperLink)item["AttachmentName"].Controls[0];
                hLink.NavigateUrl = urlstring;
            }
        }

        #endregion

        #region " grdAttachments_ItemCommand "

        protected void gridAttachments_ItemCommand(object sender, GridCommandEventArgs e)
        {
            var item = (GridDataItem)e.Item;
            var grdAttachments = (RadGrid)item.Parent.Parent.Parent;

            switch (e.CommandName)
            {
                case "Delete":
                    using (AttachmentManager am = new AttachmentManager(Global.ABCConnectionString))
                    {
                        using (DataTable retRow = am.DeleteAttachment(Convert.ToInt32(item["AttachmentId"].Text)))
                        {
                            if ((int)retRow.Rows[0]["ErrorCode"] == 0)
                            {
                                //lblAttachmentMessage.Text = "Attachment Successfully Deleted";
                                //lblAttachmentMessage.Style.Add(HtmlTextWriterStyle.Color, "Green");
                                //grdAttachments.Rebind();
                                using (AttachmentManager ams = new AttachmentManager(Global.ABCConnectionString))
                                {
                                    using (DataTable _dt = ams.LoadAttachments(Convert.ToInt32(grdAttachments.ID.Replace("gridAttachments", "")), FormInstance, (int)AttachmentIdentifier.QuestionLevel))
                                    {
                                        if (_dt != null && _dt.Rows.Count > 0)
                                        {
                                            grdAttachments.DataSource = _dt;
                                        }
                                        else
                                        {
                                            grdAttachments.DataSource = null;
                                        }
                                    }
                                }
                                grdAttachments.DataBind();
                            }
                        }
                    }
                    break;
            }
        }
        #endregion
        #endregion
    }
}