﻿using BusinessLogicLayer;
using Common;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using Verizon.QueryStringEncryption;

namespace ABC.ABCForm
{
    public partial class SampleAdmin : System.Web.UI.Page
    {
        public int Count { get; set; }

        public int SectionId { get; set; }

        public int FormId { get; set; }

        private bool _ReadOnly = false;
        public bool ReadOnly
        {
            get
            {
                return _ReadOnly;
            }
            set
            {
                _ReadOnly = value;
            }
        }

        private string FormInstance
        {
            get
            {
                if (Session["FormInstance"] != null)
                {
                    return Session["FormInstance"].ToString();
                }

                return string.Empty;
            }
            set
            {
                Session["FormInstance"] = value;
            }
        }

        public IEnumerable<DynamicField> Answers
        {
            get
            {
                var ans = new List<DynamicField>();

                using (ControlFinder<TextBox> tbcf = new ControlFinder<TextBox>())
                {
                    tbcf.FindChildControlsRecursive(phDynFields);
                    var tbList = tbcf.FoundControls;
                    foreach (TextBox tb in tbList)
                    {
                        using (var dynamicField = new DynamicField
                        {
                            Id = tb.ID,
                            Form = FormId,//Convert.ToInt32(rdpFormType.SelectedValue),
                            Sec = SectionId,//Convert.ToInt32(rdpFormSection.SelectedValue),
                            CtrlType = DynControlType.TextBox,
                            Text = tb.Text,
                            FieldData = tb.Attributes["questionText"]
                        })
                        {
                            ans.Add(dynamicField);
                        }
                    }
                }

                return ans;
            }
        }
        protected void Page_Init(object sender, EventArgs e)
        {
            //if (rdpFormType.SelectedValue != "" && rdpFormSection.SelectedValue != "")
            //{
            //var FormId = Convert.ToInt32(rdpFormType.SelectedValue);
            //var SectionId = Convert.ToInt32(rdpFormSection.SelectedValue);
            using (FormManager refMgr = new FormManager(Global.ABCConnectionString))
            {
                var dynamicFields = refMgr.GetDynamicFields(FormId, SectionId, 101, "");

                Count = dynamicFields.Count();

                SetDynamicFields(dynamicFields);

            }
            //}
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadComboBox("rdpFormType", rdpFormType);
            }
        }
        protected void abtnSearch_ServerClick(object sender, EventArgs e)
        {
            FormId = Convert.ToInt32(rdpFormType.SelectedValue);
            SectionId = Convert.ToInt32(rdpFormSection.SelectedValue);
            using (FormManager refMgr = new FormManager(Global.ABCConnectionString))
            {
                var dynamicFields = refMgr.GetDynamicFields(FormId, SectionId, 101, "");

                Count = dynamicFields.Count();

                SetDynamicFields(dynamicFields);

            }
        }
        /// <summary>
        /// SetDynamicFields
        /// </summary>
        /// <param name="dynamicFields"></param>
        protected void SetDynamicFields(IEnumerable<DynamicField> dynamicFields)
        {
            using (Table base_tbl = new Table())
            {
                base_tbl.ID = "base_tbl";
                base_tbl.CssClass = "table table-bordered";

                //Header Row - Column Titles
                using (TableHeaderRow tr = new TableHeaderRow())
                {
                    using (TableHeaderCell th = new TableHeaderCell())
                    {
                        using (var label = new Label { Text = "S.No" })
                        {
                            th.Controls.Add(label);
                        }
                        th.Width = Unit.Percentage(5);
                        tr.Controls.Add(th);
                    }

                    using (TableHeaderCell th = new TableHeaderCell())
                    {
                        using (var label = new Label { Text = "Question" })
                        {
                            th.Controls.Add(label);
                        }
                        th.Width = Unit.Percentage(75);
                        tr.Controls.Add(th);
                    }
                    using (TableHeaderCell td = new TableHeaderCell())
                    {
                        using (var label = new Label { Text = "Order" })
                        {
                            td.Controls.Add(label);
                        }
                        td.Width = Unit.Percentage(20);
                        tr.Controls.Add(td);
                    }
                    base_tbl.Controls.Add(tr);
                }

                foreach (DynamicField df in dynamicFields)
                {

                    using (TableRow tr = new TableRow())
                    {

                        //Column 1
                        using (TableCell th = new TableCell())
                        {
                            using (var label = new Label { Text = String.Format("{0}", df.QuestionNumber) })
                            {
                                th.Controls.Add(label);
                            }
                            tr.Controls.Add(th);
                        }

                        //Column 2
                        using (TableCell th = new TableCell())
                        {
                            using (var label = new Label { Text = df.Text })
                            {
                                th.Controls.Add(label);
                            }
                            tr.Controls.Add(th);
                        }
                        {
                            //Column 3
                            //Edit Cell
                            var td = new TableCell();
                            using (var tb = new TextBox
                            {
                                ID = df.Id.ToString(),
                                Text = df.QuestionNumber.ToString()
                            })
                            {
                                tb.Attributes.Add("questionText", df.Text);
                                td.Controls.Add(tb);
                                tr.Controls.Add(td);
                            }
                        }
                        base_tbl.Controls.Add(tr);
                    }
                    //Add Row to Table
                }

                //Footer Row
                {
                    var tr = new TableRow();

                    {
                        var th = new TableHeaderCell();
                        using (var label = new Label { Text = "&nbsp;" })
                        {
                            th.Controls.Add(label);
                        }
                        th.ColumnSpan = 3;
                        th.Width = Unit.Percentage(100);
                        tr.Controls.Add(th);
                    }

                    base_tbl.Controls.Add(tr);
                }

                phDynFields.Controls.Add(base_tbl);
            }
        }

        #region " LoadDropDown "
        /** \private    LoadDropDown 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
        */
        private void LoadComboBox(string ddType, Telerik.Web.UI.RadComboBox dropDown)
        {
            try
            {
                #region " Try Block "

                /** First un-select any selected item */
                dropDown.ClearSelection();
                dropDown.Items.Clear(); //Remove any previously loaded items
                dropDown.SelectedIndex = -1;
                /**Create DashboardManager object and bind values to dropdowns*/
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    var roleId = ((Int32)Navigation.Current.CurrentRole).ToString();// Session["currentUserRole"] != null ? Convert.ToString(Session["currentUserRole"]) : string.Empty;
                    if (roleId == string.Empty)
                    {
                        // roleId = "103"; //Pass Default Admin role, later need to remove this line
                    }
                    // rdpFormSection is dependent on the selected rdpFormType dropDown
                    if (ddType == "rdpFormType")
                    {
                        using (var _dt1 = dm.GetFormsDropDownList())
                        {
                            if (_dt1 != null && _dt1.Rows.Count > 0)
                            {
                                for (int i = 0; i < _dt1.Rows.Count; i++)
                                {
                                    var li = new RadComboBoxItem(_dt1.Rows[i]["Name"].ToString(), _dt1.Rows[i]["FormID"].ToString());
                                    dropDown.Items.Add(li);
                                }
                            }
                        }
                    }
                    else
                    {
                        using (var _dt = dm.GetFormSectionDropDownList(Convert.ToInt32(ddType), Convert.ToInt32(roleId), 2))
                        {
                            dropDown.DataSource = _dt;
                            dropDown.DataTextField = "SectionDescription";
                            dropDown.DataValueField = "SectionId";
                            dropDown.DataBind();
                        }
                    }

                    /* Add default value */
                    var liFirst = new RadComboBoxItem("-- Choose Value --", "0");
                    dropDown.Items.Insert(0, liFirst);
                }

                #endregion
            }
            catch (Exception ex)
            {
                //ex.HelpLink = GetMoreInfoForException();
                //Get page name and calling method and stored procedure.
                //ex.HelpLink = GetMoreInfoForException(Path.GetFileName(Request.Path), MethodBase.GetCurrentMethod().Name, "");
                //LogError(ex, ex.HelpLink);
                ExceptionPolicy.HandleException(ex, Global.ApplicationLayerPolicy);
            }

        }
        #endregion

        protected void rdpFormType_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            FormId = Convert.ToInt32(rdpFormType.SelectedValue);
            LoadComboBox(rdpFormType.SelectedValue, rdpFormSection);
        }



        private string RemoveInvalidChar(string fileName)
        {
            try
            {
                return Regex.Replace(fileName, "[^\\w\\.-]", "");
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        #region " EncryptQueryString "
        /// <summary>
        /// Encrypt Query String
        /// </summary>
        /// <param name="queryStrings"></param>
        /// <returns></returns>
        private string EncryptQueryString(NameValueCollection queryStrings)
        {
            var encryptedString = CryptoQueryStringHandler.EncryptQueryStrings(queryStrings, ConfigurationManager.AppSettings["CryptoKey"]);
            return encryptedString;
        }

        #endregion

        protected void btnUpdateOrder_ServerClick(object sender, EventArgs e)
        {
            var sb = new StringBuilder();
            var ansList = Answers;

            foreach (DynamicField df in ansList)
            {
                sb.Append("UPDATE FS SET FS.SecQuestionOrder = " + df.Text);
                sb.Append(" FROM dbo.FormSection FS");
                sb.Append(" INNER JOIN dbo.FormQuestion FQ ON FQ.FormQuestionID = FS.FormQuestionID");
                sb.AppendLine(" WHERE SectionID = " + df.Sec.ToString() + " AND FormID = " + df.Form.ToString() + " AND RoleID = 101 AND FQ.QuestionText = '" + df.FieldData.ToString().Replace("'", "''") + "';");
            }
            txtOuput.Text = sb.ToString();
        }
    }
}