﻿using BusinessLogicLayer;
using Common;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Script.Serialization;
using System.Web.Services;

namespace ABC.ABCForm
{
    public partial class PrintPartialForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


        }

        #region " ProcessException "

        protected static void ProcessException(Exception inEx, string inFunctionName, string inSPName, int stsId)
        {
            var userName = string.Empty;
            if (Navigation.Current.UserName != null)
            {
                userName = Navigation.Current.UserName;
            }
            var excep = new ABCException
            {
                StsId = stsId,
                Name = userName,
                MethodName = inFunctionName,
                SpName = inSPName,
                PageName = "PrintPartialForm.aspx.cs"
            };
            inEx.HelpLink = ABCException.GetMoreInfoForException(excep);
            ExceptionPolicy.HandleException(inEx, Global.ApplicationLayerPolicy);
        }

        #endregion

        #region " DataTableToJSONWithJavaScriptSerializer "
        public static string DataTableToJSONWithJavaScriptSerializer(DataTable table)
        {
            var jsSerializer = new JavaScriptSerializer
            {
                MaxJsonLength = Int32.MaxValue
            };
            var parentRow = new List<Dictionary<string, object>>();
            Dictionary<string, object> childRow;
            foreach (DataRow row in table.Rows)
            {
                childRow = new Dictionary<string, object>();
                foreach (DataColumn col in table.Columns)
                {
                    childRow.Add(col.ColumnName, row[col]);
                }
                parentRow.Add(childRow);
            }
            return jsSerializer.Serialize(parentRow);
        }
        #endregion

        #region " Web Methods "
        #region " LoadDropDown "
        /** \private    LoadDropDown 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
        */
        [WebMethod]
        public static string LoadComboBox(string ddType )
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    var roleId = ((Int32)Navigation.Current.CurrentRole).ToString();// Session["currentUserRole"] != null ? Convert.ToString(Session["currentUserRole"]) : string.Empty;
                    // rdpFormSection is dependent on the selected rdpFormType dropDown
                    if (ddType == "rdpFormType")
                    {
                        using (var _dt1 = dm.GetFormsDropDownList())
                        {
                            if (_dt1 != null && _dt1.Rows.Count > 0)
                            {
                                result = DataTableToJSONWithJavaScriptSerializer(_dt1);
                            }
                        }
                    }
                    else
                    {
                        using (var _dt = dm.GetFormSectionDropDownList(Convert.ToInt32(ddType), Convert.ToInt32(roleId), 2))
                        {
                            result = DataTableToJSONWithJavaScriptSerializer(_dt);
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "LoadComboBox", "qry_GetFormsDropDown", stsId);
            }
            return result;
        }
        #endregion
        #endregion
    }
}