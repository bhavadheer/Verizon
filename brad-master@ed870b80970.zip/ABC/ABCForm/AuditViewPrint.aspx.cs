﻿using BusinessLogicLayer;
using Common;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ABC.ABCForm
{
    public partial class AuditViewPrint : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region " ProcessException "

        protected static void ProcessException(Exception inEx, string inFunctionName, string inSPName, int stsId)
        {
            var userName = string.Empty;
            if (Navigation.Current.UserName != null)
            {
                userName = Navigation.Current.UserName;
            }
            var excep = new ABCException
            {
                StsId = stsId,
                Name = userName,
                MethodName = inFunctionName,
                SpName = inSPName,
                PageName = "AuditViewPrint.aspx.cs"
            };
            inEx.HelpLink = ABCException.GetMoreInfoForException(excep);
            ExceptionPolicy.HandleException(inEx, Global.ApplicationLayerPolicy);
        }

        #endregion

        #region " DataTableToJSONWithJavaScriptSerializer "
        public static string DataTableToJSONWithJavaScriptSerializer(DataTable table)
        {
            var jsSerializer = new JavaScriptSerializer
            {
                MaxJsonLength = Int32.MaxValue
            };
            var parentRow = new List<Dictionary<string, object>>();
            Dictionary<string, object> childRow;
            foreach (DataRow row in table.Rows)
            {
                childRow = new Dictionary<string, object>();
                foreach (DataColumn col in table.Columns)
                {
                    childRow.Add(col.ColumnName, row[col]);
                }
                parentRow.Add(childRow);
            }
            return jsSerializer.Serialize(parentRow);
        }
        #endregion

        #region " Web Methods "
        [WebMethod]
        public static string LoadForms(string fromDate, string toDate)
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            var ci = System.Globalization.CultureInfo.CreateSpecificCulture("en-GB");
            var frDate = fromDate == "" ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(DateTime.Parse(fromDate, ci.DateTimeFormat).ToString("d"));
            var tDate = toDate == "" ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(DateTime.Parse(toDate, ci.DateTimeFormat).ToString("d"));
            var isUrgent = string.Empty;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    using (var _dt1 = dm.GetFormsSearch(0, string.Empty, string.Empty, string.Empty, frDate, tDate, 3, stsId, isUrgent, string.Empty))
                    {
                        if (_dt1 != null && _dt1.Rows.Count > 0)
                        {
                            result = DataTableToJSONWithJavaScriptSerializer(_dt1);//_dt1.AsEnumerable().Take(100).CopyToDataTable());
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "LoadForms", "qry_FormsSearch", stsId);
            }
            return result;
        }

        [WebMethod]
        public static string GetAuditViewPrint(string formInstance)
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (FormManager dm = new FormManager(Global.ABCConnectionString))
                {
                    using (var _dt1 = dm.GetAuditViewPrint(formInstance))
                    {
                        if (_dt1 != null && _dt1.Rows.Count > 0)
                        {
                            result = DataTableToJSONWithJavaScriptSerializer(_dt1);
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "GetAuditViewPrint", "qry_AuditViewPrint", stsId);
            }
            return result;
        }

        #endregion
    }
}