﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Common;
using BusinessLogicLayer;
using Telerik.Web.UI;
using System.Data;
using System.IO;
using System.Web.Services;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using Verizon.QueryStringEncryption;
using System.Collections.Specialized;
using System.Configuration;
using System.Text.RegularExpressions;

namespace ABC.ABCForm
{
    public partial class AttachmentControl : System.Web.UI.UserControl
    {

        private string FormInstance
        {
            get
            {
                if (Session["FormInstance"] != null)
                {
                    return Session["FormInstance"].ToString();
                }

                return string.Empty;
            }
            set
            {
                Session["FormInstance"] = value;
            }
        }

        public void Reload()
        {
            grdAttachments.Rebind();
        }

        #region " Public Properties "

        private int _vendorId;
        private int _formId;

        public int VenderId
        {
            set { _vendorId = value; }
        }

        public int FormId
        {
            set { _formId = value; }
        }

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            fileUpload.TemporaryFolder = Global.TempPathForFile;
            fileUpload.TargetFolder = Global.TempPathForFile;

            if ((string)Session["reloadAttachments"] == "1")
            {
                grdAttachments.Rebind();
                Session["reloadAttachments"] = string.Empty;
            }
        }

        #region " btnSubmitDocs_Click "

        protected void btnSubmitDocs_Click(object sender, EventArgs e)
        {
            if (fileUpload.UploadedFiles.Count == 0)
            {
                lblAttachmentMessage.Text = "Attachment Upload Failed - Allowed File types: pdf, doc, docx, xls, xlsx, msg";
                lblAttachmentMessage.Style.Add(HtmlTextWriterStyle.Color, "Red");
            }

            grdAttachments.Rebind();
        }

        #endregion

        #region " grdAttachment events "

        #region " grdAttachments_PreRender "

        protected void grdAttachments_PreRender(object sender, System.EventArgs e)
        {
            if (!this.IsPostBack)
            {
                foreach (GridColumn column in grdAttachments.MasterTableView.Columns)
                {
                    switch (column.UniqueName)
                    {
                        case "AttachmentId":
                            column.Display = false;
                            break;
                    }
                }
            }
        }
        #endregion

        #region " grdAttachments_NeedDataSource "

        protected void grdAttachments_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
        {
            using (AttachmentManager am = new AttachmentManager(Global.ABCConnectionString))
            {
                using (DataTable _dt = am.LoadAttachments(27, (string)Session["FormInstance"], (int)AttachmentIdentifier.FormLevel))
                {
                    grdAttachments.DataSource = _dt;
                }
            }
        }

        #endregion

        #region " grdAttachments_ItemDataBound "

        protected void grdAttachments_ItemDataBound(object sender, GridItemEventArgs e)
        {
            if (e.Item is GridDataItem)
            {
                string attachmentName = Convert.ToString(DataBinder.Eval(e.Item.DataItem, "AttachmentName"));
                string attachmentId = Convert.ToString(DataBinder.Eval(e.Item.DataItem, "AttachmentId"));

                if (string.IsNullOrEmpty(attachmentId))
                {
                    attachmentId = "0";
                }

                GridDataItem item = (GridDataItem)e.Item;
                HyperLink lnkAttachmentName = (HyperLink)e.Item.FindControl("lnkAttachmentName");
                if (lnkAttachmentName != null)
                {
                    NameValueCollection parameters = new NameValueCollection();
                    parameters.Add("attachmentId", RemoveInvalidChar(attachmentId));
                    parameters.Add("attachmentName", RemoveInvalidChar(attachmentName));
                    string querystring = EncryptQueryString(parameters);
                    string urlstring = "~/ABCForm/DisplayFile.aspx?" + querystring;
                    lnkAttachmentName.Text = attachmentName;
                    lnkAttachmentName.NavigateUrl = urlstring;
                    lnkAttachmentName.Target = "_blank";
                }
            }
        }

        #endregion

        #region " grdAttachments_ItemCommand "

        protected void grdAttachments_ItemCommand(object sender, GridCommandEventArgs e)
        {
            GridDataItem item = (GridDataItem)e.Item;

            switch (e.CommandName)
            {
                case "Delete":
                    using (AttachmentManager am = new AttachmentManager(Global.ABCConnectionString))
                    {
                        using (DataTable retRow = am.DeleteAttachment(Convert.ToInt32(item["AttachmentId"].Text)))
                        {
                            if ((int)retRow.Rows[0]["ErrorCode"] == 0)
                            {
                                lblAttachmentMessage.Text = "Attachment Successfully Deleted";
                                lblAttachmentMessage.Style.Add(HtmlTextWriterStyle.Color, "Green");
                                //grdAttachments.Rebind();
                                grdAttachments_NeedDataSource(null, null);
                            }
                        }
                    }
                    break;
            }
        }
        #endregion

        #endregion

        #region " Attachment DB calls "

        #region " GetAttachmentsByFormVendor "

        protected void GetAttachmentsByFormVendor()
        {
            int outSectionId;
            if (Int32.TryParse(Session["FormId"].ToString(), out outSectionId))
            {
                using (AttachmentManager am = new AttachmentManager(Global.ABCConnectionString))
                {
                    using (DataTable _dt = am.GetAttachmentsByFormVendor(outSectionId))
                    {
                        grdAttachments.DataSource = _dt;
                    }
                }
            }
        }

        #endregion

        #region " Save Attachment "

        protected void fileUpload_FileUploaded(object sender, FileUploadedEventArgs e)
        {
            try
            {
                lblAttachmentMessage.Text = string.Empty;
                using (AttachmentManager am = new AttachmentManager(Global.ABCConnectionString))
                {
                    var contenttype = string.Empty;
                    var fileext = string.Empty;
                    var filename = string.Empty;
                    DataTable insrows = null;
                    var attachment = new Attachment();
                    var filebytes = new Byte[0];
                    UploadedFile imageFile = null;

                    attachment.AttachmentId = 0;
                    //attachment.FormId = Convert.ToInt32((int)Session["FormId"]);
                    attachment.FormSectionId = 0; //Change if/when required
                    attachment.AttachmentStream = filebytes;

                    if (e.File.ContentLength > 0)
                    {
                        int outStsId;
                        imageFile = e.File;
                        contenttype = e.File.ContentType;
                        filename = e.File.GetName();
                        fileext = e.File.GetExtension();
                        attachment.AttachmentName = filename;
                        attachment.FormSectionId = 27;

                        var fs = e.File.InputStream;
                        using (var br = new BinaryReader(fs))
                        {
                            if (!Int32.TryParse(Navigation.Current.LoggedInStsId.ToString(), out outStsId))
                            {
                                outStsId = -1;
                            }
                            if (String.IsNullOrEmpty(FormInstance))
                            {
                                using (FormManager refMgr = new FormManager(Global.ABCConnectionString))
                                {
                                    FormInstance = refMgr.GetNextFormInstance(Convert.ToInt32(Session["FormId"]));
                                }
                            }
                            insrows = am.InsertAttachmentWithStream(attachment, FormInstance, (int)AttachmentIdentifier.FormLevel, outStsId, fs);
                            fs.Close();
                        }
                    }
                    else
                    {
                        lblAttachmentMessage.Text = "Please select a file to upload";
                        lblAttachmentMessage.Style.Add(HtmlTextWriterStyle.Color, "Red");
                        return;
                    }

                    if ((int)insrows.Rows[0]["ErrorCode"] == 0)
                    {
                        lblAttachmentMessage.Style.Add(HtmlTextWriterStyle.Color, "Green");
                        lblAttachmentMessage.Text = "File attached successfully";
                        //grdAttachments.Rebind();
                        grdAttachments_NeedDataSource(null, null);
                    }
                }
            }
            catch (System.Threading.ThreadAbortException) { }
            catch (Exception ex)
            {
                ProcessException(ex, "fileUpload_FileUploaded", "InsertAttachmentWithStream()");
            }
        }

        #endregion

        #endregion

        #region " ProcessException "

        protected void ProcessException(Exception inEx, string inFunctionName, string inSPName)
        {
            var userName = string.Empty;
            if (Navigation.Current.UserName != null)
            {
                userName = Navigation.Current.UserName;
            }
            var excep = new ABCException
            {
                StsId = Navigation.Current.LoggedInStsId,
                Name = userName,
                MethodName = inFunctionName,
                SpName = inSPName,
                PageName = "AttachmentControl.ascx.cs"
            };
            inEx.HelpLink = ABCException.GetMoreInfoForException(excep);
            ExceptionPolicy.HandleException(inEx, Global.ApplicationLayerPolicy);
        }

        #endregion

        #region " EncryptQueryString "
        /// <summary>
        /// Encrypt Query String
        /// </summary>
        /// <param name="queryStrings"></param>
        /// <returns></returns>
        private string EncryptQueryString(NameValueCollection queryStrings)
        {
            string encryptedString = CryptoQueryStringHandler.EncryptQueryStrings(queryStrings, ConfigurationManager.AppSettings["CryptoKey"]);
            return encryptedString;
        }

        #endregion

        #region " RemoveInvalidChar "
        /** \private    RemoveInvalidChar    
         *  \details    Strips out all nonalphanumeric characters except periods (.) and hyphens (-), and returns the remaining string  
        */

        private string RemoveInvalidChar(string fileName)
        {
            try
            {
                return Regex.Replace(fileName, @"[^\w\.-]", "");
            }
            catch
            {
                return string.Empty;
            }
        }

        #endregion

        protected void grdAttachments_ItemCreated(object sender, GridItemEventArgs e)
        {
            if (e.Item is GridPagerItem)
            {
                var PageSizeCombo = (RadComboBox)e.Item.FindControl("PageSizeComboBox");
                PageSizeCombo.RenderMode = RenderMode.Lightweight;
            }
        }
    }
}