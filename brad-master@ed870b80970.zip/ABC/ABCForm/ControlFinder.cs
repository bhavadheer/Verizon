﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

namespace ABC
{
    #region " ControlFinder "
    /// <summary>
    /// Finds all controls of type T stores them in FoundControls
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ControlFinder<T> : IDisposable where T : Control
    {
        private bool disposed = false;
        private readonly List<T> _foundControls = new List<T>();

        public ControlFinder()
        {
        }

        ~ControlFinder()
        {
            this.Dispose(false);
        }

        ///<summary>
        ///Dispose ControlFinder object
        ///</summary>
        public void Dispose()
        {
            //call dispose of any object used in class
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        ///<summary>
        ///Dispose ControlFinder object. It cleans resources both managed and native
        ///</summary>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    //Call dispose of any object used in this class
                }
            }
            disposed = true;
        }

        public IEnumerable<T> FoundControls
        {
            get { return _foundControls; }
        }

        public void FindChildControlsRecursive(Control control)
        {
            foreach (Control childControl in control.Controls)
            {
                if (childControl.GetType() == typeof(T) || childControl.GetType().BaseType == typeof(T))
                {
                    _foundControls.Add((T)childControl);
                }
                else
                {
                    FindChildControlsRecursive(childControl);
                }
            }
        }

        public Control FindParentControlsRecursive(Control control)
        {
            Control rControl = null;
            if (control.Parent != null)
            {
                if (control.Parent.GetType() == typeof(T))
                {
                    rControl = control.Parent;
                }
                else
                {
                    rControl = FindParentControlsRecursive(control.Parent);
                }
            }
            else
            {
                rControl = null;
            }
            return rControl;
        }
    }
    #endregion
}