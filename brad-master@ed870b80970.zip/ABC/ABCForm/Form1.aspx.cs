﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Common;
using Telerik.Web.UI;
using System.Data;
using BusinessLogicLayer;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using System.IO;
using System.Drawing;
using System.Collections.Specialized;
using Verizon.QueryStringEncryption;
using System.Web.Configuration;
using System.Web.Services;
using System.Web.Script.Serialization;

namespace ABC.ABCForm
{
    public partial class Form1 : System.Web.UI.Page
    {

        #region " Page level variables "

        private string FormInstance
        {
            get
            {
                if (Session["FormInstance"] != null)
                {
                    return Session["FormInstance"].ToString();
                }

                return string.Empty;
            }
            set
            {
                Session["FormInstance"] = value;
            }
        }

        private string LegalName
        {
            get
            {
                if (Session["LegalName"] != null)
                {
                    return Session["LegalName"].ToString();
                }

                return string.Empty;
            }
            set
            {
                Session["LegalName"] = value;
            }
        }

        private int FormInstanceType
        {
            get
            {
                int x;
                if (Session["FormInstanceType"] != null)
                {
                    if (Int32.TryParse(Session["FormInstanceType"].ToString(), out x))
                    {
                        return x;
                    }
                }

                return 0;
            }
            set
            {
                Session["FormInstanceType"] = value;
            }
        }

        private bool AllowOverride
        {
            get
            {
                bool x;
                if (Session["AllowOverride"] != null)
                {
                    if (bool.TryParse(Session["AllowOverride"].ToString(), out x))
                    {
                        return x;
                    }
                }

                return false;
            }
            set
            {
                Session["AllowOverride"] = value;
            }
        }

        private int LoggedInStsId
        {
            get
            {
                int x;
                if (Int32.TryParse(hiLoggedInStsId.Value, out x))
                {
                    return x;
                }

                return -1;
            }
            set
            {
                hiLoggedInStsId.Value = value.ToString();
            }
        }

        private int LockID
        {
            get
            {
                int x;
                if (Int32.TryParse(hiLockID.Value, out x))
                {
                    return x;
                }

                return -1;
            }
            set
            {
                hiLockID.Value = value.ToString();
            }
        }

        private bool _ReadOnly
        {
            get
            {
                bool x;
                if (Session["ReadOnly"] != null && Boolean.TryParse(Session["ReadOnly"].ToString(), out x))
                {
                    return x;
                }

                return false;
            }
            set
            {
                Session["ReadOnly"] = value;
            }
        }

        private String LastClickedRPI
        {
            get
            {
                if (Session["LastClickedRPI"] != null)
                {
                    return Session["LastClickedRPI"].ToString();
                }

                return string.Empty;
            }
            set
            {
                Session["LastClickedRPI"] = value;
            }
        }

        #endregion

        #region " Page_Init "
        protected void Page_Init(object sender, EventArgs e)
        {
            LoadSections();
        }
        #endregion

        #region " Page Load "
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    hiLoggedInVzid.Value = Navigation.Current.LoggedInVzid;// Convert.ToString(Session["SsoLoginVzid"]);
                    hiLoggedInStsId.Value = Convert.ToString(Navigation.Current.LoggedInStsId);//Session["SsoLoginStsId"]);
                    hiLoggedInUserName.Value = Navigation.Current.UserName;// Convert.ToString(Session["userName"]);
                    hiLoggedInUserCurrentRole.Value = ((Int32)Navigation.Current.CurrentRole).ToString();// Convert.ToString(Session["currentUserRole"]);

                    if (Request.QueryString["request"] != null && !string.IsNullOrEmpty(Request.QueryString["request"]))
                    {
                        var decryptedQueryStrings = CryptoQueryStringHandler.GetDecryptedQueryStrings(Request.QueryString["request"]);
                        // Request Level Authentication (If required)
                        if (decryptedQueryStrings["FormId"] != null && !string.IsNullOrEmpty(decryptedQueryStrings["FormId"]))
                        {
                            Session["FormId"] = hiFormId.Value = decryptedQueryStrings["FormId"];
                        }
                        var LockedUserName = string.Empty;
                        if (decryptedQueryStrings["FormInstance"] != null && !string.IsNullOrEmpty(decryptedQueryStrings["FormInstance"]))
                        {
                            FormInstance = decryptedQueryStrings["FormInstance"];
                            lblFormInstance.Text = "Form Instance: " + FormInstance;
                            SetPrintURL();
                        }
                        else
                        {
                            FormInstance = string.Empty;
                            lblFormInstance.Text = string.Empty;
                            btnPrint.Visible = false;
                        }

                        if (decryptedQueryStrings["LegalName"] != null && !string.IsNullOrEmpty(decryptedQueryStrings["LegalName"]))
                        {
                            LegalName = decryptedQueryStrings["LegalName"];
                            lblFormInstance.Text = lblFormInstance.Text + " <br/>Company Name: " + LegalName;
                        }

                        if (decryptedQueryStrings["AllowOverride"] != null && Convert.ToBoolean(decryptedQueryStrings["AllowOverride"]) == true)
                        {
                            AllowOverride = Convert.ToBoolean(decryptedQueryStrings["AllowOverride"]);
                            chkOverRide.Checked = true;
                        }

                        if (decryptedQueryStrings["ReadOnly"] != null && !string.IsNullOrEmpty(decryptedQueryStrings["ReadOnly"]))
                        {
                            _ReadOnly = Convert.ToBoolean(decryptedQueryStrings["ReadOnly"]);
                            btnDraft.Visible = false;
                            btnSubmit.Visible = false;
                            chkOverRide.Enabled = false;
                            if (!String.IsNullOrEmpty(LockedUserName) && LockedUserName.Trim() != "self")
                            {
                                btnEdit.Visible = false;
                            }
                            else
                            {
                                btnEdit.Visible = true;
                            }

                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(FormInstance))
                            {
                                LockedUserName = isLock(FormInstance);
                                if (LockedUserName.Trim() == string.Empty && FormInstance.Trim() != string.Empty)
                                {
                                    LockID = InsertLock(FormInstance, LoggedInStsId);
                                }
                                else if (LockedUserName.Trim() != "self")
                                {
                                    lblLockedMessage.Text = "Lock Alert: This form has been locked by " + LockedUserName;
                                    LockID = 0;
                                }
                            }
                            _ReadOnly = false;
                            btnDraft.Visible = true;
                            btnSubmit.Visible = true;
                            btnEdit.Visible = false;
                        }
                        if (decryptedQueryStrings["IsEditable"] != null && !string.IsNullOrEmpty(decryptedQueryStrings["IsEditable"]))
                        {
                            if (decryptedQueryStrings["IsEditable"].ToString() == "False")
                            {
                                btnEdit.Visible = false;
                            }
                        }
                        if (decryptedQueryStrings["FormInstanceType"] != null && !string.IsNullOrEmpty(decryptedQueryStrings["FormInstanceType"]))
                        {
                            FormInstanceType = Convert.ToInt32(decryptedQueryStrings["FormInstanceType"]);
                        }
                        else
                        {
                            FormInstanceType = (int)InstanceType.Draft;
                        }

                        if (_ReadOnly)
                        {
                            LogUserAccess("View");
                        }
                        else
                        {
                            LogUserAccess("Edit");
                        }
                    }
                    lblMessage.Text = string.Empty;
                    divMessage.Visible = false;

                    if (LockID == 0)
                    {
                        _ReadOnly = true;
                        btnDraft.Visible = false;
                        btnSubmit.Visible = false;
                    }
                }

                //LoadSections();
                LoadContent();
            }
            catch (Exception ex)
            {
                ProcessException(ex, "Page_Load", "");
            }
        }
        #endregion

        #region " InsertLock "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="FormInstance"></param>
        /// <param name="stsId"></param>
        /// <returns></returns>
        private int InsertLock(string FormInstance, int stsId)
        {
            try
            {
                var BRTLockId = 0;
                DataTable dataTable = null;
                using (FormManager refMgr = new FormManager(Global.ABCConnectionString))
                {
                    dataTable = refMgr.InsertBRTLock(FormInstance, stsId);

                    if (dataTable != null && dataTable.Rows.Count > 0)
                    {
                        return BRTLockId = (int)dataTable.Rows[0]["BRTLockId"];
                    }
                }
            }
            catch (System.Threading.ThreadAbortException) { }
            catch (Exception ex)
            {
                ProcessException(ex, "InsertLock", "ins_BRTLock");
                return 0;
            }

            return 0;
        }

        #endregion

        #region " isLock "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="FormInstance"></param>
        /// <returns></returns>
        private string isLock(string FormInstance)
        {
            try
            {
                var lockName = string.Empty;
                DataTable dataTable = null;
                using (FormManager refMgr = new FormManager(Global.ABCConnectionString))
                {
                    dataTable = refMgr.GetBRTLock(FormInstance, LoggedInStsId);

                    if (dataTable != null && dataTable.Rows.Count > 0)
                    {
                        return lockName = (string)dataTable.Rows[0]["Name"];
                    }
                }
            }
            catch (System.Threading.ThreadAbortException) { }
            catch (Exception ex)
            {
                ProcessException(ex, "isLock", "qry_GetBRTLock");
            }

            return string.Empty;
        }

        #endregion

        #region " DeleteLock "
        /// <summary>
        /// DeleteLock
        /// </summary>
        /// <returns></returns>
        private void DeleteLock()
        {
            try
            {
                using (FormManager refMgr = new FormManager(Global.ABCConnectionString))
                {
                    refMgr.DeleteBRTLock(FormInstance, LoggedInStsId);
                }
            }
            catch (System.Threading.ThreadAbortException) { }
            catch (Exception ex)
            {
                ProcessException(ex, "DeleteLock", "del_BRTLock");
            }
        }

        #endregion

        #region " Page_LoadComplete "
        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            //RadAsyncUpload fileUpload = (RadAsyncUpload)Page.FindControl("MainContent_rpb_Section_i20_acMain_grdAttachments");
            //RadAjaxManager AjaxManager = (RadAjaxManager)Page.Master.FindControl("AjaxManager1");
            //AjaxManager1.AjaxSettings.AddAjaxSetting(fileUpload, fileUpload, null);
        }
        #endregion

        #region " Protected Methods "

        #region " SaveAnswers "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void SaveAnswers(object sender, RadPanelBarEventArgs e)
        {
            var rpi = (RadPanelItem)e.Item;
            if (e.Item.Value != LastClickedRPI)
            {

                SaveAnswersPerSection();
                if (!ValidateDependantQuestions())
                {
                    //e.Item.Value = LastClickedRPI;
                    foreach (RadPanelItem rpinner in rpb_Section.Items)
                    {
                        if (rpinner.Value == LastClickedRPI)
                        {
                            rpinner.Expanded = true;
                            LastClickedRPI = rpinner.Value;
                            break;
                        }
                    }
                }
                else
                {
                    LastClickedRPI = e.Item.Value;
                    lblFormInstance.Text = "Form Instance: " + FormInstance;
                    if (!string.IsNullOrEmpty(LegalName))
                    {
                        lblFormInstance.Text = lblFormInstance.Text + " <br/>Company Name: " + LegalName;
                    }
                    lblMessage.Text = string.Empty;
                    divMessage.Visible = false;
                    SetPrintURL();
                }
                ScriptManager.RegisterClientScriptBlock(this.Page, Page.GetType(), "hwa", "UpdateIsFormDataUnsaved();", true);
            }
        }
        #endregion

        #region " SaveAnswersPerSection "
        /// <summary>
        /// SaveAnswersPerSection
        /// </summary>
        protected void SaveAnswersPerSection()
        {
            RadPanelItem lastclicked = null;
            using (ControlFinder<RadPanelItem> flc = new ControlFinder<RadPanelItem>())
            {
                try
                {
                    flc.FindChildControlsRecursive(rpb_Section);

                    var flcc = flc.FoundControls;
                    if (flcc.Count() > 0)
                    {
                        lastclicked = flcc.FirstOrDefault(x => x.Value == LastClickedRPI);

                        using (ControlFinder<DynamicFields> dfcf = new ControlFinder<DynamicFields>())
                        {
                            dfcf.FindChildControlsRecursive(lastclicked);
                            var dynamicFields = dfcf.FoundControls;
                            using (FormManager refMgr = new FormManager(Global.ABCConnectionString))
                            {
                                if (String.IsNullOrEmpty(FormInstance))
                                {

                                    FormInstance = refMgr.GetNextFormInstance(Convert.ToInt32(hiFormId.Value));
                                    SetPrintURL();
                                }

                                AllowOverride = chkOverRide.Checked;
                                refMgr.SaveFormInstanceType(FormInstance, FormInstanceType, AllowOverride, LoggedInStsId);


                                foreach (DynamicFields dfs in dynamicFields)
                                {
                                    foreach (DynamicField df in dfs.Answers)
                                    {
                                        switch (df.CtrlType)
                                        {
                                            case (DynControlType.DatePicker):
                                                refMgr.SaveAnswers(Convert.ToInt32(df.Id), FormInstance, df.Text, LoggedInStsId);
                                                break;

                                            case (DynControlType.TextBox):
                                                refMgr.SaveAnswers(Convert.ToInt32(df.Id), FormInstance, df.Text.HtmlEncode(), LoggedInStsId);
                                                break;

                                            case (DynControlType.CheckBox):
                                                refMgr.SaveAnswers(Convert.ToInt32(df.Id), FormInstance, (df.FieldData != null) ? df.FieldData.ToString() : string.Empty, LoggedInStsId);
                                                break;

                                            case (DynControlType.DropDown):
                                                refMgr.SaveAnswers(Convert.ToInt32(df.Id), FormInstance, df.FieldData.ToString(), LoggedInStsId);
                                                break;

                                            case (DynControlType.Radio):
                                                refMgr.SaveAnswers(Convert.ToInt32(df.Id), FormInstance, (df.FieldData != null) ? df.FieldData.ToString() : string.Empty, LoggedInStsId);
                                                break;

                                            case (DynControlType.Attachment):
                                                try
                                                {
                                                    using (AttachmentManager am = new AttachmentManager(Global.ABCConnectionString))
                                                    {
                                                        var contenttype = string.Empty;
                                                        var fileext = string.Empty;
                                                        var filename = string.Empty;
                                                        DataTable insrows = null;
                                                        var attachment = new Attachment();
                                                        var filebytes = new Byte[0];
                                                        UploadedFile imageFile = null;

                                                        attachment.FormId = df.Form;
                                                        attachment.FormSectionId = Convert.ToInt32(df.Id);
                                                        attachment.AttachmentStream = filebytes;
                                                        var uploadedfileCol = (UploadedFileCollection)df.FieldData;
                                                        foreach (UploadedFile uploadedfile in uploadedfileCol)
                                                        {
                                                            if (uploadedfile.ContentLength > 0)
                                                            {
                                                                int outStsId;
                                                                imageFile = uploadedfile;
                                                                contenttype = uploadedfile.ContentType;
                                                                filename = uploadedfile.GetName();
                                                                fileext = uploadedfile.GetExtension();
                                                                attachment.AttachmentName = filename;

                                                                var fs = uploadedfile.InputStream;
                                                                using (var br = new BinaryReader(fs))
                                                                {
                                                                    if (!Int32.TryParse(hiLoggedInStsId.Value, out outStsId))
                                                                    {
                                                                        outStsId = -1;
                                                                    }

                                                                    insrows = am.InsertAttachmentWithStream(attachment, FormInstance, (int)AttachmentIdentifier.QuestionLevel, outStsId, fs);
                                                                    fs.Close();
                                                                }
                                                            }
                                                        }
                                                    }
                                                    var grd = (RadGrid)dfs.FindControl("gridAttachments" + df.Id);
                                                    if (grd != null)
                                                    {
                                                        grd.Visible = true;
                                                        using (AttachmentManager ams = new AttachmentManager(Global.ABCConnectionString))
                                                        {
                                                            using (DataTable _dt = ams.LoadAttachments(Convert.ToInt32(df.Id), FormInstance, (int)AttachmentIdentifier.QuestionLevel))
                                                            {
                                                                if (_dt != null && _dt.Rows.Count > 0)
                                                                {
                                                                    grd.DataSource = _dt;
                                                                }
                                                                else
                                                                {
                                                                    grd.DataSource = null;
                                                                }
                                                            }
                                                        }
                                                        grd.DataBind();
                                                    }
                                                }
                                                catch (System.Threading.ThreadAbortException) { }
                                                break;
                                        }
                                    }
                                }

                                //3884 - Rajesh Srigakolapu - Added a block to see if it is Management release section and update the form report status based on values.. 
                                if (!string.IsNullOrEmpty(FormInstance) && !chkOverRide.Checked) //&& LastClickedRPI == "19"
                                {
                                    refMgr.UpdateFormReportStatus(Convert.ToInt32(hiFormId.Value), Convert.ToInt32(LastClickedRPI), FormInstance, LoggedInStsId);
                                    //3982 - Rajesh Srigakolapu - Added code to update Form Review status based on the section, Form and Form Instance
                                    refMgr.UpdateFormReviewStatus(Convert.ToInt32(hiFormId.Value), Convert.ToInt32(LastClickedRPI), FormInstance, LoggedInStsId);
                                }
                            }
                        }
                        //hiIsFormDataUnsaved.Value = "0";
                    }
                }
                catch (Exception ex)
                {
                    //lblMessage.ForeColor = Color.Red;
                    divMessage.Visible = true;
                    divMessage.Attributes.Remove("class");
                    divMessage.Attributes.Add("class", "alert alert-danger clearfix");
                    lblMessage.Text = "An error occured, please try again.";
                    ProcessException(ex, "SaveAnswersPerSection", "ins_FormResponse", lastclicked.Text);
                }
            }

        }
        #endregion

        #region " btnDraft_Click "
        /// <summary>
        /// btnDraft_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDraft_Click(object sender, EventArgs e)
        {
            SaveAnswersPerSection();
            if (!ValidateDependantQuestions())
            {
                //e.Item.Value = LastClickedRPI;
                foreach (RadPanelItem rpinner in rpb_Section.Items)
                {
                    if (rpinner.Value == LastClickedRPI)
                    {
                        rpinner.Expanded = true;
                        LastClickedRPI = rpinner.Value;
                        break;
                    }
                }
            }
            else
            {
                //lblMessage.ForeColor = Color.Green;
                lblMessage.Text = "Form Instance " + FormInstance + " has been saved successfully.";
                divMessage.Visible = true;
                divMessage.Attributes.Remove("class");
                divMessage.Attributes.Add("class", "alert alert-success clearfix");
                Session["FormInstance"] = FormInstance;
                lblFormInstance.Text = string.Empty;
            }
            ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "hwa", "UpdateIsFormDataUnsaved();", true);
        }
        #endregion

        #region " btnSubmit_Click "
        /// <summary>
        /// btnSubmit_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (ValidateSections() && ValidateDependantQuestions())
            {
                SaveAnswersPerSection();
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "hwa", "UpdateIsFormDataUnsaved();", true);
                lblMessage.Text = "Form Instance " + FormInstance + " has been submited successfully.";
                divMessage.Visible = true;
                divMessage.Attributes.Remove("class");
                divMessage.Attributes.Add("class", "alert alert-success clearfix");
                Session["FormInstance"] = FormInstance;
                Session["IsSubmitted"] = "submitted";
                lblFormInstance.Text = string.Empty;
                using (FormManager refMgr = new FormManager(Global.ABCConnectionString))
                {
                    refMgr.SaveFormInstanceType(FormInstance, (int)InstanceType.Submitted, AllowOverride, LoggedInStsId);
                }
                FormInstanceType = (int)InstanceType.Submitted;
                btnDraft.Visible = false;
                btnSubmit.Visible = false;
                FormInstance = string.Empty;
                //lblMessage.ForeColor = Color.Green;
                Response.Redirect("Dashboard.aspx");
            }
        }
        #endregion

        #region " btnCancel_Click "

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            DeleteLock();
            Response.Redirect("~/ABCForm/Dashboard.aspx");
        }

        #endregion

        #region " grdOutput_NeedDataSource "
        /// <summary>
        /// grdOutput_NeedDataSource
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdOutput_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
        {
            var ans = new List<DynamicField>();

            using (ControlFinder<DynamicFields> dfcf = new ControlFinder<DynamicFields>())
            {
                dfcf.FindChildControlsRecursive(rpb_Section);
                var dynamicFields = dfcf.FoundControls;

                foreach (DynamicFields df in dynamicFields)
                {
                    ans.AddRange(df.Answers);
                }
            }
            grdOutput.DataSource = ans.OrderBy(x => x.Id);
        }
        #endregion

        #region " HideSections "
        /// <summary>/// HideSections
        /// </summary>
        protected void HideSections()
        {
            using (ControlFinder<RadPanelItem> picf = new ControlFinder<RadPanelItem>())
            {
                picf.FindChildControlsRecursive(rpb_Section);
                var sectionList = picf.FoundControls;
                foreach (RadPanelItem pi in sectionList)
                {
                    if (pi.Text != "Attach Documents")
                    {
                        using (ControlFinder<DynamicFields> dfcf = new ControlFinder<DynamicFields>())
                        {
                            dfcf.FindChildControlsRecursive(pi);
                            var section = dfcf.FoundControls;


                            var _visible = false;
                            foreach (DynamicFields df in section)
                            {
                                if (df.Count > 0)
                                {
                                    //pi.Text = pi.Text + " <img src='../Content/images/wild_card12.gif' id='wild_card' width='12px' height='12px' alt='' />";
                                    _visible = true;
                                    break;
                                }
                            }
                            pi.Visible = _visible;
                        }
                    }
                }
            }
        }
        #endregion

        #region " rpb_Section_ItemDataBound "
        protected void rpb_Section_ItemDataBound(object sender, RadPanelBarEventArgs e)
        {
            var rpi = (RadPanelItem)e.Item;
            rpi.ImageUrl = "~/Content/images/button_plus.gif";
            rpi.ExpandedImageUrl = "~/Content/images/button_minus.gif";
            rpi.Expanded = false;
        }
        #endregion

        #endregion

        #region " Private Methods "

        #region " Load Sections "
        private void LoadSections()
        {
            using (FormManager fManager = new FormManager(Global.ABCConnectionString))
            {
                var sections = fManager.GetSectionsByForm(1, Convert.ToInt32(Navigation.Current.CurrentRole), 2);//TODO: FORMID AND PRIVILEGE ID GET FROM SESSION
                if (sections.Count > 0)
                {
                    rpb_Section.DataTextField = "SectionDescription";
                    rpb_Section.DataValueField = "SectionId";
                    rpb_Section.DataFieldID = "SectionId";
                    rpb_Section.DataSource = sections;
                    rpb_Section.ItemClick += new RadPanelBarEventHandler(SaveAnswers);
                    rpb_Section.DataBind();
                    foreach (RadPanelItem rpi in rpb_Section.Items)
                    {
                        rpi.ViewStateMode = ViewStateMode.Enabled;
                    }
                    if (!IsPostBack)
                    {
                        //rpb_Section.Items[0].Expanded = true;
                        LastClickedRPI = rpb_Section.Items[0].Value;
                    }
                    //var rpiAttachments = new RadPanelItem("Attachments");
                    ////rpiAttachments.Value = "20";
                    //rpb_Section.Items.Add(rpiAttachments);
                }
            }
        }
        #endregion

        #region " Load Content "
        private void LoadContent()
        {
            var template = new CustomContentTemplate();
            foreach (RadPanelItem item in rpb_Section.Items)
            {
                item.ContentTemplate = new CustomContentTemplate();
                template.InstantiateIn(item, this.Page, Convert.ToInt32(hiFormId.Value), _ReadOnly, FormInstance);
                item.DataBind();
            }
        }
        #endregion

        #region " ValidateSections "
        /// <summary>
        /// ValidateSections
        /// </summary>
        /// <returns></returns>
        private bool ValidateSections()
        {
            var validated = true;

            //Find all sections
            using (ControlFinder<RadPanelItem> picf = new ControlFinder<RadPanelItem>())
            {
                picf.FindChildControlsRecursive(rpb_Section);
                var sectionList = picf.FoundControls;

                foreach (RadPanelItem pi in sectionList)
                {
                    //Find the Dynamic Controls
                    using (ControlFinder<DynamicFields> dfcf = new ControlFinder<DynamicFields>())
                    {
                        dfcf.FindChildControlsRecursive(pi);
                        var section = dfcf.FoundControls;
                        //Check Validation
                        var _valid = true;
                        foreach (DynamicFields df in section)
                        {
                            if (df.Validation > 0)
                            {
                                _valid = false;
                                validated = false;
                                break;
                            }
                        }

                        //Set the section color if not valid
                        pi.CssClass = (_valid == false) ? "dyn_section_yellow" : String.Empty;
                    }
                }
                return validated;
            }
        }
        #endregion

        #region " ValidateSections "
        /// <summary>
        /// ValidateDependantQuestions
        /// </summary>
        /// <returns></returns>
        private bool ValidateDependantQuestions()
        {
            var validated = true;

            using (FormManager fManager = new FormManager(Global.ABCConnectionString))
            {
                var dt = fManager.GetValidationResponse(FormInstance, Convert.ToInt32(hiFormId.Value), Convert.ToInt32(LastClickedRPI != string.Empty ? LastClickedRPI : "0"));

                if (dt.Rows.Count > 0)
                {
                    validated = false;

                    divMessage.Visible = true;
                    divMessage.Attributes.Remove("class");
                    divMessage.Attributes.Add("class", "alert alert-danger clearfix");
                    lblMessage.Text = dt.Rows[0]["ValidationMessage"].ToString();
                }
            }
            return validated;
        }
        #endregion

        #region " Attachments "
        private DataTable Attachments()
        {

            DataTable dataTable = null;
            try
            {
                if (ViewState["Attachments"] == null)
                {
                    using (dataTable = new DataTable())
                    {
                        var dr = dataTable.NewRow();
                        DataColumn column;

                        // Create new DataColumn, set DataType, ColumnName and add to DataTable.    
                        using (column = new DataColumn())
                        {
                            column.DataType = System.Type.GetType("System.Int32");
                            column.ColumnName = "AttachmentId";
                            dataTable.Columns.Add(column);
                        }
                        // Create second column.
                        using (column = new DataColumn())
                        {
                            column.DataType = Type.GetType("System.String");
                            column.ColumnName = "AttachmentName";
                            dataTable.Columns.Add(column);
                        }
                        // Create second column.
                        using (column = new DataColumn())
                        {
                            column.DataType = Type.GetType("System.String");
                            column.ColumnName = "Attachment";
                            dataTable.Columns.Add(column);
                        }

                        dr["AttachmentId"] = 1;
                        dr["AttachmentName"] = "DataMappingfor5ABCforms";
                        dr["Attachment"] = "DataMappingfor5ABCforms.xlsx";
                        dataTable.Rows.Add(dr);
                        ViewState["Attachments"] = dataTable;
                    }
                }
                else
                {
                    dataTable = (DataTable)ViewState["Attachments"];

                    var dr = dataTable.NewRow();

                    //dr["AttachmentId"] = dataTable.Rows.Count + 1;
                    //dr["AttachmentName"] = txtFormName.Text;
                    //dr["Attachment"] = AsyncUpload1.UploadedFiles[0].FileName;// questionLoader.FileName;

                    dataTable.Rows.InsertAt(dr, 0);
                }
                return dataTable;
            }
            catch (Exception ex)
            {
                if (!ex.Message.Contains("Object reference not set to an instance of an object"))
                {
                }
            }

            return dataTable;
        }
        #endregion

        #endregion

        #region " ProcessException "

        protected void ProcessException(Exception inEx, string inFunctionName, string inSPName, string sectionName = "",
                                        string answer = "")
        {
            var userName = string.Empty;
            if (Navigation.Current.UserName != null)
            {
                userName = Navigation.Current.UserName;
            }
            var excep = new ABCException
            {
                StsId = Convert.ToInt32(hiLoggedInStsId.Value),
                Name = userName,
                MethodName = inFunctionName,
                SpName = inSPName,
                PageName = "Form1.aspx.cs",
                FormInstance = FormInstance,
                SectionName = sectionName
            };
            inEx.HelpLink = ABCException.GetMoreInfoForException(excep);
            ExceptionPolicy.HandleException(inEx, Global.ApplicationLayerPolicy);
        }

        #endregion

        #region " SetPrintURL "
        private void SetPrintURL()
        {
            var url = Global.ReportUrl;
            
            if (!string.IsNullOrEmpty(FormInstance))
            {
                btnPrint.Visible = true;

                var nvc_Querystring = new NameValueCollection();
                nvc_Querystring.Add("FormInstanceId", FormInstance);

                hiCurrentFormInstanceId.Value = url + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]);
                printReport.Src = url + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]);
            }
        }
        #endregion

        #region " btnEdit_Click "
        /// <summary>
        /// btnEdit_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            _ReadOnly = false;
            var nvc_Querystring = new NameValueCollection();
            nvc_Querystring.Add("FormId", Session["FormId"].ToString());
            nvc_Querystring.Add("FormInstance", FormInstance);
            nvc_Querystring.Add("FormInstanceType", FormInstanceType.ToString());
            nvc_Querystring.Add("AllowOverride", AllowOverride.ToString());
            nvc_Querystring.Add("LegalName", HttpUtility.UrlEncode(LegalName));
            Response.Redirect(Request.Path + "?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
        }
        #endregion

        #region " updateProgress_Init "

        protected void updateProgress_Init(object sender, EventArgs e)
        {
            if (IsPostBack) { Session["reloadAttachments"] = "1"; }
        }

        #endregion

        private void Page_Error(object sender, EventArgs e)
        {
            var ex = Server.GetLastError();
            ProcessException(ex, "Page_Error", "");
            // Clear the error from the server
            Server.ClearError();
        }

        [WebMethod]
        public static string GetBRTAnalystInfo(string logonId)
        {
            try
            {
                var serializer = new JavaScriptSerializer();
                using (FormManager ism = new FormManager(Global.ABCConnectionString))
                {
                    var returnObj = ism.GetBRTAnalystInfo(logonId);
                    return serializer.Serialize(returnObj);
                }
            }
            catch (Exception ex)
            {
                ExceptionPolicy.HandleException(ex, Global.ApplicationLayerPolicy);
                HttpContext.Current.Response.StatusCode = 500; // Will be captured on ajax error method 
                return ex.Message;
            }

        }
        [WebMethod]
        public static void LogPrint()
        {
            using (var f1 = new Form1())
            {
                f1.LogUserAccess("Print");
            }
        }
        private void LogUserAccess(string eventType)
        {
            var loggedinStsId = Navigation.Current.LoggedInStsId;
            var loggedinUser = Navigation.Current.UserName;
            if (!string.IsNullOrEmpty(FormInstance))
            {
                using (FormManager fManager = new FormManager(Global.ABCConnectionString))
                {
                    fManager.InsertAuditViewPrint(FormInstance, loggedinStsId, loggedinUser, eventType);
                }
            }
        }
    }
}