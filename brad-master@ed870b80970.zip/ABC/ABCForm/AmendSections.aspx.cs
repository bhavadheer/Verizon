﻿using BusinessLogicLayer;
using Common;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ABC.ABCForm
{
    public partial class AmendSections : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region " ProcessException "

        protected static void ProcessException(Exception inEx, string inFunctionName, string inSPName, int stsId)
        {
            var userName = string.Empty;
            if (Navigation.Current.UserName != null)
            {
                userName = Navigation.Current.UserName;
            }
            var excep = new ABCException
            {
                StsId = stsId,
                Name = userName,
                MethodName = inFunctionName,
                SpName = inSPName,
                PageName = "AmendSections.aspx.cs"
            };
            inEx.HelpLink = ABCException.GetMoreInfoForException(excep);
            ExceptionPolicy.HandleException(inEx, Global.ApplicationLayerPolicy);
        }

        #endregion

        #region " DataTableToJSONWithJavaScriptSerializer "
        public static string DataTableToJSONWithJavaScriptSerializer(DataTable table)
        {
            var jsSerializer = new JavaScriptSerializer
            {
                MaxJsonLength = Int32.MaxValue
            };
            var parentRow = new List<Dictionary<string, object>>();
            Dictionary<string, object> childRow;
            foreach (DataRow row in table.Rows)
            {
                childRow = new Dictionary<string, object>();
                foreach (DataColumn col in table.Columns)
                {
                    childRow.Add(col.ColumnName, row[col]);
                }
                parentRow.Add(childRow);
            }
            return jsSerializer.Serialize(parentRow);
        }
        #endregion

        #region " Web Methods "

        [WebMethod]
        public static string LoadSections()
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (SectionManager dm = new SectionManager(Global.ABCConnectionString))
                {
                    var roleId = (Int32)Navigation.Current.CurrentRole;
                    using (var _dt1 = dm.GetSections())
                    {
                        if (_dt1 != null && _dt1.Rows.Count > 0)
                        {
                            result = DataTableToJSONWithJavaScriptSerializer(_dt1);
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "LoadSections", "qry_Sections", stsId);
            }
            return result;
        }

        [WebMethod]
        public static string LoadSectionForEdit(int sectionID)
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (SectionManager dm = new SectionManager(Global.ABCConnectionString))
                {
                    var roleId = (Int32)Navigation.Current.CurrentRole;
                    using (var _dt1 = dm.GetSections())
                    {
                        if (_dt1 != null && _dt1.Rows.Count > 0)
                        {
                            var filterTable = _dt1.Select("SectionID =" + sectionID).CopyToDataTable();
                            result = DataTableToJSONWithJavaScriptSerializer(filterTable);
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "LoadSections", "qry_Sections", stsId);
            }
            return result;
        }

        [WebMethod]
        public static bool UpdateSection(int sectionID, string sectionName, string sectionDesc)
        {
            var result = true;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (SectionManager dm = new SectionManager(Global.ABCConnectionString))
                {
                    dm.UpdateSections(sectionID, sectionName, sectionDesc, stsId);
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "UpdateSection", "dbo.upd_Sections", stsId);
                result = false;
            }
            return result;
        }

        [WebMethod]
        public static bool UpdateSectionOrder(string sectionOrderInfo)
        {
            var result = true;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (SectionManager dm = new SectionManager(Global.ABCConnectionString))
                {
                    dm.UpdateSectionOrder(sectionOrderInfo, stsId);
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "UpdateSectionOrder", "dbo.upd_SectionOrder", stsId);
                result = false;
            }
            return result;
        }

        #region " LoadDropDown "
        /** \private    LoadDropDown 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
        */
        [WebMethod]
        public static string LoadComboBox(string ddType)
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    var roleId = ((Int32)Navigation.Current.CurrentRole).ToString();// Session["currentUserRole"] != null ? Convert.ToString(Session["currentUserRole"]) : string.Empty;
                    // rdpFormSection is dependent on the selected rdpFormType dropDown
                    if (ddType == "rdpFormType")
                    {
                        using (var _dt1 = dm.GetFormsDropDownList())
                        {
                            if (_dt1 != null && _dt1.Rows.Count > 0)
                            {
                                result = DataTableToJSONWithJavaScriptSerializer(_dt1);
                            }
                        }
                    }
                    else
                    {
                        using (var _dt = dm.GetFormSectionDropDownList(Convert.ToInt32(ddType), Convert.ToInt32(roleId), 2))
                        {
                            result = DataTableToJSONWithJavaScriptSerializer(_dt);
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "LoadComboBox", "qry_GetFormsDropDown", stsId);
            }
            return result;
        }
        #endregion

        #region " LoadFormQuestions "
        /** \private    LoadDropDown 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
*/
        [WebMethod]
        public static string LoadFormQuestions(int formId, int sectionId)
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    var roleId = (Int32)Navigation.Current.CurrentRole;

                    using (var _dt1 = dm.GetFormQuestions(formId, sectionId, roleId))
                    {
                        if (_dt1 != null && _dt1.Rows.Count > 0)
                        {
                            result = DataTableToJSONWithJavaScriptSerializer(_dt1);
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "LoadFormQuestions", "qry_FormQuestionsBySectionId", stsId);
            }
            return result;
        }
        #endregion

        [WebMethod]
        public static bool UpdateFormSection(int newSectionID, string formSectionId)
        {
            var result = true;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (SectionManager dm = new SectionManager(Global.ABCConnectionString))
                {
                    foreach (string str in formSectionId.Split(','))
                    {
                        dm.UpdateFormSections(Convert.ToInt32(str), newSectionID, stsId);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "UpdateFormSection", "dbo.upd_FormSection", stsId);
                result = false;
            }
            return result;
        }

        #endregion
    }
}