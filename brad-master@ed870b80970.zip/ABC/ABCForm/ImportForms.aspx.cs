﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Common;
using BusinessLogicLayer;
using System.Data;
using System.Data.SqlClient;
using Telerik.Web.UI;
using System.IO;
using System.Data.OleDb;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using System.Threading;

namespace ABC.ABCForm
{
    public partial class ImportForms : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    hiLoggedInVzid.Value = Navigation.Current.LoggedInVzid;// Convert.ToString(Session["SsoLoginVzid"]);
                    hiLoggedInStsId.Value = Convert.ToString(Navigation.Current.LoggedInStsId);//Convert.ToString(Session["SsoLoginStsId"]);
                    hiLoggedInUserName.Value = Navigation.Current.UserName;// Convert.ToString(Session["userName"]);
                    hiLoggedInUserCurrentRole.Value = ((Int32)Navigation.Current.CurrentRole).ToString();// Convert.ToString(Session["currentUserRole"]);
                    //hiLoggedInUserCurrentRoleFlag.Value = Convert.ToString(Session["currentUserRoleFlag"]);
                    //hiLoggedInUserCurrentLOB.Value = Convert.ToString(Session["currentUserLob"]);
                    //hiLoggedInUserCurrentGroupNumber.Value = Convert.ToString(Session["currentUserGroupNumber"]);

                    radUpload.TemporaryFolder = Path.Combine(Global.TempPathForFile, "UploadTemp");
                    //radUpload.TargetFolder = string.Empty;// Path.Combine(Global.TempPathForFile, "UploadTarget");
                    LoadDropDown(radForms);

                }
            }
            catch (Exception ex)
            {
                divSearchStatus.Visible = true;//.Text = "Error occured while loading page";
                ExceptionPolicy.HandleException(ex, Global.ApplicationLayerPolicy);
            }

        }

        #region " LoadDropDown "
        /** \private    LoadDropDown 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/10/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      dropDown   RadComboBox
        */
        private void LoadDropDown(Telerik.Web.UI.RadComboBox dropDown)
        {
            try
            {
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    DataTable _dt1 = new DataTable();
                    _dt1 = dm.GetFormsDropDownList();
                    if (_dt1 != null && _dt1.Rows.Count > 0)
                    {
                        for (int i = 0; i < _dt1.Rows.Count; i++)
                        {
                            dropDown.Items.Add(new Telerik.Web.UI.RadComboBoxItem(_dt1.Rows[i]["Name"].ToString(), _dt1.Rows[i]["FormID"].ToString()));
                        }
                    }
                }

                /* Add default value */
                dropDown.Items.Insert(0, new Telerik.Web.UI.RadComboBoxItem("-- Choose Value --", "0"));
            }

            catch (Exception ex)
            {
                ExceptionPolicy.HandleException(ex, Global.ApplicationLayerPolicy);
            }
        }
        #endregion

        #region " radForms_SelectedIndexChanged "
        /** \protected  radForms_SelectedIndexChanged 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/10/2016
         *  \details    Upon dropdown change, loads Forms Template to download
         *  \param      o object
         *  \param      e RadComboBoxSelectedIndexChangedEventArgs
         */
        protected void radForms_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            if (radForms.SelectedIndex != 0)
            {
                String formValue;
                formValue = radForms.SelectedItem.Text;
                ViewState["fileName"] = formValue;
                lnkDownloadTemplate.Visible = true;
                lnkDownloadTemplate.Text = "Download " + formValue + " Template";
                div1.Visible = false;
                //lblButtonStatus.Visible = false;
                lblImportErrors.Visible = false;
                grdImportsErrors.Visible = false;
                btnExportErrorsToExcel.Visible = false;
            }
            else
            {
                lnkDownloadTemplate.Visible = false;
            }
        }
        #endregion

        #region " lnkDownloadTemplate_Click "
        /** \protected  lnkDownloadTemplate_Click 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/11/2016
         *  \details    This Method is called to download a form template.
         *  \param      sender object
         *  \param      e EventArgs
         */
        protected void lnkDownloadTemplate_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = GetFormInfo(Convert.ToInt32(radForms.SelectedValue), Convert.ToInt32(hiLoggedInUserCurrentRole.Value));
                string fileName = Path.Combine(Global.TempPathForFile, radForms.SelectedItem.Text + hiLoggedInStsId.Value + DateTime.Now.GetTimeStamp() + ".xlsx");
                dt.Columns.Add("Response1", typeof(String));
                dt.Columns.Add("Response2", typeof(String));
                dt.Columns.Add("Response3", typeof(String));
                dt.Columns.Add("Response4", typeof(String));
                dt.Columns.Add("Response5", typeof(String));
                dt.Columns.Add("Response6", typeof(String));
                dt.Columns.Add("Response7", typeof(String));
                dt.Columns.Add("Response8", typeof(String));
                dt.Columns.Add("Response9", typeof(String));
                dt.Columns.Add("Response10", typeof(String));
                dt.Columns.Add("Response11", typeof(String));
                dt.Columns.Add("Response12", typeof(String));
                dt.Columns.Add("Response13", typeof(String));
                dt.Columns.Add("Response14", typeof(String));
                dt.Columns.Add("Response15", typeof(String));
                dt.Columns.Add("Response16", typeof(String));
                dt.Columns.Add("Response17", typeof(String));
                dt.Columns.Add("Response18", typeof(String));
                dt.Columns.Add("Response19", typeof(String));
                dt.Columns.Add("Response20", typeof(String));

                dt.ExportToExcel(fileName);
                //dt.ExportToExcelOpenXML(fileName);
                if (fileName != "")
                {
                    System.IO.FileInfo file = new System.IO.FileInfo(fileName);
                    if (file.Exists)
                    {
                        Response.Clear();
                        Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name);
                        Response.AddHeader("Content-Length", file.Length.ToString());
                        Response.ContentType = "application/octet-stream";
                        Response.WriteFile(file.FullName);
                        HttpContext.Current.Response.Flush(); // Sends all currently buffered output to the client.
                        HttpContext.Current.Response.SuppressContent = true;  // Gets or sets a value indicating whether to send HTTP content to the client.
                        HttpContext.Current.ApplicationInstance.CompleteRequest(); // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.

                        File.Delete(fileName);
                    }
                    else
                    {
                        //Page page = HttpContext.Current.Handler as Page;
                        //string error = "This file does not exist.";
                        //ScriptManager.RegisterStartupScript(page, page.GetType(), "err_msg", "alert('" + error + "');", true);
                        //lblButtonStatus.ForeColor = System.Drawing.Color.Red;
                        div1.Visible = true;
                        div1.Attributes.Remove("class");
                        div1.Attributes.Add("class", "alert alert-danger clearfix");
                        lblButtonStatus.Text = "This file does not exist.";

                    }
                }
            }
            catch (ThreadAbortException)
            {

            }
            catch (Exception ex)
            {
                div1.Visible = true;
                div1.Attributes.Remove("class");
                div1.Attributes.Add("class", "alert alert-danger clearfix");
                //lblButtonStatus.ForeColor = System.Drawing.Color.Red;
                lblButtonStatus.Text = "Error while downloading the excel- " + ex.Message.ToString();
                lblButtonStatus.Visible = true;
                grdImportsErrors.Visible = false;
                lblImportErrors.Visible = false;
                btnExportErrorsToExcel.Visible = false;
                ExceptionPolicy.HandleException(ex, Global.ApplicationLayerPolicy);
            }
        }
        #endregion

        #region " GetFormInfo "
        /** \private    GetFormInfo 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/11/2016
         *  \details    This Method gets the form information.
         *  \param      FormId int
         *  \param      RoleId int
         *  \return     A DataTable
         */
        private DataTable GetFormInfo(int FormId, int RoleId)
        {
            DataTable _dtForm = null;

            try
            {
                /**Create ImportManager object to get all items*/
                using (ImportManager iptMgr = new ImportManager(Global.ABCConnectionString))
                {
                    _dtForm = iptMgr.GetFormInfo(FormId, RoleId);
                }
            }
            catch (Exception ex)
            {
                ExceptionPolicy.HandleException(ex, Global.ApplicationLayerPolicy);
            }
            return _dtForm;
        }
        #endregion

        #region " btnImport_Click "
        /** \protected  btnImport_Click 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/10/2016
         *  \details    This method is called upon click on btnImport .
         *  \param      sender object
         *  \param      e EventArgs
         */
        protected void btnImport_Click(object sender, EventArgs e)
        {
            try
            {
                if (radForms.SelectedIndex != 0 && radUpload.UploadedFiles.Count > 0)
                {
                    string strDate = DateTime.Now.ToString();
                    hiStrDate.Value = strDate;
                    string mpath = Global.TempPathForFile;
                    // Calling the bulkexcelupload method where we can upload the excelfile and load in to the Table.
                    BulkExcelUpload(mpath, hiLoggedInVzid.Value, strDate);
                }

                else
                {
                    div1.Visible = true;
                    div1.Attributes.Remove("class");
                    div1.Attributes.Add("class", "alert alert-danger clearfix");
                    //lblButtonStatus.ForeColor = System.Drawing.Color.Red;
                    lblButtonStatus.Text = "Please select the Form and Upload excel files to import.";
                    //lblButtonStatus.Visible = true;
                    grdImportsErrors.Visible = false;
                    lblImportErrors.Visible = false;
                    btnExportErrorsToExcel.Visible = false;
                }
            }
            catch (Exception ex)
            {
                div1.Visible = true;
                div1.Attributes.Remove("class");
                div1.Attributes.Add("class", "alert alert-danger clearfix");
                //lblButtonStatus.ForeColor = System.Drawing.Color.Red;
                lblButtonStatus.Text = "Error while importing the data from excel- " + ex.Message.ToString();
                grdImportsErrors.Visible = false;
                lblImportErrors.Visible = false;
                btnExportErrorsToExcel.Visible = false;
                ExceptionPolicy.HandleException(ex, Global.ApplicationLayerPolicy);
            }
        }
        #endregion

        #region " BulkExcelUpload  "
        /* \private    BulkExcelUpload 
        *  \section    First Draft
        *  \author     Bharath Bellam
        *  \date       03/14/2016
        *  \details    Method to upload data from Excel into table 
        *  \param      sender object
        *  \param      e EventArgs 
        */
        private void BulkExcelUpload(string mpath, string vzid, string strDate)
        {
            string sheetName = "";
            bool uploadSuccess = false;
            if (radUpload.UploadedFiles.Count > 0)
            {
                foreach (UploadedFile file in radUpload.UploadedFiles)
                {
                    string targetFileName = System.IO.Path.Combine(mpath, file.GetNameWithoutExtension() + file.GetExtension());
                    file.SaveAs(targetFileName);
                    OleDbConnection connection = null;
                    try
                    {
                        string connectionString = string.Empty;
                        string fName = file.FileName;
                        string fExtension = fName.Substring(fName.LastIndexOf(".") + 1);

                        hiFileName.Value = fName;

                        if (fExtension == "xls")
                        {
                            connectionString = ExcelImport(fExtension, targetFileName);
                        }
                        else if (fExtension == "xlsx")
                        {
                            connectionString = ExcelImport(fExtension, targetFileName);
                        }


                        connection = new OleDbConnection(connectionString);
                        connection.Open();

                        /* Read all excel entries into datatable */
                        DataTable xlTable = new DataTable();
                        xlTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                        for (int lngStart = 0; lngStart < xlTable.Rows.Count; lngStart++)
                        {
                            //Remove the single-quote surrounding the table name
                            sheetName = xlTable.Rows[lngStart][2].ToString().Replace("'", "");
                            if (sheetName.EndsWith("$") && (sheetName.Contains("sheet1") || sheetName.Contains("Table")))
                            {
                                /* Read all excel entries into this datatable */
                                DataTable dtExcelLoad = new DataTable();
                                OleDbDataAdapter adapter = new OleDbDataAdapter("SELECT * FROM [" + sheetName.Substring(0, sheetName.Length) + "]", connection);

                                /* Fill the datatable */
                                adapter.Fill(dtExcelLoad);

                                //Excel Data modification to delete Empty columns and Rows
                                //Deleting Extra Columns.
                                int NoofColumns = 27;
                                if (dtExcelLoad.Columns.Count > NoofColumns)
                                {
                                    for (int i = NoofColumns; i >= NoofColumns && i < dtExcelLoad.Columns.Count; )
                                    {
                                        dtExcelLoad.Columns.RemoveAt(i);
                                    }
                                }

                                dtExcelLoad.Columns.Add("StsId", typeof(Int32));
                                dtExcelLoad.Columns.Add("CreatedDate", typeof(DateTime));

                                foreach (DataRow DR in dtExcelLoad.Rows)
                                {
                                    DR["StsId"] = hiLoggedInStsId.Value;
                                    DR["CreatedDate"] = DateTime.Now;
                                }

                                /* Insert all data from data table in to the database using SQL Bulk Copy */
                                using (SqlConnection connection1 = new SqlConnection(Global.ABCConnectionString))
                                {
                                    /*Bulk Upload Function to insert in to the database*/
                                    SqlBulkCopy bulkCopy = new SqlBulkCopy(connection1, SqlBulkCopyOptions.TableLock | SqlBulkCopyOptions.FireTriggers | SqlBulkCopyOptions.UseInternalTransaction | SqlBulkCopyOptions.KeepIdentity, null);
                                    connection1.Open();

                                    //Set table to insert records
                                    bulkCopy.DestinationTableName = "FormImportQuestionBank";

                                    bulkCopy.ColumnMappings.Add(0, "FormName");
                                    bulkCopy.ColumnMappings.Add(1, "SectionName");
                                    bulkCopy.ColumnMappings.Add(2, "QuestionId");
                                    bulkCopy.ColumnMappings.Add(3, "Identifier");
                                    bulkCopy.ColumnMappings.Add(4, "QuestionText");
                                    bulkCopy.ColumnMappings.Add(5, "ResponseType");
                                    bulkCopy.ColumnMappings.Add(6, "DropdownData");
                                    bulkCopy.ColumnMappings.Add(7, "ResponseText1");
                                    bulkCopy.ColumnMappings.Add(8, "ResponseText2");
                                    bulkCopy.ColumnMappings.Add(9, "ResponseText3");
                                    bulkCopy.ColumnMappings.Add(10, "ResponseText4");
                                    bulkCopy.ColumnMappings.Add(11, "ResponseText5");
                                    bulkCopy.ColumnMappings.Add(12, "ResponseText6");
                                    bulkCopy.ColumnMappings.Add(13, "ResponseText7");
                                    bulkCopy.ColumnMappings.Add(14, "ResponseText8");
                                    bulkCopy.ColumnMappings.Add(15, "ResponseText9");
                                    bulkCopy.ColumnMappings.Add(16, "ResponseText10");
                                    bulkCopy.ColumnMappings.Add(17, "ResponseText11");
                                    bulkCopy.ColumnMappings.Add(18, "ResponseText12");
                                    bulkCopy.ColumnMappings.Add(19, "ResponseText13");
                                    bulkCopy.ColumnMappings.Add(20, "ResponseText14");
                                    bulkCopy.ColumnMappings.Add(21, "ResponseText15");
                                    bulkCopy.ColumnMappings.Add(22, "ResponseText16");
                                    bulkCopy.ColumnMappings.Add(23, "ResponseText17");
                                    bulkCopy.ColumnMappings.Add(24, "ResponseText18");
                                    bulkCopy.ColumnMappings.Add(25, "ResponseText19");
                                    bulkCopy.ColumnMappings.Add(26, "ResponseText20");
                                    bulkCopy.ColumnMappings.Add(27, "StsId");
                                    bulkCopy.ColumnMappings.Add(28, "CreatedDate");

                                    /* Insert all data from data table in to the database */
                                    bulkCopy.WriteToServer(dtExcelLoad);
                                    connection1.Close();
                                    hiRowCount.Value = dtExcelLoad.Rows.Count.ToString();
                                }
                                connection.Close();
                                uploadSuccess = true;

                            }
                            else
                            {
                                connection.Close();
                                div1.Visible = true;
                                div1.Attributes.Remove("class");
                                div1.Attributes.Add("class", "alert alert-danger clearfix");
                                //lblButtonStatus.ForeColor = System.Drawing.Color.Red;
                                lblButtonStatus.Text = "The Excel file does not contain required Sheet.";
                                //lblButtonStatus.Visible = true;
                                grdImportsErrors.Visible = false;
                                lblImportErrors.Visible = false;
                                btnExportErrorsToExcel.Visible = false;

                            }
                        }


                        if (File.Exists(targetFileName))
                        {
                            File.Delete(targetFileName);
                        }
                    }
                    catch (Exception ex)
                    {
                        if (connection.State == ConnectionState.Open)
                        {
                            connection.Close();
                        }
                        if (File.Exists(mpath))
                        {
                            File.Delete(mpath);
                        }
                        throw new Exception(ex.Message.ToString() + " Please make sure the column names are in correct format in the Excel sheet: " + sheetName);
                        //throw ex;
                    }
                    if (uploadSuccess)
                    {
                        using (ImportManager imptMgr = new ImportManager(Global.ABCConnectionString))
                        {
                            DataTable _dtErrors = GetFormImportErrors();
                            ViewState["importErrors"] = _dtErrors;
                            //_dtErrors = imptMgr.ValidateFormImport();
                            if (_dtErrors != null && _dtErrors.Rows.Count > 0)
                            {
                                grdImportsErrors.DataSource = _dtErrors;
                                grdImportsErrors.DataBind();
                                div1.Visible = false;
                                //lblButtonStatus.Visible = false;
                                grdImportsErrors.Visible = true;
                                lblImportErrors.Visible = true;
                                btnExportErrorsToExcel.Visible = true;
                            }
                            else
                            {
                                imptMgr.InsertFormImportQuestionBank(Convert.ToInt32(radForms.SelectedValue), Convert.ToInt32(hiLoggedInUserCurrentRole.Value), Convert.ToInt32(hiLoggedInStsId.Value));
                                //When no error during the import, display a success message
                                div1.Visible = true;
                                div1.Attributes.Remove("class");
                                div1.Attributes.Add("class", "alert alert-success clearfix");
                                //lblButtonStatus.ForeColor = System.Drawing.Color.Green;
                                lblButtonStatus.Text = "Successfully Imported Records.";
                                //lblButtonStatus.Visible = true;
                                grdImportsErrors.Visible = false;
                                lblImportErrors.Visible = false;
                                btnExportErrorsToExcel.Visible = false;
                            }
                        }
                    }
                }
            }
        }
        #endregion

        #region " ExcelImport "
        /** \private    ExcelImport 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/14/2016
         *  \details    Get the Excel Connection string 
         *  \param      fExtension string 
         *  \param      FilePath string 
         */
        private string ExcelImport(string fExtension, string FilePath)
        {
            string mConnString = "";
            string ProviderExcel = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=";
            string ExtendedPropertiesExcel = ";Extended Properties='Excel 8.0;IMEX=1;HDR=YES'";

            string ProviderExcel2007 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=";
            string ExtendedPropertiesExcel2007 = ";Extended Properties='Excel 12.0;IMEX=1;HDR=YES'";

            switch (fExtension)
            {
                case "xls":
                    mConnString = ProviderExcel + FilePath + ExtendedPropertiesExcel;
                    break;
                case "xlsx":
                    mConnString = ProviderExcel2007 + FilePath + ExtendedPropertiesExcel2007;
                    break;
            }

            return mConnString;
        }
        #endregion

        #region " btnClear_Click "
        /** \protected  btnImport_Click 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/15/2016
         *  \details    This method is called to clear the seclection .
         *  \param      sender object
         *  \param      e EventArgs
         */
        protected void btnClear_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("ImportForms.aspx", false);
            }
            catch (Exception)
            {

            }
        }
        #endregion

        #region " GetFormImportErrors "
        /** \private    GetFormImportErrors 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/24/2016
         *  \details    This Method gets the form import errors.
         *  \return     A DataTable
         */
        private DataTable GetFormImportErrors()
        {
            DataTable _dtErrors = null;

            try
            {
                /**Create ImportManager object to get all items*/
                using (ImportManager iptMgr = new ImportManager(Global.ABCConnectionString))
                {
                    _dtErrors = iptMgr.ValidateFormImport(Convert.ToInt32(hiLoggedInStsId.Value));
                }
            }
            catch (Exception ex)
            {
                ExceptionPolicy.HandleException(ex, Global.ApplicationLayerPolicy);
            }
            return _dtErrors;
        }
        #endregion

        #region " grdImportsErrors_NeedDataSource "
        /** \protected  grdImportsErrors_NeedDataSource 
         *  \author     Bharath Bellam
         *  \date       03/24/2016
         *  \details    This method sets the Datasource and primarykey for the grid in this NeedDataSource Event for Refreshing or Event in a grid. 
         *  \param      source object
         *  \param      e GridNeedDataSourceEventArgs
         */
        protected void grdImportsErrors_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
        {
            if (ViewState["importErrors"] != null)
            {
                DataTable dt = (DataTable)ViewState["importErrors"];
                grdImportsErrors.DataSource = dt;
            }
        }
        #endregion

        #region " btnExportErrorsToExcel_Click "
        /** \protected  btnExportErrorsToExcel_Click 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/31/2016
         *  \details    This method will export the products in same category to Excel.
         *  \param      sender object
         *  \param      e EventArgs
         */
        protected void btnExportErrorsToExcel_Click(object sender, EventArgs e)
        {
            try
            {
                grdImportsErrors.ExportSettings.ExportOnlyData = true;
                grdImportsErrors.ExportSettings.IgnorePaging = true;
                grdImportsErrors.ExportSettings.OpenInNewWindow = true;
                grdImportsErrors.MasterTableView.ExportToExcel();
            }
            catch (Exception)
            {

            }
        }
        #endregion

        protected void grdImportsErrors_ItemCreated(object sender, GridItemEventArgs e)
        {
            if (e.Item is GridPagerItem)
            {
                var PageSizeCombo = (RadComboBox)e.Item.FindControl("PageSizeComboBox");
                PageSizeCombo.RenderMode = RenderMode.Lightweight;
            }
        }
    }
}