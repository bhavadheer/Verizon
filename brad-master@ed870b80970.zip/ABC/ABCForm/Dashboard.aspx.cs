﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogicLayer;
using System.Data;
using System.Data.SqlClient;
using Telerik.Web.UI;
using System.Text.RegularExpressions;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using System.Collections.Specialized;
using System.Web.Configuration;
using Verizon.QueryStringEncryption;
using Common;
using System.Web.Services;
using System.Web.Script.Serialization;
using System.Web.UI.HtmlControls;

namespace ABC.ABCForm
{
    public partial class Dashboard : System.Web.UI.Page
    {
        protected class QuestionData
        {
            public int Id { get; set; }
            public string Form { get; set; }
            public string Person { get; set; }
            public DateTime CreateDate { get; set; }
            public DateTime MonthYear { get; set; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                this.Header.DataBind();
                if (!IsPostBack)
                {
                    hfAccordionIndex.Value = Request.Form[hfAccordionIndex.UniqueID];
                    hiLoggedInVzid.Value = Navigation.Current.LoggedInVzid;// Convert.ToString(Session["SsoLoginVzid"]);
                    hiLoggedInStsId.Value = Convert.ToString(Navigation.Current.LoggedInStsId);
                    if (Navigation.Current.ShowDelete == 1)
                    {
                        icEditIdentifier.Style.Clear();
                        icEditIdentifier.Style.Add("cursor", "pointer");
                        icEditIdentifier.Style.Add("display", "");
                    }
                    LoadComboBox("rdpFormType", rdpFormType, -1, 0);
                    LoadComboBox("radCmbQueFilter", radCmbQueFilter, -1, 0);
                    LoadDropdownByCategory("MarkIfUrgent", rdpIsUrgent);
                    LoadDropdownByCategory("CurrentReportStatus", rdpCurrentReportStatus);
                    LoadDropdownByCategory("CurrentReviewStatus", rdpCurrentReviewStatus);
                    LoadPersonnelDropDown();
                    rdpShowType.SelectedValue = "3";
                    rdpFrom.SelectedDate = DateTime.Now.AddDays(-30);
                    rdpTo.SelectedDate = DateTime.Now;

                    var _dtSearch = GetExistingFormsData();

                    if (_dtSearch != null && _dtSearch.Rows.Count > 0)
                    {
                        grdDashboard.DataSource = _dtSearch;
                        grdDashboard.DataBind();
                        divFormExport.Visible = true;
                    }
                    else
                    {
                        ////rpb_Section.
                        //var panel = ((RadPanelItem)(rpb_Section.FindItemByValue("rpb_DashBoard")));
                        //panel.Visible = false;
                        grdDashboard.Visible = false;
                        divFormExport.Visible = false;
                    }
                    txtInstanceIdentifier.Attributes.Add("onkeypress", "return isNumberKey(event)");
                    txtInstanceYear.Attributes.Add("onkeypress", "return isNumberKey(event)");
                }
            }
            catch (Exception ex)
            {
                ProcessException(ex, "Page_Load", "");
            }
        }

        #region " LoadPersonnelDropDown "
        /** \private    LoadPersonnelDropDown 
         *  \author     David Martinez
         *  \date       03/21/2016
         *  \details    Retrieve personnel list.
         *  \param      none
        */
        private void LoadPersonnelDropDown()
        {
            try
            {
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    using (var dt = dm.GetPersonnelList())
                    {
                        if (dt != null && dt.Rows.Count > 0)
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                var li = new RadComboBoxItem(dt.Rows[i]["Name"].ToString(), dt.Rows[i]["StsId"].ToString());
                                rdpPersonnel.Items.Add(li);
                            }
                        }
                    }
                }

                var liFirst = new RadComboBoxItem("-- Choose Value --", "0");
                rdpPersonnel.Items.Insert(0, liFirst);
            }
            catch (System.Threading.ThreadAbortException) { }
            catch (Exception ex)
            {
                ProcessException(ex, "LoadPersonnelDropDown", "GetPersonnelList()");
            }
        }

        #endregion

        #region " LoadDropDown "
        /** \private    LoadDropDown 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
        */
        private void LoadDropDown(string ddType, Telerik.Web.UI.RadDropDownList dropDown)
        {
            try
            {
                #region " Try Block "

                /** First un-select any selected item */
                dropDown.ClearSelection();
                dropDown.Items.Clear(); //Remove any previously loaded items
                dropDown.SelectedIndex = -1;
                /**Create DashboardManager object and bind values to dropdowns*/
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    var roleId = ((Int32)Navigation.Current.CurrentRole).ToString();// Session["currentUserRole"] != null ? Convert.ToString(Session["currentUserRole"]) : string.Empty;
                    if (roleId == string.Empty)
                    {
                        // roleId = "103"; //Pass Default Admin role, later need to remove this line
                    }
                    var vzid = hiLoggedInVzid.Value;// Session["SsoLoginVzid"] != null ? Convert.ToString(Session["SsoLoginVzid"]) : string.Empty;

                    // rdpFormSection is dependent on the selected rdpFormType dropDown
                    if (ddType == "rdpFormType")
                    {
                        using (var _dt1 = dm.GetFormsDropDownList())
                        {
                            if (_dt1 != null && _dt1.Rows.Count > 0)
                            {
                                for (int i = 0; i < _dt1.Rows.Count; i++)
                                {
                                    var li = new DropDownListItem(_dt1.Rows[i]["Name"].ToString(), _dt1.Rows[i]["FormID"].ToString());
                                    dropDown.Items.Add(li);
                                }
                            }
                        }
                    }
                    else
                    {
                        using (DataTable _dt = dm.GetFormSectionDropDownList(Convert.ToInt32(ddType), Convert.ToInt32(roleId), 2))
                        {
                            dropDown.DataSource = _dt;
                            dropDown.DataTextField = "SectionDescription";
                            dropDown.DataValueField = "SectionId";
                            dropDown.DataBind();
                        }
                    }

                    /* Add default value */
                    var liFirst = new DropDownListItem("-- Choose Value --", "0");
                    dropDown.Items.Insert(0, liFirst);
                }

                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "LoadDropDown", "qry_FormSections");
            }
        }
        #endregion

        #region " LoadComboBox "
        /** \private    LoadDropDown 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
        */
        private void LoadComboBox(string ddType, Telerik.Web.UI.RadComboBox dropDown, int ParentSelectedItem, int elementId = -1)
        {
            try
            {
                #region " Try Block "

                /** First un-select any selected item */
                dropDown.ClearSelection();
                dropDown.Items.Clear(); //Remove any previously loaded items
                dropDown.SelectedIndex = -1;
                /**Create DashboardManager object and bind values to dropdowns*/
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    var roleId = ((Int32)Navigation.Current.CurrentRole).ToString();// Session["currentUserRole"] != null ? Convert.ToString(Session["currentUserRole"]) : string.Empty;
                    if (roleId == string.Empty)
                    {
                        // roleId = "103"; //Pass Default Admin role, later need to remove this line
                    }
                    var vzid = hiLoggedInVzid.Value;// Session["SsoLoginVzid"] != null ? Convert.ToString(Session["SsoLoginVzid"]) : string.Empty;

                    // rdpFormSection is dependent on the selected rdpFormType dropDown
                    if (ddType == "rdpFormType")
                    {
                        using (var _dt1 = dm.GetFormsDropDownList())
                        {
                            if (_dt1 != null && _dt1.Rows.Count > 0)
                            {
                                for (int i = 0; i < _dt1.Rows.Count; i++)
                                {
                                    var li = new RadComboBoxItem(_dt1.Rows[i]["Name"].ToString(), _dt1.Rows[i]["FormID"].ToString());
                                    dropDown.Items.Add(li);
                                }
                            }
                        }
                    }
                    else if (ddType == "radCmbQueFilter")
                    {
                        using (var _dt1 = dm.GetGlobalFilter())
                        {
                            if (_dt1 != null && _dt1.Rows.Count > 0)
                            {
                                for (int i = 0; i < _dt1.Rows.Count; i++)
                                {
                                    var li = new RadComboBoxItem(_dt1.Rows[i]["QuestionText"].ToString(), _dt1.Rows[i]["FormQuestionID"].ToString());
                                    dropDown.Items.Add(li);
                                }
                            }
                        }
                    }
                    else
                    {
                        using (DataTable _dt = dm.GetFormSectionDropDownList(Convert.ToInt32(ddType), Convert.ToInt32(roleId), 2))
                        {
                            dropDown.DataSource = _dt;
                            dropDown.DataTextField = "SectionDescription";
                            dropDown.DataValueField = "SectionId";
                            dropDown.DataBind();
                        }
                    }

                    /* Add default value */
                    var liFirst = new RadComboBoxItem("-- Choose Value --", "0");
                    dropDown.Items.Insert(0, liFirst);
                }

                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "LoadComboBox", "qry_GetFormsDropDown");
            }

        }
        #endregion

        #region " LoadDropdownByCategory "
        /** \private    LoadDropDown 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
        */
        private void LoadDropdownByCategory(string ddType, Telerik.Web.UI.RadComboBox dropDown)
        {
            try
            {
                #region " Try Block "

                /** First un-select any selected item */
                dropDown.ClearSelection();
                dropDown.Items.Clear(); //Remove any previously loaded items
                dropDown.SelectedIndex = -1;
                /**Create DashboardManager object and bind values to dropdowns*/
                using (DropDownDataManager dm = new DropDownDataManager(Global.ABCConnectionString))
                {
                    var roleId = ((Int32)Navigation.Current.CurrentRole).ToString();// Session["currentUserRole"] != null ? Convert.ToString(Session["currentUserRole"]) : string.Empty;
                    if (roleId == string.Empty)
                    {
                        // roleId = "103"; //Pass Default Admin role, later need to remove this line
                    }
                    var vzid = hiLoggedInVzid.Value;// Session["SsoLoginVzid"] != null ? Convert.ToString(Session["SsoLoginVzid"]) : string.Empty;

                    // rdpFormSection is dependent on the selected rdpFormType dropDown
                    using (DataTable _dt = dm.GetAllDropDownDataByCategory(ddType))
                    {
                        dropDown.DataSource = _dt;
                        dropDown.DataTextField = "DisplayValue";
                        dropDown.DataValueField = "DDID";
                        dropDown.DataBind();
                    }

                    /* Add default value */
                    var liFirst = new RadComboBoxItem("-- Choose Value --", "0");
                    dropDown.Items.Insert(0, liFirst);
                }

                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "LoadComboBox", "qry_GetFormsDropDown");
            }

        }
        #endregion

        #region " LoadDropdownByCategory "
        /** \private    LoadDropDown 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
        */
        private void LoadAnalysts(RadComboBox dropDown)
        {
            try
            {
                #region " Try Block "

                /** First un-select any selected item */
                dropDown.ClearSelection();
                dropDown.Items.Clear(); //Remove any previously loaded items
                dropDown.SelectedIndex = -1;
                /**Create DashboardManager object and bind values to dropdowns*/
                using (FormManager dm = new FormManager(Global.ABCConnectionString))
                {
                    // rdpFormSection is dependent on the selected rdpFormType dropDown
                    using (DataTable _dt = dm.GetBRTAnalysts())
                    {
                        dropDown.DataSource = _dt;
                        dropDown.DataTextField = "FullName";
                        dropDown.DataValueField = "LogonId";
                        dropDown.DataBind();
                    }

                    /* Add default value */
                    var liFirst = new RadComboBoxItem("-- Choose Value --", "0");
                    dropDown.Items.Insert(0, liFirst);
                }

                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "LoadComboBox", "qry_GetFormsDropDown");
            }

        }
        #endregion

        #region " grdDashboard Events "

        protected void grdDashboard_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            grdDashboard.DataSource = GetExistingFormsData();
        }

        protected void grdDashboard_ItemCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
        {
            if (e.Item is GridDataItem)
            {
                var item = (GridDataItem)e.Item;

                var nvc_Querystring = new NameValueCollection();
                nvc_Querystring.Add("FormId", item["ID"].Text);
                nvc_Querystring.Add("FormInstance", item["FormInstance"].Text);
                nvc_Querystring.Add("FormInstanceType", item["FTID"].Text);
                nvc_Querystring.Add("IsEditable", item["IsActive"].Text);
                nvc_Querystring.Add("AllowOverride", item["AllowOverride"].Text);
                nvc_Querystring.Add("LegalName", item["LegalName"].Text == "&nbsp;" ? string.Empty : HttpUtility.UrlEncode(item["LegalName"].Text));

                switch (e.CommandName)
                {
                    case "Edit":
                        {
                            try
                            {
                                switch (item["ID"].Text)
                                {
                                    case ("1"):
                                        Response.Redirect("../ABCForm/Form1.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                    case ("2"):
                                        Response.Redirect("../ABCForm/Form2.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                    case ("3"):
                                        Response.Redirect("../ABCForm/Form3.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                    case ("4"):
                                        Response.Redirect("../ABCForm/Form4.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                    case ("5"):
                                        Response.Redirect("../ABCForm/Form5.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                }
                            }
                            catch (ThreadAbortException)
                            { /* Do Nothing */ }
                        }
                        break;

                    case "View":
                        {
                            nvc_Querystring.Add("ReadOnly", "true");
                            try
                            {
                                switch (item["ID"].Text)
                                {
                                    case ("1"):
                                        Response.Redirect("../ABCForm/Form1.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                    case ("2"):
                                        Response.Redirect("../ABCForm/Form2.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                    case ("3"):
                                        Response.Redirect("../ABCForm/Form3.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                    case ("4"):
                                        Response.Redirect("../ABCForm/Form4.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                    case ("5"):
                                        Response.Redirect("../ABCForm/Form5.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                }
                            }
                            catch (ThreadAbortException)
                            { /* Do Nothing */ }
                        }
                        break;
                    case "Delete":
                        var isActive = false;
                        var btn = (Button)item["Delete"].Controls[0];
                        if (btn != null && btn.Text == "Un-Delete")
                        {
                            isActive = true;
                        }

                        using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                        {
                            var dd = dm.DeleteForm(item["FormInstance"].Text, isActive, Navigation.Current.LoggedInStsId);
                        }
                        break;
                }
            }
        }

        protected void grdDashboard_PreRender(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                foreach (GridColumn column in grdDashboard.MasterTableView.Columns)
                {
                    switch (column.UniqueName)
                    {
                        case "FTID":
                            column.Display = false;
                            break;
                    }
                }
            }
        }

        protected void grdDashboard_ItemDataBound(object sender, GridItemEventArgs e)
        {
            if (e.Item is GridDataItem)
            {
                var ditem = (GridDataItem)e.Item;
                var btn = (Button)ditem["Delete"].Controls[0];
                var btnEdit = (Button)ditem["Edit"].Controls[0];
                var showDelete = ditem["ShowDelete"].Text;
                var isFormActive = ditem["IsActive"].Text;
                var analystName = ditem["AnalystName"].Text;
                var isUrgent = ditem["MarkIfUrgent"].Text;
                var analystId = ditem["AnalystID"].Text;
                var icon = (HtmlControl)ditem["NotesCol"].Controls[0].FindControl("i1");
                var notes = ditem["Notes"].Text == "&nbsp;" ? string.Empty : ditem["Notes"].Text;
                var FormInstance = ditem["FormInstance"].Text;
                var FormId = ditem["ID"].Text;

                if (showDelete == "1")
                {
                    btn.Visible = true;
                    if (isFormActive == "False")
                    {
                        btnEdit.Visible = false;
                        btn.Text = "Un-Delete";
                        btn.ToolTip = "Un-Delete";
                    }
                }
                else
                {
                    btn.Visible = false;
                }
                if (string.IsNullOrEmpty(analystName) || analystName == "&nbsp;")
                {
                    if (isUrgent == "Urgent")
                    {
                        ditem.BackColor = System.Drawing.Color.IndianRed;
                    }
                    else
                    {
                        ditem.CssClass = "dyn_field_yellow";
                    }
                }

                var cmbAnalyst = ditem.FindControl("cmbBrtAnalyst") as RadComboBox;
                if (cmbAnalyst != null)
                {
                    LoadAnalysts(cmbAnalyst);
                    if (!string.IsNullOrEmpty(analystId) && analystId != "&nbsp;")
                    {
                        var cmbItem = cmbAnalyst.FindItemByValue(analystId);
                        if (cmbItem != null)
                        {
                            cmbItem.Selected = true;
                        }
                    }
                }

                if (icon != null)
                {
                    if (notes != string.Empty)
                    {
                        icon.Attributes.Add("onclick", "LoadNotes(" + FormId + ",\"" + FormInstance + "\",\"" + notes.Replace(Environment.NewLine, "new line").Replace("\n", "new line") + "\")");
                        icon.Attributes.Add("title", notes);
                    }
                    else
                    {
                        icon.Visible = false;
                    }
                }
            }
        }

        protected void grdDashboard_ItemCreated(object sender, GridItemEventArgs e)
        {
            if (e.Item is GridPagerItem)
            {
                var PageSizeCombo = (RadComboBox)e.Item.FindControl("PageSizeComboBox");
                PageSizeCombo.RenderMode = RenderMode.Lightweight;
            }
        }

        #endregion

        #region " btnSearch_Click "
        /** \protected  btnSearch_Click 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/01/2016
         *  \details    This method is called upon click on btnsearch .
         *  \param      sende object
         *  \param      e EventArgs
         */
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable _dtSearch = null;
                /** Call GetExistingFormsData() to load datatable */
                using (_dtSearch = GetExistingFormsData())
                {
                    if (_dtSearch != null && _dtSearch.Rows.Count > 0)
                    {
                        ViewState["GetExistingFormsData"] = _dtSearch;
                        grdDashboard.Visible = true;
                        /** bind results to grdDashboard grid */
                        grdDashboard.DataSource = _dtSearch;
                        grdDashboard.DataBind();
                        //lblSearchError.Visible = false;
                        divSearchError.Visible = false;
                    }
                    else
                    {
                        grdDashboard.Visible = false;
                        divSearchError.Visible = true;
                    }

                }
            }
            catch (Exception ex)
            {
                ProcessException(ex, "btnSearch_Click", "qry_FormsSearch");
            }

        }
        #endregion

        #region " GetExistingFormsData "
        /** \private    GetExistingFormsData 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       06/22/2012
         *  \details    This method searchs for and retrieve existing Forms data based on user entered data in key fields.
         *  \return     DataTable
         */
        private DataTable GetExistingFormsData()
        {
            DataTable _dtSearch = null;
            var FormName = 0;
            var currentReportStatus = string.Empty;
            var currentReviewStatus = string.Empty;
            var analystName = string.Empty;
            var FormInstance = string.Empty;
            DateTime dummydate;
            var DateFromCreated = Convert.ToDateTime("01/01/1900");
            var DateToCreated = Convert.ToDateTime("01/01/1900");

            var vzid = !string.IsNullOrEmpty(hiLoggedInStsId.Value) ? Convert.ToInt32(hiLoggedInStsId.Value) : 0;
            var ShowType = Convert.ToInt32(rdpShowType.SelectedValue);
            var isUrgent = string.Empty;
            if (rdpFormType.SelectedIndex > 0)
            {
                FormName = Convert.ToInt32(rdpFormType.SelectedValue);
            }
            if (rdpCurrentReportStatus.SelectedIndex > 0)
            {
                currentReportStatus = rdpCurrentReportStatus.SelectedItem.Text;
            }
            if (rdpPersonnel.SelectedIndex > 0)
            {
                analystName = rdpPersonnel.SelectedItem.Text;
            }
            if ((rdpFrom.SelectedDate).ToString() != string.Empty)
            {
                // added to prevent data conversion issues
                if (DateTime.TryParse(rdpFrom.SelectedDate.ToString(), out dummydate))
                {
                    DateFromCreated = dummydate;
                }
            }
            if ((rdpTo.SelectedDate).ToString() != string.Empty)
            {
                // added to prevent data conversion issues
                if (DateTime.TryParse(rdpTo.SelectedDate.ToString(), out dummydate))
                {
                    DateToCreated = dummydate;
                }
            }

            if (rdpFormType.SelectedIndex != 0)
            {
                if (txtInstanceYear.Text != string.Empty)
                {
                    FormInstance += rdpFormType.SelectedItem.Text.Trim() + "-" + txtInstanceYear.Text.Trim();
                    if (txtInstanceIdentifier.Text != string.Empty)
                    {
                        FormInstance += "-" + txtInstanceIdentifier.Text.Trim();
                    }
                }
            }

            if (rdpIsUrgent.SelectedIndex > 0)
            {
                isUrgent = rdpIsUrgent.SelectedItem.Text;
            }

            if (rdpCurrentReviewStatus.SelectedIndex > 0)
            {
                currentReviewStatus = rdpCurrentReviewStatus.SelectedItem.Text;
            }

            try
            {
                /** Query for existing Rsik Profile records based on user entered data.*/
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    _dtSearch = dm.GetFormsSearch(FormName, FormInstance, currentReportStatus, analystName,
                                                    DateFromCreated, DateToCreated, ShowType, Navigation.Current.LoggedInStsId,
                                                    isUrgent, currentReviewStatus);
                }
            }
            catch (System.Threading.ThreadAbortException) { }
            catch (Exception ex)
            {
                ProcessException(ex, "GetExistingFormsData", "qry_FormsSearch");
            }
            return _dtSearch;
        }
        #endregion

        #region " rdpFormType_SelectedIndexChanged "
        /** \protected  rdpFormType_SelectedIndexChanged 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    Upon dropdown Formname change loads the FormSection dropdown
         *  \param      o object
         *  \param      e RadDropDownListSelectedIndexChangedEventArgs
         */
        protected void rdpFormType_SelectedIndexChanged(object sender, Telerik.Web.UI.DropDownListEventArgs e)
        {

        }
        #endregion

        #region " btnMainSearch_Click "

        protected void btnMainSearch_Click(object sender, EventArgs e)
        {
            GetGlobalSearchResults();
            grdSearchResults.Rebind();

        }

        #endregion

        #region " grdSearchResults Events "

        #region " grdSearchResults_PreRender "

        protected void grdSearchResults_PreRender(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                foreach (GridColumn column in grdSearchResults.MasterTableView.Columns)
                {
                    switch (column.UniqueName)
                    {
                        case "FormID":
                            column.Display = false;
                            break;
                    }
                }
            }
        }

        #endregion

        #region " grdSearchResults_ItemDataBound "

        protected void grdSearchResults_ItemDataBound(object sender, GridItemEventArgs e)
        {
            if (e.Item is GridDataItem)
            {
                var dataItem = e.Item as GridDataItem;
                var drv = e.Item.DataItem as DataRowView;

                var searchText = txtMainSearch.Value.Trim();
                var tt = drv.Row["QuestionText"].ToString();
                if (tt != string.Empty)
                {
                    if (tt.IndexOf(searchText.Trim(), StringComparison.CurrentCultureIgnoreCase) > 0)
                    {
                        var actualString = tt.Substring(tt.IndexOf(searchText.Trim(), StringComparison.CurrentCultureIgnoreCase), searchText.Length);
                        var hightLightFormat = "<mark>" + actualString + "</mark>";
                        var highlightText = Regex.Replace(tt, actualString, hightLightFormat, RegexOptions.IgnoreCase);
                        dataItem["QuestionText"].Text = highlightText;
                    }
                }

                tt = drv.Row["AnswerText"].ToString();
                if (tt != string.Empty)
                {
                    if (tt.IndexOf(searchText.Trim(), StringComparison.CurrentCultureIgnoreCase) > 0)
                    {
                        var actualString = tt.Substring(tt.IndexOf(searchText.Trim(), StringComparison.CurrentCultureIgnoreCase), searchText.Length);
                        var hightLightFormat = "<mark>" + actualString + "</mark>";
                        var highlightText = Regex.Replace(tt, actualString, hightLightFormat, RegexOptions.IgnoreCase);
                        dataItem["AnswerText"].Text = highlightText;
                    }
                }
            }
        }

        #endregion

        #region " grdSearchResults_NeedDataSource "

        protected void grdSearchResults_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
        {
            GetGlobalSearchResults();
        }

        #endregion

        #region " grdSearchResults_ItemCommand "

        protected void grdSearchResults_ItemCommand(object sender, GridCommandEventArgs e)
        {
            if (e.Item is GridDataItem)
            {
                var item = (GridDataItem)e.Item;
                var nvc_Querystring = new NameValueCollection();
                nvc_Querystring.Add("FormId", item["FormID"].Text);
                nvc_Querystring.Add("FormInstance", item["FormInstance"].Text == "&nbsp;" ? string.Empty : item["FormInstance"].Text);
                nvc_Querystring.Add("LegalName", item["LegalName"].Text == "&nbsp;" ? string.Empty : HttpUtility.UrlEncode(item["LegalName"].Text));

                //if (string.IsNullOrEmpty(item["AnswerText"].Text))
                //{
                nvc_Querystring.Add("ReadOnly", "true");
                //}
                switch (item["FormID"].Text)
                {
                    case ("1"):
                        Response.Redirect("../ABCForm/Form1.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                        break;
                    case ("2"):
                        Response.Redirect("../ABCForm/Form2.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                        break;
                    case ("3"):
                        Response.Redirect("../ABCForm/Form3.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                        break;
                    case ("4"):
                        Response.Redirect("../ABCForm/Form4.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                        break;
                    case ("5"):
                        Response.Redirect("../ABCForm/Form5.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                        break;
                }

            }
        }

        #endregion

        protected void grdSearchResults_ItemCreated(object sender, GridItemEventArgs e)
        {
            if (e.Item is GridPagerItem)
            {
                var PageSizeCombo = (RadComboBox)e.Item.FindControl("PageSizeComboBox");
                PageSizeCombo.RenderMode = RenderMode.Lightweight;
            }
        }

        #endregion

        #region " GetGlobalSearchResults "

        protected void GetGlobalSearchResults()
        {
            try
            {
                if ((txtMainSearch.Value.Trim() != string.Empty || rdpDDValues.SelectedValue != "-1") && rdoSearchType.SelectedIndex != -1)
                {
                    using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                    {
                        var searchstring = !rdpDDValues.Visible ? txtMainSearch.Value.Trim().HtmlEncode() : rdpDDValues.SelectedItem.Text;
                        var searchType = Convert.ToInt32(rdoSearchType.SelectedItem.Value);
                        using (DataTable dt = dm.GetGlobalSearch(searchstring, radCmbQueFilter.SelectedValue == "0" ? 0 : Convert.ToInt32(radCmbQueFilter.SelectedValue), searchType))
                        {
                            if (dt != null && dt.Rows.Count > 0)
                            {
                                grdSearchResults.Visible = true;
                                //lblSearchStatus.Visible = false;
                                grdSearchResults.DataSource = dt;
                                divExport.Visible = true;
                                divSearchStatus.Visible = false;
                                lblGlobalSearchMessage.Text = "";
                            }
                            else
                            {
                                grdSearchResults.DataSource = new string[] { };
                                grdSearchResults.Visible = false;
                                //lblSearchStatus.Visible = true;
                                divSearchStatus.Visible = true;
                                lblGlobalSearchMessage.Text = "No Search results found!";
                            }
                        }
                    }
                }
                else
                {
                    divSearchStatus.Visible = true;
                    lblGlobalSearchMessage.Text = "Please enter Search string and select the type!";
                    grdSearchResults.DataSource = new string[] { };
                }
            }
            catch (Exception ex)
            {
                ProcessException(ex, "GetGlobalSearchResults", "qry_GlobalSearch");
            }
        }

        #endregion

        #region " ProcessException "

        protected void ProcessException(Exception inEx, string inFunctionName, string inSPName)
        {
            var userName = string.Empty;
            if (Navigation.Current.UserName != null)
            {
                userName = Navigation.Current.UserName;
            }
            var excep = new ABCException
            {
                StsId = Convert.ToInt32(hiLoggedInStsId.Value),
                Name = userName,
                MethodName = inFunctionName,
                SpName = inSPName,
                PageName = "Dashboard.aspx.cs"
            };
            inEx.HelpLink = ABCException.GetMoreInfoForException(excep);
            ExceptionPolicy.HandleException(inEx, Global.ApplicationLayerPolicy);
        }

        #endregion

        protected void btnGlobalClear_Click(object sender, EventArgs e)
        {
            txtMainSearch.Value = string.Empty;
            //lblSearchStatus.Visible = false;
            divSearchStatus.Visible = false;
            lblGlobalSearchMessage.Text = "";
            divExport.Visible = false;
            grdSearchResults.DataSource = new string[] { };
            grdSearchResults.DataBind();
            grdSearchResults.Visible = false;
            rdpDDValues.Visible = false;
            radCmbQueFilter.SelectedValue = "0";
            txtMainSearch.Visible = true;
            // GetGlobalSearchResults();
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            Response.Redirect("Dashboard.aspx", false);
        }

        #region " ExportGlobalSearchResults "

        protected void abtnExportExcel_ServerClick(object sender, EventArgs e)
        {
            try
            {
                if (txtMainSearch.Value.Trim() != string.Empty || rdpDDValues.SelectedValue != "-1")
                {
                    using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                    {
                        var searchstring = !rdpDDValues.Visible ? txtMainSearch.Value.Trim().HtmlEncode() : rdpDDValues.SelectedItem.Text;
                        var searchType = Convert.ToInt32(rdoSearchType.SelectedItem.Value);
                        using (DataTable dt = dm.ExportGlobalSearchResults(searchstring, radCmbQueFilter.SelectedValue == "0" ? 0 : Convert.ToInt32(radCmbQueFilter.SelectedValue), searchType))
                        {
                            if (dt != null && dt.Rows.Count > 0)
                            {
                                ABCExtensions.ExportToExcel(dt);
                            }
                            else
                            {
                                divSearchStatus.Visible = true;
                                lblGlobalSearchMessage.Text = "No Search results available to export!";
                            }
                        }
                    }
                }
                else
                {
                    divSearchStatus.Visible = true;
                    lblGlobalSearchMessage.Text = "Please enter Search string!";
                }
            }
            catch (Exception ex)
            {
                ProcessException(ex, "abtnExportExcel_ServerClick", "qry_ExportGlobalSearch");
            }
        }
        #endregion

        //you can call this function every time you need to set specific pane to open
        //positon
        private void SetAccordionPane(int idx)
        {
            var s = "<script type=\"text/javascript\">var paneIndex = " + idx + "</script>";
            ScriptManager.RegisterStartupScript(this, GetType(), "ss", s, true);
        }

        protected void radCmbQueFilter_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            if (radCmbQueFilter.SelectedValue != "0")
            {
                using (DashboardManager dManger = new DashboardManager(Global.ABCConnectionString))
                {
                    var dt = dManger.GetGlobalFilter();
                    var dRow = dt.Select("FormQuestionID=" + radCmbQueFilter.SelectedValue);
                    if (dRow.Count() > 0)
                    {
                        var str = dRow.FirstOrDefault()["DropDownIdentifier"].ToString();
                        if (!string.IsNullOrEmpty(str))
                        {
                            txtMainSearch.Visible = false;
                            rdpDDValues.Visible = true;
                            rdpDDValues.Items.Clear();
                            using (DropDownDataManager ddManager = new DropDownDataManager(Global.ABCConnectionString))
                            {
                                rdpDDValues.Items.Add(new RadComboBoxItem("-- Choose Value --", "-1"));
                                using (System.Data.DataTable _dt = ddManager.GetAllDropDownDataByCategory(str))
                                {
                                    for (int i = 0; i < _dt.Rows.Count; i++)
                                    {
                                        rdpDDValues.Items.Add(new RadComboBoxItem(_dt.Rows[i]["DisplayValue"].ToString(), _dt.Rows[i]["DDId"].ToString()));
                                    }
                                }

                            }
                        }
                        else
                        {
                            rdpDDValues.Visible = false;
                            txtMainSearch.Visible = true;
                        }
                    }
                }
            }
            else
            {
                rdpDDValues.Visible = false;
                txtMainSearch.Visible = true;
            }
        }

        #region " LoadFormQuestions "
        /** \private    LoadDropDown 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
*/
        [WebMethod]
        public static string LoadFormQuestions()
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {

                    using (var _dt1 = dm.GetQuestionsGlobalCategory())
                    {
                        if (_dt1 != null && _dt1.Rows.Count > 0)
                        {
                            result = DataTableToJSONWithJavaScriptSerializer(_dt1);
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "LoadFormQuestions", "qry_QuestionsGlobalCategory", stsId);
            }
            return result;
        }
        #endregion

        #region " InsertGlobalQuestions "
        /** \private    LoadDropDown 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
*/
        [WebMethod]
        public static void InsertGlobalQuestions(string questionIds)
        {
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "
                /**Create DashboardManager object and bind values to dropdowns*/
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    dm.InsertGlobalCatQuestions(questionIds, stsId);
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "InsertGlobalQuestions", "upd_GlobalSearchCategory", stsId);
            }
        }
        #endregion

        #region " DataTableToJSONWithJavaScriptSerializer "
        public static string DataTableToJSONWithJavaScriptSerializer(DataTable table)
        {
            var jsSerializer = new JavaScriptSerializer
            {
                MaxJsonLength = Int32.MaxValue
            };
            var parentRow = new List<Dictionary<string, object>>();
            Dictionary<string, object> childRow;
            foreach (DataRow row in table.Rows)
            {
                childRow = new Dictionary<string, object>();
                foreach (DataColumn col in table.Columns)
                {
                    childRow.Add(col.ColumnName, row[col]);
                }
                parentRow.Add(childRow);
            }
            return jsSerializer.Serialize(parentRow);
        }
        #endregion

        #region " ProcessException "

        protected static void ProcessException(Exception inEx, string inFunctionName, string inSPName, int stsId)
        {
            var userName = string.Empty;
            if (Navigation.Current.UserName != null)
            {
                userName = Navigation.Current.UserName;
            }
            var excep = new ABCException
            {
                StsId = stsId,
                Name = userName,
                MethodName = inFunctionName,
                SpName = inSPName,
                PageName = "Dashboard.aspx.cs"
            };
            inEx.HelpLink = ABCException.GetMoreInfoForException(excep);
            ExceptionPolicy.HandleException(inEx, Global.ApplicationLayerPolicy);
        }

        #endregion

        protected void abtnExportFormSearch_ServerClick(object sender, EventArgs e)
        {
            try
            {

                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    var FormName = 0;
                    var currentReportStatus = string.Empty;
                    var currentReviewStatus = string.Empty;
                    var anaylystName = string.Empty;
                    var FormInstance = string.Empty;
                    DateTime dummydate;
                    var DateFromCreated = Convert.ToDateTime("01/01/1900");
                    var DateToCreated = Convert.ToDateTime("01/01/1900");
                    var isUrgent = string.Empty;
                    var vzid = !string.IsNullOrEmpty(hiLoggedInStsId.Value) ? Convert.ToInt32(hiLoggedInStsId.Value) : 0;
                    var ShowType = Convert.ToInt32(rdpShowType.SelectedValue);

                    if (rdpFormType.SelectedIndex > 0)
                    {
                        FormName = Convert.ToInt32(rdpFormType.SelectedValue);
                    }
                    if (rdpCurrentReportStatus.SelectedIndex > 0)
                    {
                        currentReportStatus = rdpCurrentReportStatus.SelectedItem.Text;
                    }

                    if (rdpPersonnel.SelectedIndex > 0)
                    {
                        anaylystName = rdpPersonnel.SelectedItem.Text;
                    }
                    if ((rdpFrom.SelectedDate).ToString() != string.Empty)
                    {
                        // added to prevent data conversion issues
                        if (DateTime.TryParse(rdpFrom.SelectedDate.ToString(), out dummydate))
                        {
                            DateFromCreated = dummydate;
                        }
                    }
                    if ((rdpTo.SelectedDate).ToString() != string.Empty)
                    {
                        // added to prevent data conversion issues
                        if (DateTime.TryParse(rdpTo.SelectedDate.ToString(), out dummydate))
                        {
                            DateToCreated = dummydate;
                        }
                    }

                    if (rdpFormType.SelectedIndex != 0)
                    {
                        if (txtInstanceYear.Text != string.Empty)
                        {
                            FormInstance += rdpFormType.SelectedItem.Text.Trim() + "-" + txtInstanceYear.Text.Trim();
                            if (txtInstanceIdentifier.Text != string.Empty)
                            {
                                FormInstance += "-" + txtInstanceIdentifier.Text.Trim();
                            }
                        }
                    }

                    if (rdpIsUrgent.SelectedIndex > 0)
                    {
                        isUrgent = rdpIsUrgent.SelectedItem.Text;
                    }

                    if (rdpCurrentReviewStatus.SelectedIndex > 0)
                    {
                        currentReviewStatus = rdpCurrentReviewStatus.SelectedItem.Text;
                    }

                    using (DataTable dt = dm.ExportFormSearchResults(FormName, FormInstance, currentReportStatus,
                                                                    anaylystName, DateFromCreated, DateToCreated,
                                                                    ShowType, Navigation.Current.LoggedInStsId,
                                                                    isUrgent, currentReviewStatus))
                    {
                        if (dt != null && dt.Rows.Count > 0)
                        {
                            ABCExtensions.ExportToExcel(dt);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                ProcessException(ex, "abtnExportFormSearch_ServerClick", "qry_ExportFormsSearch");
            }
        }
        //4027 - added this code to save Name field and due to the architechture the code looks redundant but no other way.. 
        protected void cmbBrtAnalyst_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            try
            {
                var ddlCtrl = sender as RadComboBox;
                if (ddlCtrl != null)
                {
                    var ditem = ddlCtrl.Parent.Parent as GridDataItem;
                    if (ditem != null)
                    {
                        var formId = ditem["Id"].Text;
                        var analystSectionId = ditem["AnalystSectionID"].Text;
                        var formInstance = ditem["FormInstance"].Text;
                        var analystId = ddlCtrl.SelectedValue;// ditem["AnalystID"].Text;
                        var allowOverride = Convert.ToBoolean(ditem["AllowOverride"].Text);
                        var stsId = Navigation.Current.LoggedInStsId;
                        if (!string.IsNullOrEmpty(formInstance) && !string.IsNullOrEmpty(analystId))
                        {
                            using (FormManager fm = new FormManager(Global.ABCConnectionString))
                            {
                                if (analystId != "0")
                                {
                                    var analysInfo = fm.GetBRTAnalystInfo(analystId);
                                    if (analysInfo != null)
                                    {
                                        foreach (BRTAnalyst banalyst in analysInfo)
                                        {
                                            var formSectionId = fm.GetFormSectionIdByQuestion(Convert.ToInt32(formId), 16, 323);
                                            if (formSectionId > 0)
                                            {
                                                fm.SaveAnswers(formSectionId, formInstance, banalyst.LogonId, stsId);
                                            }
                                            formSectionId = fm.GetFormSectionIdByQuestion(Convert.ToInt32(formId), 16, 324);
                                            if (formSectionId > 0)
                                            {
                                                fm.SaveAnswers(formSectionId, formInstance, banalyst.Email, stsId);
                                            }
                                            formSectionId = fm.GetFormSectionIdByQuestion(Convert.ToInt32(formId), 16, 325);
                                            if (formSectionId > 0)
                                            {
                                                fm.SaveAnswers(formSectionId, formInstance, banalyst.WorkPhone, stsId);
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    var formSectionId = fm.GetFormSectionIdByQuestion(Convert.ToInt32(formId), 16, 323);
                                    fm.SaveAnswers(formSectionId, formInstance, string.Empty, stsId);
                                    formSectionId = fm.GetFormSectionIdByQuestion(Convert.ToInt32(formId), 16, 324);
                                    fm.SaveAnswers(formSectionId, formInstance, string.Empty, stsId);
                                    formSectionId = fm.GetFormSectionIdByQuestion(Convert.ToInt32(formId), 16, 325);
                                    fm.SaveAnswers(formSectionId, formInstance, string.Empty, stsId);
                                    //fm.UpdateFormReportStatus(Convert.ToInt32(formId), 28, formInstance, stsId);

                                }
                                if (!allowOverride)
                                {
                                    fm.UpdateFormReportStatus(Convert.ToInt32(formId), 28, formInstance, stsId);
                                }
                            }
                            grdDashboard.Rebind();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ProcessException(ex, "cmbBrtAnalyst_SelectedIndexChanged", "SaveAnswers");
            }
        }

        #region " UpdateNotes "
        /** \private    UpdateNotes 
         *  \section    First Draft
         *  \author     Rajesh Srigakolapu
         *  \date       02/07/2018
         *  \details    This method to update notes for a form.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
*/
        [WebMethod]
        public static void UpdateNotes(int formId, string formInstance, string notes)
        {
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "
                /**Create DashboardManager object and bind values to dropdowns*/
                using (FormManager fm = new FormManager(Global.ABCConnectionString))
                {
                    //28 -Section: Additional Questions/Actions, 429 - Notes
                    //Get Formsectionid to save response as per the form type.
                    var formSectionId = fm.GetFormSectionIdByQuestion(formId, 28, 429);
                    //Save the notes sent from front end.
                    fm.SaveAnswers(formSectionId, formInstance, notes, stsId);
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "InsertGlobalQuestions", "upd_GlobalSearchCategory", stsId);
            }
        }
        #endregion

        #region " GetExistingFormsData "
        /** \private    GetExistingFormsData 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       06/22/2012
         *  \details    This method searchs for and retrieve existing Forms data based on user entered data in key fields.
         *  \return     DataTable
         */
        private DataTable GetUnblockFormsData()
        {
            DataTable _dtSearch = null;

            try
            {
                /** Query for existing Rsik Profile records based on user entered data.*/
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    _dtSearch = dm.GetUnblockFormsSearch(Navigation.Current.LoggedInStsId);
                    if (_dtSearch.Rows.Count > 0)
                    {
                        lblCountUnblock.Text = _dtSearch.Rows.Count.ToString();
                    }
                }
            }
            catch (System.Threading.ThreadAbortException) { }
            catch (Exception ex)
            {
                ProcessException(ex, "GetExistingFormsData", "qry_FormsSearch");
            }
            return _dtSearch;
        }
        #endregion

        #region " grdDashboard Events "

        protected void grdUnblockSection_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
        {
            grdUnblockSection.DataSource = GetUnblockFormsData();
        }

        protected void grdUnblockSection_ItemDataBound(object sender, GridItemEventArgs e)
        {
            if (e.Item is GridDataItem)
            {
                var ditem = (GridDataItem)e.Item;
                var btn = (Button)ditem["Delete"].Controls[0];
                var btnEdit = (Button)ditem["Edit"].Controls[0];
                var showDelete = ditem["ShowDelete"].Text;
                var isFormActive = ditem["IsActive"].Text;
                var analystName = ditem["AnalystName"].Text;
                var isUrgent = ditem["MarkIfUrgent"].Text;
                var analystId = ditem["AnalystID"].Text;
                var icon = (HtmlControl)ditem["NotesCol"].Controls[0].FindControl("i1");
                var notes = ditem["Notes"].Text == "&nbsp;" ? string.Empty : ditem["Notes"].Text;
                var FormInstance = ditem["FormInstance"].Text;
                var FormId = ditem["ID"].Text;

                if (showDelete == "1")
                {
                    btn.Visible = true;
                    if (isFormActive == "False")
                    {
                        btnEdit.Visible = false;
                        btn.Text = "Un-Delete";
                        btn.ToolTip = "Un-Delete";
                    }
                }
                else
                {
                    btn.Visible = false;
                }
                //if (string.IsNullOrEmpty(analystName) || analystName == "&nbsp;")
                //{
                //    if (isUrgent == "Urgent")
                //    {
                //        ditem.BackColor = System.Drawing.Color.IndianRed;
                //    }
                //    else
                //    {
                //        ditem.CssClass = "dyn_field_yellow";
                //    }
                //}

                var cmbAnalyst = ditem.FindControl("cmbBrtAnalystUB") as RadComboBox;
                if (cmbAnalyst != null)
                {
                    LoadAnalysts(cmbAnalyst);
                    if (!string.IsNullOrEmpty(analystId) && analystId != "&nbsp;")
                    {
                        var cmbItem = cmbAnalyst.FindItemByValue(analystId);
                        if (cmbItem != null)
                        {
                            cmbItem.Selected = true;
                        }
                    }
                }

                if (icon != null)
                {
                    if (notes != string.Empty)
                    {
                        icon.Attributes.Add("onclick", "LoadNotes(" + FormId + ",\"" + FormInstance + "\",\"" + notes.Replace(Environment.NewLine, "new line").Replace("\n", "new line") + "\")");
                        icon.Attributes.Add("title", notes);
                    }
                    else
                    {
                        icon.Visible = false;
                    }
                }
            }
        }

        protected void grdUnblockSection_ItemCommand(object sender, GridCommandEventArgs e)
        {
            if (e.Item is GridDataItem)
            {
                var item = (GridDataItem)e.Item;

                var nvc_Querystring = new NameValueCollection();
                nvc_Querystring.Add("FormId", item["ID"].Text);
                nvc_Querystring.Add("FormInstance", item["FormInstance"].Text);
                nvc_Querystring.Add("FormInstanceType", item["FTID"].Text);
                nvc_Querystring.Add("IsEditable", item["IsActive"].Text);
                nvc_Querystring.Add("AllowOverride", item["AllowOverride"].Text);
                nvc_Querystring.Add("LegalName", item["LegalName"].Text == "&nbsp;" ? string.Empty : HttpUtility.UrlEncode(item["LegalName"].Text));

                switch (e.CommandName)
                {
                    case "Edit":
                        {
                            try
                            {
                                switch (item["ID"].Text)
                                {
                                    case ("1"):
                                        Response.Redirect("../ABCForm/Form1.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                    case ("2"):
                                        Response.Redirect("../ABCForm/Form2.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                    case ("3"):
                                        Response.Redirect("../ABCForm/Form3.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                    case ("4"):
                                        Response.Redirect("../ABCForm/Form4.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                    case ("5"):
                                        Response.Redirect("../ABCForm/Form5.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                }
                            }
                            catch (ThreadAbortException)
                            { /* Do Nothing */ }
                        }
                        break;

                    case "View":
                        {
                            nvc_Querystring.Add("ReadOnly", "true");
                            try
                            {
                                switch (item["ID"].Text)
                                {
                                    case ("1"):
                                        Response.Redirect("../ABCForm/Form1.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                    case ("2"):
                                        Response.Redirect("../ABCForm/Form2.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                    case ("3"):
                                        Response.Redirect("../ABCForm/Form3.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                    case ("4"):
                                        Response.Redirect("../ABCForm/Form4.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                    case ("5"):
                                        Response.Redirect("../ABCForm/Form5.aspx?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]), false);
                                        break;
                                }
                            }
                            catch (ThreadAbortException)
                            { /* Do Nothing */ }
                        }
                        break;
                    case "Delete":
                        var isActive = false;
                        var btn = (Button)item["Delete"].Controls[0];
                        if (btn != null && btn.Text == "Un-Delete")
                        {
                            isActive = true;
                        }

                        using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                        {
                            var dd = dm.DeleteForm(item["FormInstance"].Text, isActive, Navigation.Current.LoggedInStsId);
                        }
                        break;
                }
            }
        }

        protected void grdUnblockSection_ItemCreated(object sender, GridItemEventArgs e)
        {
            if (e.Item is GridPagerItem)
            {
                var PageSizeCombo = (RadComboBox)e.Item.FindControl("PageSizeComboBox");
                PageSizeCombo.RenderMode = RenderMode.Lightweight;
            }
        }

        protected void grdUnblockSection_PreRender(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                foreach (GridColumn column in grdDashboard.MasterTableView.Columns)
                {
                    switch (column.UniqueName)
                    {
                        case "FTID":
                            column.Display = false;
                            break;
                    }
                }
            }
        }

        #endregion

        protected void cmbBrtAnalystUB_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            try
            {
                var ddlCtrl = sender as RadComboBox;
                if (ddlCtrl != null)
                {
                    var ditem = ddlCtrl.Parent.Parent as GridDataItem;
                    if (ditem != null)
                    {
                        var formId = ditem["Id"].Text;
                        var analystSectionId = ditem["AnalystSectionID"].Text;
                        var formInstance = ditem["FormInstance"].Text;
                        var analystId = ddlCtrl.SelectedValue;// ditem["AnalystID"].Text;
                        var stsId = Navigation.Current.LoggedInStsId;
                        if (!string.IsNullOrEmpty(formInstance) && !string.IsNullOrEmpty(analystId))
                        {
                            using (FormManager fm = new FormManager(Global.ABCConnectionString))
                            {
                                if (analystId != "0")
                                {
                                    var analysInfo = fm.GetBRTAnalystInfo(analystId);
                                    if (analysInfo != null)
                                    {
                                        foreach (BRTAnalyst banalyst in analysInfo)
                                        {
                                            var formSectionId = fm.GetFormSectionIdByQuestion(Convert.ToInt32(formId), 40, 323);
                                            if (formSectionId > 0)
                                            {
                                                fm.SaveAnswers(formSectionId, formInstance, banalyst.LogonId, stsId);
                                            }
                                            formSectionId = fm.GetFormSectionIdByQuestion(Convert.ToInt32(formId), 40, 324);
                                            if (formSectionId > 0)
                                            {
                                                fm.SaveAnswers(formSectionId, formInstance, banalyst.Email, stsId);
                                            }
                                            formSectionId = fm.GetFormSectionIdByQuestion(Convert.ToInt32(formId), 40, 325);
                                            if (formSectionId > 0)
                                            {
                                                fm.SaveAnswers(formSectionId, formInstance, banalyst.WorkPhone, stsId);
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    var formSectionId = fm.GetFormSectionIdByQuestion(Convert.ToInt32(formId), 40, 323);
                                    fm.SaveAnswers(formSectionId, formInstance, string.Empty, stsId);
                                    formSectionId = fm.GetFormSectionIdByQuestion(Convert.ToInt32(formId), 40, 324);
                                    fm.SaveAnswers(formSectionId, formInstance, string.Empty, stsId);
                                    formSectionId = fm.GetFormSectionIdByQuestion(Convert.ToInt32(formId), 40, 325);
                                    fm.SaveAnswers(formSectionId, formInstance, string.Empty, stsId);
                                    //fm.UpdateFormReportStatus(Convert.ToInt32(formId), 28, formInstance, stsId);

                                }
                            }
                            grdUnblockSection.Rebind();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ProcessException(ex, "cmbBrtAnalyst_SelectedIndexChanged", "SaveAnswers");
            }
        }
    }
}