﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Telerik.Web.UI;
using BusinessLogicLayer;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using Common;

namespace ABC.ABCForm
{
    public partial class AuditHistory : System.Web.UI.Page
    {
        string FormId = string.Empty;
        string FormInstance = string.Empty;

        #region " Page_Load "
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                hiLoggedInVzid.Value = Navigation.Current.LoggedInVzid;// Convert.ToString(Session["SsoLoginVzid"]);
                hiLoggedInStsId.Value = Convert.ToString(Navigation.Current.LoggedInStsId);
                LoadDropDown("ddlFormName", ddlFormName, -1, 0);
            }
        }
        #endregion

        #region " LoadDropDown "
        /** \private    LoadDropDown 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
        */
        private void LoadDropDown(string ddType, RadComboBox dropDown, int ParentSelectedItem, int elementId = -1)
        {
            try
            {
                dropDown.ClearSelection();
                dropDown.Items.Clear();
                //Use DashboardManager to load the forms list
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    if (ddType == "ddlFormName")
                    {
                        DataTable _dt1 = new DataTable();
                        _dt1 = dm.GetFormsDropDownList();
                        if (_dt1 != null && _dt1.Rows.Count > 0)
                        {
                            for (int i = 0; i < _dt1.Rows.Count; i++)
                            {
                                RadComboBoxItem li = new RadComboBoxItem(_dt1.Rows[i]["Name"].ToString(), _dt1.Rows[i]["FormID"].ToString());
                                dropDown.Items.Add(li);
                            }
                        }
                    }
                    /* Add default value */
                    RadComboBoxItem liFirst = new RadComboBoxItem("-- Choose Value --", "0");
                    dropDown.Items.Insert(0, liFirst);
                }
            }
            catch (Exception ex)
            {
                //ex.HelpLink = GetMoreInfoForException();
                //Get page name and calling method and stored procedure.
                //ex.HelpLink = GetMoreInfoForException(Path.GetFileName(Request.Path), MethodBase.GetCurrentMethod().Name, "");
                //LogError(ex, ex.HelpLink);
                ProcessException(ex, "Page_Load", "");
            }
        }
        #endregion

        #region " ddlFormName_SelectedIndexChanged "
        /** \private    ddlFormName_SelectedIndexChanged 
         *  \section    First Draft
         *  \author     Itzier Meneses
         *  \date       03/17/2016
         *  \details    This method binds the data to ddlFormInstance dropdown.
         *  \param      sender object
         *  \param      e DropDownListEventArgs
        */
        protected void ddlFormName_SelectedIndexChanged(object sender, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            //Load ddlFormInstance drop down
            //using (FormManager fm = new FormManager(Global.ABCConnectionString))
            //{
            //    using (DataTable _dt = fm.GetFormInstances(Convert.ToInt32(ddlFormName.SelectedValue)))
            //    {
            //        ddlFormInstance.DataSource = _dt;
            //        ddlFormInstance.DataTextField = "FormInstance";
            //        ddlFormInstance.DataValueField = "FormInstance";
            //        ddlFormInstance.DataBind();

            //        DropDownListItem ddli = new DropDownListItem("-- Choose Value --", "0");
            //        ddlFormInstance.Items.Insert(0, ddli);
            //    }
            //}
        }
        #endregion

        protected void grdFormInstances_NeedDataSource(object sender, Telerik.Web.UI.GridNeedDataSourceEventArgs e)
        {
            grdFormInstances.DataSource = GetExistingFormsData();
        }

        protected void grdFormInstances_ItemCommand(object sender, Telerik.Web.UI.GridCommandEventArgs e)
        {
            if (e.Item is GridDataItem)
            {
                GridDataItem item = (GridDataItem)e.Item;

                FormId = item["ID"].Text;
                FormInstance = item["FormInstance"].Text;

                if (e.CommandName == "View")
                {
                    grdFormInstances.DataSource = null;
                    grdFormInstances.DataBind();

                    grdAuditHistory.Visible = true;

                    //if (ddlFormName.SelectedIndex == 0)
                    //{
                    //    lblAuditHistory.Text = "Please select a form name and instance.";
                    //}
                    //else
                    //{
                    div1.Visible = true;
                    lblAuditHistory.Text = "Audit history for Form " + FormInstance;
                    using (FormManager fm = new FormManager(Global.ABCConnectionString))
                    {
                        using (DataTable _dt = fm.GetAuditHistory(FormInstance))
                        {
                            grdAuditHistory.DataSource = _dt;
                            grdAuditHistory.DataBind();
                        }
                    }
                    //}
                }
            }
        }

        #region " btnSearch_Click "
        /** \private    btnSearch_Click 
         *  \section    First Draft
         *  \author     Itzier Meneses
         *  \date       03/17/2016
         *  \details    This method performs the audit history search and binds the data to the grid.
         *  \param      sender object
         *  \param      e DropDownListEventArgs
        */
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DataTable _dt = null;
            using (_dt = GetExistingFormsData())
            {
                if (_dt.Rows.Count > 0)
                {
                    grdFormInstances.Visible = true;
                    grdFormInstances.DataSource = _dt;
                    grdFormInstances.DataBind();
                    div2.Visible = false;
                    lblError.Text = "";
                }
                else
                {
                    grdFormInstances.Visible = false;
                    div2.Visible = true;
                    lblError.Text = "No Records found.";
                }
            }

            grdAuditHistory.DataSource = null;
            grdAuditHistory.DataBind();
            grdAuditHistory.Visible = false;
            div1.Visible = false;
            lblAuditHistory.Text = "";

        }
        #endregion

        #region " GetExistingFormsData "
        private DataTable GetExistingFormsData()
        {
            DataTable _dtSearch = null;
            int FormName = 0;
            int FormSection = 0;
            string FormQuestions = string.Empty;
            int CreatorStsId = 0;
            string FormInstance = string.Empty;
            DateTime DateFromCreated = Convert.ToDateTime("01/01/1900");
            DateTime DateToCreated = DateTime.Now;

            int vzid = !string.IsNullOrEmpty(hiLoggedInStsId.Value) ? Convert.ToInt32(hiLoggedInStsId.Value) : 0;

            if (ddlFormName.SelectedIndex > 0)
            {
                FormName = Convert.ToInt32(ddlFormName.SelectedValue);
            }

            if (ddlFormName.SelectedIndex != 0)
            {
                if (txtInstanceYear.Text != string.Empty)
                {
                    FormInstance += ddlFormName.SelectedItem.Text.Trim() + "-" + txtInstanceYear.Text.Trim();
                    if (txtInstanceIdentifier.Text != string.Empty)
                    {
                        FormInstance += "-" + txtInstanceIdentifier.Text.Trim();
                    }
                }
            }

            try
            {
                using (FormManager dm = new FormManager(Global.ABCConnectionString))
                {
                    _dtSearch = dm.GetFormsSearchAudit(FormName, FormInstance, FormSection, FormQuestions, CreatorStsId, DateFromCreated, DateToCreated, 0);
                }
            }
            catch (System.Threading.ThreadAbortException) { }
            catch (Exception ex)
            {
                ProcessException(ex, "GetExistingFormsData", "AuditHistory");
            }
            return _dtSearch;
        }
        #endregion

        #region " ProcessException "
        protected void ProcessException(Exception inEx, string inFunctionName, string inSPName)
        {
            var userName = string.Empty;
            if (Navigation.Current.UserName != null)
            {
                userName = Navigation.Current.UserName;
            }
            var excep = new ABCException
            {
                StsId = Convert.ToInt32(hiLoggedInStsId.Value),
                Name = userName,
                MethodName = inFunctionName,
                SpName = inSPName,
                PageName = "AuditHistory.aspx.cs"
            };
            inEx.HelpLink = ABCException.GetMoreInfoForException(excep);
            ExceptionPolicy.HandleException(inEx, Global.ApplicationLayerPolicy);
        }
        #endregion

        protected void grdAuditHistory_SortCommand(object source, Telerik.Web.UI.GridSortCommandEventArgs e)
        {
            grdFormInstances.DataSource = null;
            grdFormInstances.DataBind();

            if (!e.Item.OwnerTableView.SortExpressions.ContainsExpression(e.SortExpression))
            {
                GridSortExpression sortExpr = new GridSortExpression();
                sortExpr.FieldName = e.SortExpression;
                sortExpr.SortOrder = GridSortOrder.Ascending;

                e.Item.OwnerTableView.SortExpressions.AddSortExpression(sortExpr);
            }
        }

        protected void abtnClear_ServerClick(object sender, EventArgs e)
        {
            Response.Redirect("AuditHistory.aspx", true);
        }

        private void Page_Error(object sender, EventArgs e)
        {
            var ex = Server.GetLastError();
            ProcessException(ex, "Page_Error", "");
            // Clear the error from the server
            Server.ClearError();
        }

        protected void grdFormInstances_ItemCreated(object sender, GridItemEventArgs e)
        {
            if (e.Item is GridPagerItem)
            {
                var PageSizeCombo = (RadComboBox)e.Item.FindControl("PageSizeComboBox");
                PageSizeCombo.RenderMode = RenderMode.Lightweight;
            }
        }
    }
}