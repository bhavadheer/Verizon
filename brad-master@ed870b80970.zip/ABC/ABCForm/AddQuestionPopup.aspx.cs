﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Common;
using BusinessLogicLayer;
using System.Collections.Specialized;
using Verizon.QueryStringEncryption;

namespace ABC.ABCForm
{
    public partial class AddQuestionPopup : System.Web.UI.Page
    {
        public string FormId = string.Empty;
        List<ExtraField> newQuestions = new List<ExtraField>();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                hiLoggedInStsId.Value = Navigation.Current.LoggedInStsId.ToString();
                
                if (Session["NewAddedFields"] != null)
                {
                    newQuestions = (List<ExtraField>)Session["NewAddedFields"];
                    if (newQuestions != null)
                    {
                        lblQuesView.Text = newQuestions[0].Text;
                        lblAnsView.Text = newQuestions[0].FieldData.ToString();
                    }
                }
            }
            if (Request.QueryString["request"] != null && !string.IsNullOrEmpty(Request.QueryString["request"]))
            {
                NameValueCollection decryptedQueryStrings = CryptoQueryStringHandler.GetDecryptedQueryStrings(Request.QueryString["request"]);
                if (decryptedQueryStrings["Mode"] != null && !string.IsNullOrEmpty(decryptedQueryStrings["Mode"].ToString()))
                {
                    string mode = decryptedQueryStrings["Mode"].ToString();
                    if (mode == "readonly")
                    {
                        tblWrite.Style.Add("display", "none");
                        tblRead.Style.Add("display", "");
                    }
                    else
                    {
                        tblWrite.Style.Add("display", "");
                        tblRead.Style.Add("display", "none");
                    }
                }
                if (decryptedQueryStrings["FormInstance"] != null && !string.IsNullOrEmpty(decryptedQueryStrings["FormInstance"].ToString()))
                {
                    hiFormInstance.Value = decryptedQueryStrings["FormInstance"].ToString();
                }
            }
            else
            {
                if (Request.QueryString["Mode"] != null && !string.IsNullOrEmpty(Request.QueryString["Mode"].ToString()))
                {
                    string mode = Request.QueryString["Mode"].ToString();
                    if (mode == "readonly")
                    {
                        tblWrite.Style.Add("display", "none");
                        tblRead.Style.Add("display", "");
                    }
                    else
                    {
                        tblWrite.Style.Add("display", "");
                        tblRead.Style.Add("display", "none");
                    }
                }
                if (Request.QueryString["FormInstance"] != null && !string.IsNullOrEmpty(Request.QueryString["FormInstance"].ToString()))
                {
                    hiFormInstance.Value = Request.QueryString["FormInstance"].ToString();
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(hiFormInstance.Value))
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "saveParent", "saveParent();", true);
                if (Session["FormInstance"]  != null && !string.IsNullOrEmpty(Session["FormInstance"] .ToString()))
                {
                    hiFormInstance.Value = Session["FormInstance"] .ToString();
                }
            }
            
            if (Request.QueryString["FormId"] != null && !string.IsNullOrEmpty(Request.QueryString["FormId"].ToString()))
            {
                FormId = Request.QueryString["FormId"].ToString();
            }
            string[] splitForm = FormId.Split('_');
            if (Session["NewAddedFields"] != null)
            {
                newQuestions = (List<ExtraField>)Session["NewAddedFields"];
            }

            ExtraField newQuestion = new ExtraField();

            newQuestion.Form = Convert.ToInt32(splitForm[1]);
            newQuestion.Sec = Convert.ToInt32(splitForm[2]);
            newQuestion.Text = txtQuestion.Text;
            newQuestion.FieldData = NewEditor.Text;
            
            newQuestions.Add(newQuestion);
            Session["NewAddedFields"] = newQuestions;
            //Table ss = (Table)this.Parent.Page.FindControl(FormId);

            if (string.IsNullOrEmpty(hiFormInstance.Value))
            {
                if (Session["FormInstance"]  != null && !string.IsNullOrEmpty(Session["FormInstance"] .ToString()))
                {
                    hiFormInstance.Value = Session["FormInstance"] .ToString();
                }
            }

            using (FormManager fm = new FormManager(Global.ABCConnectionString))
            {
                Int32 questionId = fm.InsertAdditionalQuestion(txtQuestion.Text, NewEditor.Text, newQuestion.Form, newQuestion.Sec, hiFormInstance.Value, Convert.ToInt32(hiLoggedInStsId.Value));
            }

            lblMessage.Text = "Question was successfully saved to form " + newQuestion.FormInstance;
            //ScriptManager.RegisterStartupScript(this, GetType(), "close", "CloseModal('" + FormId + "','" + newQuestions.Count + "');", true);
            
        }

        
    }
}