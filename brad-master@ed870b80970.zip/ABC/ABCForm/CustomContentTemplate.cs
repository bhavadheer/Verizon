﻿using Common;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using Telerik.Web.UI;

namespace ABC.ABCForm
{
    public class CustomContentTemplate : ITemplate
    {
        public void InstantiateIn(Control container)
        {
        }

        public void InstantiateIn(Control container, Page ff, int formId, bool IsReadonly, string formInstance = "")
        {
            var item = (RadPanelItem)container;
            try
            {
                if (item.Text != "Attachments ")
                {
                    var dynFields = (DynamicFields)ff.LoadControl("DynamicFields.ascx");
                    dynFields.ID = "pilPanelItem";
                    dynFields.FormId = formId;
                    dynFields.SectionId = Convert.ToInt32(item.Value);
                    dynFields.ReadOnly = IsReadonly;
                    container.Controls.Add(dynFields);
                    item.CssClass = (dynFields.IsValid == false) ? "dyn_section_yellow" : String.Empty;
                }
                else
                {
                    var dynFields = (AttachmentControl)ff.LoadControl("AttachmentControl.ascx");
                    dynFields.ID = "acMain";
                    dynFields.FormId = formId;
                    container.Controls.Add(dynFields);
                }
            }
            catch (Exception ex)
            {
                ProcessException(ex, "InstantiateIn", formInstance, item.Text);
            }
        }

        #region " ProcessException "

        protected static void ProcessException(Exception inEx, string inFunctionName, string inSPName, string sectionName = "")
        {
            var userName = string.Empty;
            var stsID = 0;
            if (Navigation.Current.UserName != null)
            {
                userName = Navigation.Current.UserName;
            }
            if (Navigation.Current.LoggedInStsId != 0)
            {
                stsID = Navigation.Current.LoggedInStsId;
            }
            var excep = new ABCException
            {
                StsId = stsID,
                Name = userName,
                MethodName = inFunctionName,
                SpName = string.Empty,
                PageName = "CustomContentTemplate",
                FormInstance = inSPName,
                SectionName = sectionName
            };
            inEx.HelpLink = ABCException.GetMoreInfoForException(excep);
            ExceptionPolicy.HandleException(inEx, Global.ApplicationLayerPolicy);
        }

        #endregion

    }
}