﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using Verizon.QueryStringEncryption;

namespace ABC.ABCForm
{
    public partial class DummyPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.Header.DataBind();
            if (!IsPostBack)
            {
                var formId = string.Empty;
                if (Request.QueryString["FormId"] != null && !string.IsNullOrEmpty(Request.QueryString["FormId"].ToString()))
                {
                    formId = Request.QueryString["FormId"].ToString();
                }
                var sectionId = string.Empty;
                if (Request.QueryString["SectionId"] != null && !string.IsNullOrEmpty(Request.QueryString["SectionId"].ToString()))
                {
                    sectionId = Request.QueryString["SectionId"].ToString();
                }
                var formInstance = string.Empty;
                if (Request.QueryString["formInstance"] != null && !string.IsNullOrEmpty(Request.QueryString["formInstance"].ToString()))
                {
                    formInstance = Request.QueryString["formInstance"].ToString();
                }

                var url = string.Empty;
                switch (Global.WorkingEnvironment.ToString().ToUpper())
                {
                    case "DEV":
                        url = "https://stsdevreports1.verizon.com/SecuritySystems/ABCReportPortal/ASPX/SubFormPrint.aspx?";
                        break;
                    case "TEST":
                        url = "https://ststestreports1.verizon.com/SecuritySystems/ABCReportPortal/ASPX/SubFormPrint.aspx?";
                        break;
                    case "STAGING":
                        url = "https://stsstagingreports1.verizon.com/SecuritySystems/ABCReportPortal/ASPX/SubFormPrint.aspx?";
                        break;
                    case "PRODUCTION":
                        url = "https://stseureporting.verizon.com/ABCReportPortal/ASPX/SubFormPrint.aspx?";
                        break;
                        //case default:break;
                }

                var nvc_Querystring = new NameValueCollection();
                nvc_Querystring.Add("FormId", formId);
                nvc_Querystring.Add("SectionId", sectionId);
                nvc_Querystring.Add("RoleId", "101");
                nvc_Querystring.Add("FormInstanceId", formInstance);
                nvc_Querystring.Add("currentUserSTSID", Navigation.Current.LoggedInStsId.ToString());
                printReport.Src = url + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, WebConfigurationManager.AppSettings["CryptoKey"]);
            }
        }
    }
}