﻿using BusinessLogicLayer;
using Common;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ABC.ABCForm
{
    public partial class NewForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region " ProcessException "

        protected static void ProcessException(Exception inEx, string inFunctionName, string inSPName, int stsId)
        {
            var userName = string.Empty;
            if (Navigation.Current.UserName != null)
            {
                userName = Navigation.Current.UserName;
            }
            var excep = new ABCException
            {
                StsId = stsId,
                Name = userName,
                MethodName = inFunctionName,
                SpName = inSPName,
                PageName = "NewForm.aspx.cs"
            };
            inEx.HelpLink = ABCException.GetMoreInfoForException(excep);
            ExceptionPolicy.HandleException(inEx, Global.ApplicationLayerPolicy);
        }

        #endregion

        #region " DataTableToJSONWithJavaScriptSerializer "
        public static string DataTableToJSONWithJavaScriptSerializer(DataTable table)
        {
            var jsSerializer = new JavaScriptSerializer
            {
                MaxJsonLength = Int32.MaxValue
            };
            var parentRow = new List<Dictionary<string, object>>();
            Dictionary<string, object> childRow;
            foreach (DataRow row in table.Rows)
            {
                childRow = new Dictionary<string, object>();
                foreach (DataColumn col in table.Columns)
                {
                    childRow.Add(col.ColumnName, row[col]);
                }
                parentRow.Add(childRow);
            }
            return jsSerializer.Serialize(parentRow);
        }
        #endregion

        #region " Web Methods "

        #region " LoadDropDown "
        /** \private    LoadDropDown 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
        */
        [WebMethod]
        public static string LoadComboBox()
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (DashboardManager dm = new DashboardManager(Global.ABCConnectionString))
                {
                    var roleId = ((Int32)Navigation.Current.CurrentRole).ToString();

                    using (var _dt1 = dm.GetFormsDropDownList())
                    {
                        if (_dt1 != null && _dt1.Rows.Count > 0)
                        {
                            result = DataTableToJSONWithJavaScriptSerializer(_dt1);
                        }
                    }

                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "LoadComboBox", "qry_GetFormsDropDown", stsId);
            }
            return result;
        }
        #endregion

        #region " LoadDropDown "
        /** \private    LoadDropDown 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method binds the data to dropdowns.
         *  \param      ddType  string
         *  \param      dropDown   RadComboBox
        */
        [WebMethod]
        public static string LoadDropdownByCategory(string category)
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (DropDownDataManager dm = new DropDownDataManager(Global.ABCConnectionString))
                {
                    var roleId = ((Int32)Navigation.Current.CurrentRole).ToString();

                    using (var _dt1 = dm.GetAllDropDownDataByCategory(category))
                    {
                        if (_dt1 != null && _dt1.Rows.Count > 0)
                        {
                            result = DataTableToJSONWithJavaScriptSerializer(_dt1);
                        }
                    }

                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "LoadComboBox", "qry_GetFormsDropDown", stsId);
            }
            return result;
        }
        #endregion

        #region " GetQuestionstoLoad " 

        [WebMethod]
        public static string GetQuestionstoLoad(int formId)
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "

                /**Create DashboardManager object and bind values to dropdowns*/
                using (FormManager dm = new FormManager(Global.ABCConnectionString))
                {
                    var roleId = (Int32)Navigation.Current.CurrentRole;
                    var _dt1 = dm.GetUserFormPartial(formId);
                    result = serializer.Serialize(_dt1);
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "GetQuestionstoLoad", "qry_FormQuestionsById", stsId);
            }
            return result;
        }
        #endregion

        [WebMethod]
        public static string InsertUserPartialForm(string inputData, int formId)
        {
            var result = string.Empty;
            var serializer = new JavaScriptSerializer();
            var stsId = Navigation.Current.LoggedInStsId;
            try
            {
                #region " Try Block "
                /**Create DashboardManager object and bind values to dropdowns*/
                using (FormManager dm = new FormManager(Global.ABCConnectionString))
                {
                    var newFormInstance = dm.InsertUserPartialForm(inputData, formId, stsId);
                    result = newFormInstance;
                }
                #endregion
            }
            catch (Exception ex)
            {
                ProcessException(ex, "InsertUserPartialForm", "ins_UserPartialForm", stsId);
            }
            return result;
        }
        #endregion
    }
}