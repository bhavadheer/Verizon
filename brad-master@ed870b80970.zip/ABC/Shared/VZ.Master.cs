﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Web.UI.WebControls;
using BusinessLogicLayer;
using Common;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;


namespace ABC
{
    public partial class VZ : System.Web.UI.MasterPage
    {
        #region " Page_Load "
        /// <summary>
        /// Page_Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.Header.DataBind();
            //Session Dead or User Not Logged In
            if (Navigation.Current.LoggedInStsId == -1)
            {
                String clientIP = (Request.ServerVariables["HTTP_X_FORWARDED_FOR"] ?? Request.ServerVariables["REMOTE_ADDR"]).Split(',')[0].Trim();

                // If (SSO HTTP_VZID is Available) 
                if (Request.ServerVariables[Global.SSOId] != null && !String.IsNullOrEmpty(Request.ServerVariables[Global.SSOId]))
                {
                    Navigation.Current.GetUserNavigation(Request.ServerVariables[Global.SSOId].ToString().ToLower(), clientIP);
                    try
                    {
                        Response.Redirect(Navigation.Current.DefaultPage, false);
                    }
                    catch (ThreadAbortException)
                    { }
                }
                else // Else, Go to Custom Logout page
                {
                    try
                    {
                        Response.Redirect(Navigation.Current.LogoutPage, false);
                    }
                    catch (ThreadAbortException)
                    { }
                }
            }

            //Set Login Information
            lblUserName.Text = Navigation.Current.UserName;
            lblUserNameMenu.Text = Navigation.Current.UserName;
            lblRole.Text = Navigation.Current.CurrentRole.ToString();
            lblEnvironment.Text = String.Format("Environment:{0}&nbsp;&nbsp;&nbsp;&nbsp;Role:{1}", Global.WorkingEnvironment.DisplayString(), Navigation.Current.CurrentRole.DisplayString());
            if (Global.WorkingEnvironment == Global.EnvType.Production)
            {
                divEnvironment.Visible = false;
            }

            if (!IsPostBack)
            {
                using (NavigationManager navMan = new NavigationManager(Global.ABCConnectionString))
                {
                    MenuRepeater.DataSource = navMan.GetMasterMenu(Convert.ToInt32(Navigation.Current.CurrentRole));
                    MenuRepeater.DataBind();
                }
                //using (DataTable dt = GetMenu())
                //{
                //    //Set Main Menu
                //    MenuRepeater.DataSource = dt.DefaultView;
                //    MenuRepeater.DataBind();
                //}
            }
        }
        #endregion

        #region " ActiveUrl "
        /// <summary>
        /// ActiveUrl
        /// </summary>
        /// <param name="PageURL"></param>
        /// <returns>String</returns>
        public String ActiveUrl(object PageURL, object mainTabId)
        {
            //Default to the FilePath
            string PagePath = Request.FilePath;

            //If application is not at root
            if (Request.ApplicationPath != "/")
            {
                //Strip ApplicationPath from RequestPath to get the PagePath
                PagePath = Request.FilePath.Replace(Request.ApplicationPath, "");
            }

            //Check the PagePath vs the PageURL (Minus the asp.net ~ root path formatter
            if (PagePath == PageURL.ToString().Replace("~", "").Substring(0, PageURL.ToString().Replace("~", "").IndexOf("?")))
            {
                //Return the Active CssClass
                return "active";
            }
            SetRightLinks(Convert.ToString(mainTabId));
            return string.Empty;
        }
        #endregion

        #region " MenuRepeater_ItemDataBound "
        /// <summary>
        /// MenuRepeater_ItemDataBound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void MenuRepeater_ItemDataBound(object sender, System.Web.UI.WebControls.RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == System.Web.UI.WebControls.ListItemType.Item || e.Item.ItemType == System.Web.UI.WebControls.ListItemType.AlternatingItem)
            {
                //Repeater childRepeater = (Repeater)e.Item.FindControl("ChildMenuRepeater");
                //MenuData parentMenu = (MenuData)e.Item.DataItem;

                //using(NavigationManager navMan = new NavigationManager(Global.ABCConnectionString))
                //{
                //    List<MenuData> childMenu = navMan.GetMasterMenu(Convert.ToInt32(Session["currentUserRole"]));
                //    if(childMenu.Count > 0)
                //    {
                //        childRepeater.Visible = true;
                //        childRepeater.DataSource = childMenu;
                //        childRepeater.DataBind();
                //    }
                //    else
                //    {
                //        childRepeater.Visible = false;
                //    }
                //}
            }
        }
        #endregion

        #region " Private Methods "

        #region " SetRightLinks "
        /// <summary>
        /// Build the right links
        /// </summary>
        /// <param name="MainTabId"></param>
        private void SetRightLinks(string MainTabId)
        {
            try
            {
                var roleId = Convert.ToInt32(Navigation.Current.CurrentRole);
                using (ReferenceManager refMgr = new ReferenceManager(Global.ABCConnectionString))
                {
                    using (DataTable _dt = refMgr.GetRightLinks(roleId, MainTabId))
                    {
                        if (_dt != null && _dt.Rows.Count > 0)
                        {
                            /* Display the heading*/
                            // bRightLinkHeading.InnerText = "Application Links";

                            /* Build the right links */
                            ulRightMenu.InnerHtml = "";
                            for (int i = 0; i < _dt.Rows.Count; i++)
                            {
                                var displayName = _dt.Rows[i]["DisplayName"].ToString();
                                var url = _dt.Rows[i]["NavigationURL"].ToString();
                                var id = _dt.Rows[i]["NavId"].ToString();
                                if ((displayName == "Form Questions" || displayName == "Form Sections" || displayName == "BRT Time Report" || displayName == "Access Report") && Navigation.Current.ShowDelete == 0)
                                {
                                    ulRightMenu.InnerHtml += "<div class='include2 section-divider-bottom' style='display:none'><a id='" + id + "' href='" + url + "'>" + displayName + "</a></div>";
                                }
                                else
                                {
                                    ulRightMenu.InnerHtml += "<div class='include2 section-divider-bottom'><a id='" + id + "' href='" + url + "'>" + displayName + "</a></div>";
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionPolicy.HandleException(ex, Global.ApplicationLayerPolicy);
            }
        }
        #endregion

        #endregion
    }
}