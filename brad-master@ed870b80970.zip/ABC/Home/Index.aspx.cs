﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web.UI.WebControls;
using BusinessLogicLayer;
using Common;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;


namespace ABC.Home
{
    public partial class Index : System.Web.UI.Page
    {
        #region " Private Properties "
        private int NewAnnoucementCount
        {
            get
            {
                if (ViewState["NewAnnoucementCount"] != null)
                {
                    return Convert.ToInt32(ViewState["NewAnnoucementCount"]);
                }

                return 0;
            }
            set
            {
                ViewState["NewAnnoucementCount"] = value;
            }
        }

        private int TotalAnnouncementCount
        {
            get
            {
                if (ViewState["TotalAnnouncementCount"] != null)
                {
                    return Convert.ToInt32(ViewState["TotalAnnouncementCount"]);
                }

                return 0;
            }
            set
            {
                ViewState["TotalAnnouncementCount"] = value;
            }
        }
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                LoadAnnouncements();
            }
        }

        #region " grdAnnouncements Methods "

        #region " LoadAnnouncements "
        /// <summary>
        /// LoadAnnouncements
        /// </summary>
        protected void LoadAnnouncements()
        {
            try
            {
                using (NavigationManager navMan = new NavigationManager(Global.ICEConnectionString))
                {
                    List<Announcement> annList = navMan.GetAnnouncments(Navigation.Current.LoggedInStsId);

                    //Get Counts
                    NewAnnoucementCount = annList.Where(x => x.Acknowledged == false).Count();
                    TotalAnnouncementCount = annList.Count();

                    grdAnnouncements.DataSource = annList;
                    grdAnnouncements.DataBind();
                }
            }
            catch(Exception ex)
            {
                ExceptionPolicy.HandleException(ex, Global.ApplicationLayerPolicy);
            }
        }
        #endregion

        protected void grdAnnouncements_PreRender(object sender, EventArgs e)
        {
            try
            {
                if (grdAnnouncements.HeaderRow != null)
                {
                    grdAnnouncements.HeaderRow.TableSection = TableRowSection.TableHeader;
                }
            }
            catch (Exception ex)
            {
                ExceptionPolicy.HandleException(ex, Global.ApplicationLayerPolicy);
            }
        }

        protected void grdAnnouncements_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
        {
            try
            {
                GridView gv = (GridView)sender;

                switch (e.CommandName)
                {
                    case "viewRecord":
                        {
                            int index = Convert.ToInt32(e.CommandArgument);
                            string announcmentId = gv.DataKeys[index].Value.ToString();

                            //if (!String.IsNullOrEmpty(caseId))
                            //{
                            //    string url = String.Format(@"~/ISS/ISS_Patrol.aspx?CaseId={0}", caseId);
                            //    Response.Redirect(url, true);
                            //}
                        }
                        break;

                    case "Page":
                        //ByPass Paging Command
                        break;

                    default:
                        throw new NotImplementedException();
                }
            }
            catch (ThreadAbortException)
            { }
            catch (Exception ex)
            {
                ExceptionPolicy.HandleException(ex, Global.ApplicationLayerPolicy);
            }
        }

        protected void grdAnnouncements_PageIndexChanging(object sender, System.Web.UI.WebControls.GridViewPageEventArgs e)
        {
            grdAnnouncements.PageIndex = e.NewPageIndex;
            LoadAnnouncements();
        }

        #endregion
    }
}