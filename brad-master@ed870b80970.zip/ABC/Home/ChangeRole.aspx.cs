﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Common;
using BusinessLogicLayer;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;


namespace ABC.Home
{
    public partial class ChangeRole : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                txtCurrentRole.Value = EnumHelper.DisplayString(Navigation.Current.CurrentRole);
                LoadRoles();
            }
        }

        protected void LoadRoles()
        {
            try
            {
                Dictionary<int, string> roledict = Navigation.Current.RoleList.ToDictionary(x => Convert.ToInt32(x), x => x.DisplayString());
                grdRoles.DataSource = roledict;
                grdRoles.DataBind();
            }
            catch (Exception ex)
            {
                ExceptionPolicy.HandleException(ex, Global.ApplicationLayerPolicy);
            }
        }

        protected void grdRoles_PreRender(object sender, EventArgs e)
        {
            try
            {
                if (grdRoles.HeaderRow != null)
                {
                    grdRoles.HeaderRow.TableSection = TableRowSection.TableHeader;
                }
            }
            catch (Exception ex)
            {
                ExceptionPolicy.HandleException(ex, Global.ApplicationLayerPolicy);
            }
        }

        protected void grdRoles_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                GridView gv = (GridView)sender;

                switch (e.CommandName)
                {
                    case "selectRole":
                        int index = Convert.ToInt32(e.CommandArgument);

                        Navigation.Current.CurrentRole = EnumHelper.GetEnumTypeFromString<RoleType>(gv.DataKeys[index].Value.ToString(), RoleType.NotSet);
                        using(NavigationManager nm = new NavigationManager(Global.ICEConnectionString))
                        {
                            Navigation.Current.UserAreas = nm.GetAllUserAreas(Navigation.Current.CurrentRole);
                        }
                        txtCurrentRole.Value = EnumHelper.DisplayString(Navigation.Current.CurrentRole);
                        break;

                    case "Page":
                        //ByPass Paging Command
                        break;

                    default:
                        throw new NotImplementedException();
                }
            }
            catch(ThreadAbortException)
            { }
            catch (Exception ex)
            {
                ExceptionPolicy.HandleException(ex, Global.ApplicationLayerPolicy);
            }
        }
    }
}