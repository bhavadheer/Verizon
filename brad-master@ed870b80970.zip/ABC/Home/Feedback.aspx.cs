﻿using System;
using System.Threading;


namespace ABC.Home
{
    public partial class Feedback : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSave_ServerClick(object sender, EventArgs e)
        {
            string overallRtg = overallRating.Value;
            string contentRtg = contentRating.Value;
            string navRtg = navigationRating.Value;
            string usageRtg = usageRating.Value;

            try
            {
                Response.Redirect("~/Home/Index.aspx", true);
            }
            catch(ThreadAbortException)
            {
                //Do nothing, natural occurrence with Response.Redirect
            }
        }
    }
}