﻿using System;


namespace ABC.Home
{
    public partial class Logout : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblEnvironment.Text = String.Format("Environment:{0}", Common.EnumHelper.DisplayString(Global.WorkingEnvironment));
                if (Global.WorkingEnvironment == Global.EnvType.Production)
                {
                    divEnvironment.Visible = false;
                }
            }
        }
    }
}