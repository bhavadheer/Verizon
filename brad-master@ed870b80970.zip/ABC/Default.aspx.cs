﻿using System;
using System.Threading;


namespace ABC
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                String clientIP = (Request.ServerVariables["HTTP_X_FORWARDED_FOR"] ?? Request.ServerVariables["REMOTE_ADDR"]).Split(',')[0].Trim();
                switch(Global.WorkingEnvironment)
                {
                    case Global.EnvType.Dev:
                        //Show Login
                        divUserLogin.Visible = true;
                        divAlertLogin.Visible = false;
                        divEnvironment.Visible = true;
                        lblEnvironment.Text = String.Format("Environment:{0}&nbsp;&nbsp;&nbsp;&nbsp;Session Timeout: {1}", Common.EnumHelper.DisplayString(Global.WorkingEnvironment), Session.Timeout);

                        // If (SSO HTTP_VZID is Available) 
                        if (Request.ServerVariables[Global.SSOId] != null && !String.IsNullOrEmpty(Request.ServerVariables[Global.SSOId]))
                        {
                            Navigation.Current.GetUserNavigation(Request.ServerVariables[Global.SSOId].ToString().ToLower(), clientIP);
                            //Check for Logout and Retry
                            if (Navigation.Current.DefaultPage != Navigation.Current.LogoutPage)
                            {
                                try
                                {
                                    Response.Redirect(Navigation.Current.DefaultPage, true);
                                }
                                catch (ThreadAbortException)
                                { }
                            }
                        }
                        break;
                    case Global.EnvType.Staging:
                        break;
                    case Global.EnvType.Test:
                        //Show Login
                        divUserLogin.Visible = true;
                        divAlertLogin.Visible = false;
                        divEnvironment.Visible = true;
                        lblEnvironment.Text = String.Format("Environment:{0}&nbsp;&nbsp;&nbsp;&nbsp;Session Timeout: {1}", Common.EnumHelper.DisplayString(Global.WorkingEnvironment), Session.Timeout);

                        // If (SSO HTTP_VZID is Available) 
                        if (Request.ServerVariables[Global.SSOId] != null && !String.IsNullOrEmpty(Request.ServerVariables[Global.SSOId]))
                        {
                            Navigation.Current.GetUserNavigation(Request.ServerVariables[Global.SSOId].ToString().ToLower(), clientIP);
                            //Check for Logout and Retry
                            if (Navigation.Current.DefaultPage != Navigation.Current.LogoutPage)
                            {
                                try
                                {
                                    Response.Redirect(Navigation.Current.DefaultPage, true);
                                }
                                catch (ThreadAbortException)
                                { }
                            }
                        }
                        break;

                    case Global.EnvType.Production:
                        //Do Not Show Login - Logout User
                        divUserLogin.Visible = false;
                        divAlertLogin.Visible = false;
                        divEnvironment.Visible = false;

                        // If (SSO HTTP_VZID is Available) 
                        if (Request.ServerVariables[Global.SSOId] != null && !String.IsNullOrEmpty(Request.ServerVariables[Global.SSOId]))
                        {
                            Navigation.Current.GetUserNavigation(Request.ServerVariables[Global.SSOId].ToString().ToLower(), clientIP);
                            try
                            {
                                Response.Redirect(Navigation.Current.DefaultPage, true);
                            }
                            catch (ThreadAbortException)
                            { }
                        }
                        else
                        {
                            try
                            {
                                Response.Redirect(Navigation.Current.LogoutPage, true);
                            }
                            catch (ThreadAbortException)
                            { }
                        }
                        break;
                }
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            String clientIP = (Request.ServerVariables["HTTP_X_FORWARDED_FOR"] ?? Request.ServerVariables["REMOTE_ADDR"]).Split(',')[0].Trim();

            Navigation.Current.GetUserNavigation(userLogin.Value.ToLower(), clientIP);
            //Check for Logout and Retry
            if (Navigation.Current.DefaultPage != Navigation.Current.LogoutPage)
            {
                try
                {
                    Response.Redirect(Navigation.Current.DefaultPage, true);
                }
                catch (ThreadAbortException)
                { }
            }
            else
            {
                divAlertLogin.Visible = true;
            }
        }
    }
}