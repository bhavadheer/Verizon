﻿using System;
//using System.Collections.Generic;
using System.Configuration;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Diagnostics;
//using System.Web;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using Common;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration.Fluent;
using Microsoft.Practices.EnterpriseLibrary.Logging;

namespace ABC
{
    public class Global : System.Web.HttpApplication
    {
        #region " Global Variables "
        public enum EnvType
        {
            [DescriptionAttribute("None")]
            NotSet,

            [DescriptionAttribute("Development")]
            Dev,

            [DescriptionAttribute("QA - Test")]
            Test,

            [DescriptionAttribute("UAT - Staging")]
            Staging,

            [DescriptionAttribute("BCP")]
            BCP,

            [DescriptionAttribute("Production")]
            Production
        }

        //Database Connection Strings
        public static String InfraConnectionString;
        public static String ICEConnectionString;
        public static String LotusNotesMigrationConnectionString;
        public static String NotificationConnectionString;
        public static String SCAMSVVLConnectionString;
        public static String SecurityPortalConnectionString;
        public static String SubjectProfileConnectionString;
        public static String STSFrameworkConnectionString;
        public static String ABCConnectionString;

        //Server Fields
        public static String TempPathForFile;
        public static String DomainName;
        public static String ApplicationName;
        public static String WorkingServer; //I.E. vzsecdev-1.verizon.com
        public static EnvType WorkingEnvironment; //I.E. dev
        public static String InfraServer; //I.E. stsinfra.verizon.com
        public static String SecurityReportingPortalServer;
        public static String SSOId;

        public static String ReportUrl;

        //Enterprise Library Fields
        public static String ErrorEmailFrom;
        public static String ErrorEmailTo;
        public static String SMTPServer;
        public static Int32 SMTPPort;
        public static String ApplicationLayerPolicy;
        #endregion

        #region " Application_Start "
        /// <summary>
        /// Application_Start
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup
            InitApp();
        }
        #endregion

        #region " Session_Start "
        /// <summary>
        /// Session_Start
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Session_Start(object sender, EventArgs e)
        {

        }
        #endregion

        #region " Application_BeginRequest "
        /// <summary>
        /// Application_BeginRequest
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }
        #endregion

        #region " Application_AuthenticateRequest "
        /// <summary>
        /// Application_AuthenticateRequest
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }
        #endregion

        #region " Application_Error "
        /// <summary>
        /// Application_Error
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Application_Error(object sender, EventArgs e)
        {
            //// Code that runs when an unhandled error occurs
            //Exception ex = Server.GetLastError();
            //ExceptionPolicy.HandleException(ex, Global.ApplicationLayerPolicy);
        }
        #endregion

        #region " Session_End "
        /// <summary>
        /// Session_End
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Session_End(object sender, EventArgs e)
        {

        }
        #endregion

        #region " Application_End "
        /// <summary>
        /// Application_End
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Application_End(object sender, EventArgs e)
        {

        }
        #endregion

        #region " InitApp "
        /// <summary>
        /// InitApp
        /// </summary>
        private static void InitApp()
        {
            //Default Settings Until Database Loaded
            Global.ApplicationName = "ABC";
            Global.ErrorEmailFrom = "CSAutomation@one.verizon.com";
            Global.ErrorEmailTo = "rajesh.srigakolapu@one.verizon.com;kevin.cook@one.verizon.com;siwei.jin@one.verizon.com";
            Global.SMTPServer = "smtp.verizon.com";
            Global.SMTPPort = 25;
            Global.ApplicationLayerPolicy = "Application Layer Policy";

            //Get Working Environment from Machine Config
            Global.WorkingEnvironment = EnumHelper.GetEnumTypeFromString<EnvType>(ConfigurationManager.AppSettings["Environment"], EnvType.Dev);

            //Global.WorkingEnvironment = EnvType.Test;

            //Global.WorkingEnvironment = EnvType.Staging;
            //Get Infra Connection for Prod or Default
            if (Global.WorkingEnvironment.In(EnvType.Production))
            {
                Global.InfraConnectionString = ConfigurationManager.ConnectionStrings["STSConfigurationConnectionString"].ToString();
            }
            else
            {
                Global.InfraConnectionString = ConfigurationManager.ConnectionStrings["STSNonProdConfigurationConnectionString"].ToString();
            }

            if(Global.WorkingEnvironment.In(EnvType.Production))
            {
                ReportUrl = ConfigurationManager.AppSettings["ProdReport"];
            }
            else if (Global.WorkingEnvironment.In(EnvType.Staging))
            {
                ReportUrl = ConfigurationManager.AppSettings["StagingReport"];
            }
            else if (Global.WorkingEnvironment.In(EnvType.Test))
            {
                ReportUrl = ConfigurationManager.AppSettings["TestReport"];
            }
            else
            {
                ReportUrl = ConfigurationManager.AppSettings["TestReport"];//using testreport as we dont have dev environment as of now.. 
            }

            /* 9/09/2013 C.Omaivboje -- Make a database call to get SSO HTTP Variable */
            Database _dbToConnect = new SqlDatabase(Global.InfraConnectionString);
            using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_STSssoId"))
            {
                using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                {
                    if (resultSet != null && resultSet.Tables.Count > 0)
                    {
                        using (DataTable resultData = resultSet.Tables[0])
                        {
                            if (resultData != null && resultData.Rows.Count > 0)
                            {
                                Global.SSOId = resultData.Rows[0]["SSO_Name"].ToString();
                            }
                        }
                    }
                }
            }

            using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_AppConfig"))
            {
                _dbToConnect.AddInParameter(sqlCmd, "@environment", DbType.String, Global.WorkingEnvironment);

                using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                {
                    if (resultSet != null && resultSet.Tables.Count > 0)
                    {
                        using (DataTable dt = resultSet.Tables[0])
                        {
                            if (dt != null && dt.Rows.Count > 0)
                            {
                                for (int i = 0; i < dt.Rows.Count; i++)
                                {
                                    switch (dt.Rows[i]["ApplicationName"].ToString())
                                    {
                                        /* For ICE */
                                        case "ICE40":
                                            /* Set the connection string */
                                            Global.ICEConnectionString = "Data Source=" + dt.Rows[i]["DBServerName"].ToString() + ";" +
                                                                "Initial Catalog=" + dt.Rows[i]["DatabaseName"].ToString() + ";" +
                                                                "Integrated Security=True;";

                                            /* Set the temp path for storing files */
                                            Global.TempPathForFile = dt.Rows[i]["TempSavingPath"].ToString();

                                            ///* Set the Domain name */
                                            //Global.DomainName = dt.Rows[i]["Domain"].ToString();

                                            //if (!String.IsNullOrEmpty(dt.Rows[i]["ErrorFromEmailList"].ToString()))
                                            //{
                                            //    Global.ErrorEmailFrom = dt.Rows[i]["ErrorFromEmailList"].ToString();
                                            //}
                                            //if (!String.IsNullOrEmpty(dt.Rows[i]["ErrorToEmailList"].ToString()))
                                            //{
                                            //    Global.ErrorEmailTo = dt.Rows[i]["ErrorToEmailList"].ToString();
                                            //}

                                            //Use Loaded Initialization
                                            LoggingInitialization();
                                            break;

                                        /* For LotusNotesMigration */
                                        case "LotusNotesMigration":
                                            /* Set the connection string */
                                            Global.LotusNotesMigrationConnectionString = "Data Source=" + dt.Rows[i]["DBServerName"].ToString() + ";" +
                                                                "Initial Catalog=" + dt.Rows[i]["DatabaseName"].ToString() + ";" +
                                                                "Integrated Security=True;";
                                            break;

                                        /* For SCAMSVVL */
                                        case "LDAPData":
                                            /* Set the connection string */
                                            Global.SCAMSVVLConnectionString = "Data Source=" + dt.Rows[i]["DBServerName"].ToString() + ";" +
                                                                "Initial Catalog=" + dt.Rows[i]["DatabaseName"].ToString() + ";" +
                                                                "Integrated Security=True;";
                                            break;

                                        /* For SecurityPortal */
                                        case "SecurityPortal":
                                            /* Set the connection string */
                                            Global.SecurityPortalConnectionString = "Data Source=" + dt.Rows[i]["DBServerName"].ToString() + ";" +
                                                                "Initial Catalog=" + dt.Rows[i]["DatabaseName"].ToString() + ";" +
                                                                "Integrated Security=True;";
                                            break;

                                        /* For Subject Profiler */
                                        case "SubjectProfiler":
                                            /* Set the connection string */
                                            Global.SubjectProfileConnectionString = "Data Source=" + dt.Rows[i]["DBServerName"].ToString() + ";" +
                                                                "Initial Catalog=" + dt.Rows[i]["DatabaseName"].ToString() + ";" +
                                                                "Integrated Security=True;";
                                            break;

                                        /* For Infra */
                                        case "SoloSubmit":
                                            Global.InfraServer = dt.Rows[i]["Domain"].ToString();
                                            break;

                                        /* For SecurityReportingPortal */
                                        case "SecurityReportingPortal":
                                            Global.SecurityReportingPortalServer = dt.Rows[i]["Domain"].ToString();
                                            break;

                                        /* For Notification */
                                        case "Notification":
                                            Global.NotificationConnectionString = "Data Source=" + dt.Rows[i]["DBServerName"].ToString() + ";" +
                                                                "Initial Catalog=" + dt.Rows[i]["DatabaseName"].ToString() + ";" +
                                                                "Integrated Security=True;";
                                            break;
                                        case "STS_Framework":
                                            //Global.ApplicationName = dt.Rows[i]["ApplicationName"].ToString();
                                            /* Set the connection string */
                                            Global.STSFrameworkConnectionString = "Data Source=" + dt.Rows[i]["DBServerName"].ToString() + ";" +
                                                                "Initial Catalog=" + dt.Rows[i]["DatabaseName"].ToString() + ";" +
                                                                "Integrated Security=True;";

                                            /* Set the temp path for storing files */
                                            //Global.TempPathForFile = dt.Rows[i]["TempSavingPath"].ToString();
                                            /* Set the Domain name */
                                            DomainName = dt.Rows[i]["Domain"].ToString();
                                            break;
                                        case "STSMobile":
                                            //Global.ApplicationName = dt.Rows[i]["ApplicationName"].ToString();
                                            /* Set the connection string */
                                            Global.STSFrameworkConnectionString = "Data Source=" + "STS_Framework" + ";" +
                                                                "Initial Catalog=" + dt.Rows[i]["DatabaseName"].ToString() + ";" +
                                                                "Integrated Security=True;";

                                            /* Set the temp path for storing files */
                                            //Global.TempPathForFile = dt.Rows[i]["TempSavingPath"].ToString();
                                            /* Set the Domain name */
                                            Global.DomainName = dt.Rows[i]["Domain"].ToString();
                                            break;
                                        case "ABC":
                                            Global.ApplicationName = dt.Rows[i]["ApplicationName"].ToString();
                                            /* Set the connection string */
                                            Global.ABCConnectionString = "Data Source=" + dt.Rows[i]["DBServerName"].ToString() + ";" +
                                                                "Initial Catalog=" + dt.Rows[i]["DatabaseName"].ToString() + ";" +
                                                                "Integrated Security=True;";

                                            /* Set the temp path for storing files */
                                            Global.TempPathForFile = dt.Rows[i]["TempSavingPath"].ToString();
                                            /* Set the Domain name */
                                            Global.DomainName = dt.Rows[i]["Domain"].ToString();

                                            /* Set the Domain name */
                                            Global.DomainName = dt.Rows[i]["Domain"].ToString();

                                            if (!String.IsNullOrEmpty(dt.Rows[i]["ErrorFromEmailList"].ToString()))
                                            {
                                                Global.ErrorEmailFrom = dt.Rows[i]["ErrorFromEmailList"].ToString();
                                            }
                                            if (!String.IsNullOrEmpty(dt.Rows[i]["ErrorToEmailList"].ToString()))
                                            {
                                                Global.ErrorEmailTo = dt.Rows[i]["ErrorToEmailList"].ToString();
                                            }
                                            break;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            LoggingInitialization();
        }
        #endregion

        #region " LoggingInitialization "
        /// <summary>
        /// LoggingInitialization
        /// </summary>
        private static void LoggingInitialization()
        {
            var configBuilder = new ConfigurationSourceBuilder();
            var textFormatter = new FormatterBuilder()
                .TextFormatterNamed("Text Formatter")
                .UsingTemplate(@"Timestamp: {timestamp} {newline}Message: {message} {newline}Log Category: {category} {newline}Priority: {priority} {newline}EventId: {eventid} {newline}Severity: {severity} {newline}Title: {title} {newline}Machine: {localMachine} {newline}App Domain: {localAppDomain} {newline}ProcessId: {localProcessId} {newline}Process Name: {localProcessName} {newline}Thread Name: {threadName} {newline}Win32 ThreadId: {win32ThreadId} {newline}Extended Properties: {dictionary({key} - {value} {newline})}");

            configBuilder.ConfigureLogging()
                .WithOptions
                    .DoNotRevertImpersonation()
                    .SpecialSources
                        .LoggingErrorsAndWarningsCategory
                .LogToCategoryNamed("Trace")
                    .WithOptions
                        .SetAsDefaultCategory()
                    //.SendTo
                    //    .RollingFile("Rolling Flat File Trace Listener")
                    //    .RollEvery(Microsoft.Practices.EnterpriseLibrary.Logging.TraceListeners.RollInterval.Month)
                    //    .WhenRollFileExists(Microsoft.Practices.EnterpriseLibrary.Logging.TraceListeners.RollFileExistsBehavior.Increment)
                    //    .CleanUpArchivedFilesWhenMoreThan(4)
                    //    .FormatWith(textFormatter)
                    //    .WithHeader(String.Format("{0} {1} Application", Global.WorkingEnvironment, Global.ApplicationName))
                    //    .WithFooter(".")
                    //    .ToFile("trace.log")
                    .SendTo
                        .Email("Email Trace Listener")
                        .To(Global.ErrorEmailTo)
                        .From(Global.ErrorEmailFrom)
                        .FormatWith(textFormatter)
                        .WithSubjectStart(String.Format("{0} {1} Application", Global.WorkingEnvironment, Global.ApplicationName))
                        .WithSubjectEnd(" ")
                        .UsingSmtpServer(Global.SMTPServer)
                        .UsingSmtpServerPort(Global.SMTPPort)
                        .Unauthenticated();

            configBuilder.ConfigureExceptionHandling()
                .GivenPolicyWithName(Global.ApplicationLayerPolicy)
                .ForExceptionType<System.Exception>()
                .LogToCategory("Trace")
                .WithSeverity(TraceEventType.Error)
                .UsingEventId(100)
                .ThenNotifyRethrow();

            var configSource = new DictionaryConfigurationSource();
            configBuilder.UpdateConfigurationWithReplace(configSource);
            Logger.Reset();
            Logger.SetLogWriter(new LogWriterFactory(configSource).Create(), false);
            var factory = new ExceptionPolicyFactory(configSource);
            ExceptionPolicy.Reset();
            ExceptionPolicy.SetExceptionManager(factory.CreateManager(), false);
        }
        #endregion
    }
}