
/***********************************
 Client Application specific
 **********************************/

var VZGLOBALUIClientCustomizer = {
	"applicationName" : "Application Name" , 
	'userProfileLinks' : [
		{'label' : 'My Profile', 'url' : 'https://aboutyou.verizon.com/YourInfo'}
	]
};