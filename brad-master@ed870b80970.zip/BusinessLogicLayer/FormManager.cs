﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Common;
using DataAccessLayer;

namespace BusinessLogicLayer
{
    public class FormManager : BaseClass
    {
        #region " Private Properties "
        private FormDB _formDB;
        private bool disposed = false;
        #endregion

        #region " Constructor "

        public FormManager(string connectionString)
        {
            _formDB = new FormDB(connectionString);
        }

        #endregion

        #region " Dispose Methods "

        protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            if (disposing)
            {
                if (_formDB != null)
                {
                    _formDB.Dispose();
                }
            }
            disposed = true;
            base.Dispose(disposing);
        }

        #endregion

        #region " GetDynamicFields "
        /// <summary>
        /// GetDynamicFields
        /// </summary>
        /// <param name="formId"></param>
        /// <param name="sectionId"></param>
        /// <returns>List<DynamicField></returns>
        public List<DynamicField> GetDynamicFields(int formId, int sectionId, int currentRole, string formInstance)
        {
            return _formDB.GetDynamicFields(formId, sectionId, currentRole, formInstance);
        }
        #endregion

        #region " GetSectionsByForm "
        public List<FormSection> GetSectionsByForm(int formId, int roleId, int privilegeId)
        {
            return _formDB.GetSectionsByForm(formId, roleId, privilegeId);
        }
        #endregion

        #region " SaveAnswers "
        /// <summary>
        /// SaveAnswers
        /// </summary>
        /// <param name="formId"></param>
        /// <param name="formQuestionId"></param>
        /// <param name="formInstance"></param>
        /// <param name="answerText"></param>
        /// <param name="loggedInStsId"></param>
        public void SaveAnswers(int formSectionId, string formInstance, string answerText, int loggedInStsId)
        {
            _formDB.SaveAnswers(formSectionId, formInstance, answerText, loggedInStsId);
        }
        #endregion

        #region " GetNextFormInstance "
        /// <summary>
        /// GetNextFormInstance
        /// </summary>
        /// <param name="formId"></param>
        /// <returns></returns>
        public string GetNextFormInstance(int formId)
        {
            return _formDB.GetNextFormInstance(formId);
        }
        #endregion

        #region " GetFormInstances "
        /// <summary>
        /// GetFormInstances
        /// </summary>
        /// <param name="formId"></param>
        /// <returns></returns>
        public DataTable GetFormInstances(int formId)
        {
            return _formDB.GetFormInstances(formId);
        }
        #endregion

        #region " GetAuditHistory "
        /// <summary>
        /// GetAuditHistory
        /// </summary>
        /// <param name="formInstance"></param>
        /// <returns>DataTable</returns>
        public DataTable GetAuditHistory(string formInstance)
        {
            return _formDB.GetAuditHistory(formInstance);
        }
        #endregion

        #region " GetBRTLock "
        /// <summary>
        /// GetBRTLock
        /// </summary>
        /// <param name="formInstance"></param>
        /// <param name="StsId"></param>
        /// <returns></returns>
        public DataTable GetBRTLock(string formInstance, int StsId)
        {
            return _formDB.GetBRTLock(formInstance, StsId);
        }
        #endregion

        #region " InsertBRTLock "
        /// <summary>
        /// InsertBRTLock
        /// </summary>
        /// <param name="formInstance"></param>
        /// <param name="stsId"></param>
        /// <returns></returns>
        public DataTable InsertBRTLock(string formInstance, int stsId)
        {
            return _formDB.InsertBRTLock(formInstance, stsId);
        }
        #endregion

        #region " DeleteBRTLock "
        /// <summary>
        /// DeleteBRTLock
        /// </summary>
        /// <param name="BRTLockId"></param>
        /// <returns></returns>
        public void DeleteBRTLock(string FormInstance, int StsId)
        {
            _formDB.DeleteBRTLock(FormInstance, StsId);
        }
        #endregion

        #region " InsertAdditionalQuestion "
        /// <summary>
        /// InsertAdditionalQuestion
        /// </summary>
        /// <param name="questionText"></param>
        /// <param name="responseText"></param>
        /// <param name="formId"></param>
        /// <param name="sectionId"></param>
        /// <param name="formInstance"></param>
        /// <param name="stsid"></param>
        /// <returns>Int32</returns>
        public Int32 InsertAdditionalQuestion(string questionText, string responseText, int formId, int sectionId, string formInstance, int stsid)
        {
            return _formDB.InsertAdditionalQuestion(questionText, responseText, formId, sectionId, formInstance, stsid);
        }
        #endregion

        #region ' SaveFormInstanceType '
        public void SaveFormInstanceType(string FormInstance, int FormInstanceType, bool AllowOverride, int LoggedInStsId)
        {
            _formDB.SaveFormInstanceType(FormInstance, FormInstanceType, AllowOverride, LoggedInStsId);
        }
        #endregion

        #region " GetFormsSearchAudit "
        /** \public     GetFormsSearchAudit 
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method is called to bind the Dashboard Grid section.
         *  \param      FormName int
         *  \param      FormSection int
         *  \param      FormQuestions string
         *  \param      Creator string
         *  \param      DateFromCreated DateTime
         *  \param      DateToCreated DateTime
         *  \param      vzid string
         *  \param      connStr string
         *  \return     A Datatable.
         */
        public DataTable GetFormsSearchAudit(int FormName, string FormInstance, int FormSection, string FormQuestions, int CreatorStsId, DateTime DateFromCreated,
                                            DateTime DateToCreated, int isImport)
        {
            /** Calling method DataAccessLayer._dashboardDB.GetFormsSearch */
            return _formDB.GetFormsSearchAudit(FormName, FormInstance, FormSection, FormQuestions, CreatorStsId, DateFromCreated, DateToCreated, isImport);
        }
        #endregion

        #region " GetFormsSearchAudit "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formInstance"></param>
        /// <param name="formId"></param>
        /// <param name="sectionId"></param>
        /// <returns></returns>
        public DataTable GetValidationResponse(string formInstance, int formId, int sectionId)
        {
            /** Calling method DataAccessLayer._dashboardDB.GetValidationResponse */
            return _formDB.GetValidationResponse(formInstance, formId, sectionId);
        }
        #endregion

        #region " UpdateFormReportStatus "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formid"></param>
        /// <param name="sectionId"></param>
        /// <param name="formInstance"></param>
        /// <param name="loggedInStsId"></param>
        public void UpdateFormReportStatus(int formid, int sectionId, string formInstance, int loggedInStsId)
        {
            /** Calling method DataAccessLayer._dashboardDB.UpdateFormReportStatus */
            _formDB.UpdateFormReportStatus(formid, sectionId, formInstance, loggedInStsId);
        }
        #endregion

        #region " GetLinkedForms "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="masterFormInstance"></param>
        /// <returns></returns>
        public List<LinkedForms> GetLinkedForms(string masterFormInstance)
        {
            return _formDB.GetLinkedForms(masterFormInstance);
        }
        #endregion

        #region " GetBRTAnalysts "
        /// <summary>
        /// GetBRTAnalysts
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable GetBRTAnalysts()
        {
            return _formDB.GetBRTAnalysts();
        }
        #endregion

        #region " GetBRTAnalystInfo "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="logonId"></param>
        /// <returns></returns>
        public List<BRTAnalyst> GetBRTAnalystInfo(string logonId)
        {
            var analysts = new List<BRTAnalyst>();
            var analystDt = _formDB.GetBRTAnalystInfo(logonId);

            if (analystDt != null && analystDt.Rows.Count > 0)
            {
                foreach (DataRow dr in analystDt.Rows)
                {
                    var dd = new BRTAnalyst
                    {
                        LogonId = dr["LogonId"].ToString(),
                        Email = dr["Email"].ToString(),
                        WorkPhone = dr["WorkPhone"].ToString()
                    };
                    analysts.Add(dd);
                }
            }
            return analysts;
        }
        #endregion

        #region " CheckDropDownDependency "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formSectionId"></param>
        /// <returns></returns>
        public DataTable CheckDropDownDependency(int formSectionId)
        {
            return _formDB.CheckDropDownDependency(formSectionId);
        }
        #endregion

        #region " GetFormCompanyName "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formInstance"></param>
        /// <returns></returns>
        public List<LinkedForms> GetFormCompanyName(string formInstance)
        {
            return _formDB.GetFormCompanyName(formInstance);
        }
        #endregion

        #region " GetUserFormPartial "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formId"></param>
        /// <returns></returns>
        public List<UserFormPartial> GetUserFormPartial(int formId)
        {
            return _formDB.GetUserFormPartial(formId);
        }
        #endregion

        #region 'InsertUserPartialForm'
        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputData"></param>
        /// <param name="formId"></param>
        /// <param name="LoggedInStsId"></param>
        /// <returns></returns>
        public string InsertUserPartialForm(string inputData, int formId, int LoggedInStsId)
        {
            return _formDB.InsertUserPartialForm(inputData, formId, LoggedInStsId);
        }
        #endregion

        #region 'InsertAuditViewPrint'
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formInstance"></param>
        /// <param name="LoggedInStsId"></param>
        /// <param name="loggedinUser"></param>
        /// <param name="eventType"></param>
        /// <returns></returns>
        public void InsertAuditViewPrint(string formInstance, int LoggedInStsId, string loggedinUser, string eventType)
        {
            _formDB.InsertAuditViewPrint(formInstance, LoggedInStsId, loggedinUser, eventType);
        }
        #endregion

        #region " GetAuditViewPrint "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formInstance"></param>
        /// <returns></returns>
        public DataTable GetAuditViewPrint(string formInstance)
        {
            return _formDB.GetAuditViewPrint(formInstance);
        }
        #endregion

        #region " GetAuditViewPrintExport "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="DateFromCreated"></param>
        /// <param name="DateToCreated"></param>
        /// <returns></returns>
        public DataTable GetAuditViewPrintExport(DateTime DateFromCreated, DateTime DateToCreated)
        {
            return _formDB.GetAuditViewPrintExport(DateFromCreated, DateToCreated);
        }
        #endregion

        #region " UpdateFormReviewStatus "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formid"></param>
        /// <param name="sectionId"></param>
        /// <param name="formInstance"></param>
        /// <param name="loggedInStsId"></param>
        public void UpdateFormReviewStatus(int formid, int sectionId, string formInstance, int loggedInStsId)
        {
            /** Calling method DataAccessLayer._dashboardDB.UpdateFormReportStatus */
            _formDB.UpdateFormReviewStatus(formid, sectionId, formInstance, loggedInStsId);
        }
        #endregion

        #region " GetFormSectionIdByQuestion "
        public int GetFormSectionIdByQuestion(int formId, int sectionId, int formquestionId)
        {
            return _formDB.GetFormSectionIdByQuestion(formId, sectionId, formquestionId);
        }
        #endregion
    }
}
