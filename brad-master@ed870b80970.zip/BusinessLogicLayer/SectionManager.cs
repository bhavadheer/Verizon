﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Common;
using DataAccessLayer;

namespace BusinessLogicLayer
{
    public class SectionManager : BaseClass
    {
        #region " Private Properties "
        private SectionDB _sectionDB;
        private bool disposed = false;
        #endregion

        #region " Constructor "

        public SectionManager(string connectionString)
        {
            _sectionDB = new SectionDB(connectionString);
        }

        #endregion

        #region " Dispose Methods "

        protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            if (disposing)
            {
                if (_sectionDB != null)
                {
                    _sectionDB.Dispose();
                }
            }
            disposed = true;
            base.Dispose(disposing);
        }

        #endregion

        #region " GetSectionsByForm "
        public DataTable GetSections()
        {
            return _sectionDB.GetSections();
        }
        #endregion

        #region " UpdateSections "
        public void UpdateSections(int sectionId, string sectionName, string sectionDesc, int stsId)
        {
            _sectionDB.UpdateSections(sectionId, sectionName, sectionDesc, stsId);
        }
        #endregion

        #region " UpdateSections "
        public void UpdateSectionOrder(string sectionOrderInfo, int stsId)
        {
            _sectionDB.UpdateSectionOrder(sectionOrderInfo, stsId);
        }
        #endregion

        #region " UpdateFormSections "
        public void UpdateFormSections(int formSectionId, int newSectionId, int stsId)
        {
            _sectionDB.UpdateFormSections(formSectionId, newSectionId, stsId);
        }
        #endregion
        #region " UpdateSectionQuestionOrder "
        public void UpdateSectionQuestionOrder(string sectionQuesOrderInfo, int stsId)
        {
            _sectionDB.UpdateSectionQuestionOrder(sectionQuesOrderInfo, stsId);
        }
        #endregion
    }
}
