﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using Common;
using DataAccessLayer;

namespace BusinessLogicLayer
{
    public class AttachmentManager : IDisposable
    {

        /*! \class      AttachmentManager
        *  \implements  IDisposable 
        *  \brief       uploading the Attachments
        */
        private bool _disposed = false;

        AttachmentsDB attachmentsDB;

        public AttachmentManager(string connectionString)
        {
            /**Initialize connectionstring for SQL connection*/
            attachmentsDB = new AttachmentsDB(connectionString);
        }

        #region " Destructor "
        /**\public  ~AttachmentsManager 
         * \details call dispose(false)
         */
        ~AttachmentManager()
        {
            this.Dispose(false);
        }
        #endregion

        #region Protected Methods
        /**\protected  Dispose 
         * \details Dispose Navigation object
         * \details It cleans resources both managed and native
         */
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    /**call dispose of any object used in this class*/
                    if (attachmentsDB != null)
                    {
                        attachmentsDB.Dispose();
                    }
                }
            }

            _disposed = true;
        }
        #endregion

        #region Dispose
        /**\public  Dispose 
         * \details Over riding method for the dispose interface.
         */
        public void Dispose()
        {
            /**call dispose of any object used in this class*/
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

        #region " GetAttachments "
        /** \public      GetAttachments 
          *  \details    Get Attachments associated with a CR.
          *  \param      CrId
          *  \param      StsId
          *  \return     returns the values.
          */
        public DataTable GetAttachments(int crId, int stsId)
        {
            return attachmentsDB.GetAttachments(crId, stsId);
        }
        #endregion

        #region " InsertAttachmentWithStream "
        /// <summary>
        /// InsertAttachmentWithStream
        /// </summary>
        /// <param name="attachmentsObj"></param>
        /// <param name="vzid"></param>
        /// <param name="fs"></param>
        /// <returns></returns>
        public DataTable InsertAttachmentWithStream(Attachment attachmentObj, string FormInstance,int identifier,int stsId, Stream fs)
        {
            return attachmentsDB.InsertAttachmentWithStream(attachmentObj, FormInstance, identifier, stsId, fs);
        }
        #endregion

        #region " DeleteAttachment "
        /** \public     DeleteAttachment
         *  \details    Deleate Attachment 
         *  \param      AttachmentId
         *  \return     data table with outcome.
         */
        public DataTable DeleteAttachment(int attachementId)
        {
            return attachmentsDB.DeleteAttachment(attachementId);
        }
        #endregion

        #region " GetAttachmentsByID "
        /** \public     GetAttachmentsByID
         *  \details    Get Attachment by AttachmentId
         *  \param      AttachmentId  
         *  \return     returns a data table values.
         */
        public DataTable GetAttachmentsByID(int AttachmentId)
        {
            return attachmentsDB.GetAttachmentsByID(AttachmentId);
        }

        #endregion
        
        #region " GetAttachmentsByFormVendor "
        /** \public     GetAttachmentsByFormVendor
         *  \details    Get Attachment by formid and vendorid
         *  \param      FormId  
         *  \param      VendorId 
         *  \param      FormQuestionId  
         *  \return     returns a data table values.
         */
        public DataTable GetAttachmentsByFormVendor(int FormSectionId)
        {
            return attachmentsDB.GetAttachmentsByFormVendor(FormSectionId);
        }
        
        #endregion

        #region " GetAttachmentsByFormVendorQuestion "
        /** \public     GetAttachmentsByFormVendorQuestion
         *  \details    Get Attachment by formid, vendorid and questionid
         *  \param      FormId  
         *  \param      VendorId 
         *  \param      FormQuestionId  
         *  \return     returns a data table values.
         */
        public DataTable GetAttachmentsByFormVendorQuestion(int FormId, int VendorId, int FormQuestionId)
        {
            return attachmentsDB.GetAttachmentsByFormVendorQuestion(FormId, VendorId, FormQuestionId);
        }

        #endregion

        #region " LoadAttachments "
        /// <summary>
        /// LoadAttachments
        /// </summary>
        /// <param name="formSectionId"></param>
        /// <param name="formInstance"></param>
        /// <param name="identifier"></param>
        /// <returns></returns>
        public DataTable LoadAttachments(int formSectionId, string formInstance, int identifier)
        {
            return attachmentsDB.LoadAttachments(formSectionId, formInstance, identifier);
        }
        #endregion
    }
}
