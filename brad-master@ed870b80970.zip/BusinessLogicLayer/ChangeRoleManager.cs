﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Common;
using DataAccessLayer;

namespace BusinessLogicLayer
{
    public class ChangeRoleManager : BaseClass
    {
        #region Private Members
        private bool disposed = false;
        ChangeRoleDB changeRoleDB;
        #endregion

        #region " Constructor "
        /*! \class   ChangeRoleManager
        *  \brief       It is used to get and insert roles data
        *  \section     First Draft
         *  \author      Shrutesh Vadiyala
         *  \date        6/22/2012
         *  \details   connectionstring for SQL connection.
         *  \param     ConnectionString
         */
        public ChangeRoleManager(string connectionString)
        {
            /**Initialize connectionstring for SQL connection*/
            changeRoleDB = new ChangeRoleDB(connectionString);
        }
        #endregion

        #region " Dispose Methods "
        protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            if (disposing)
            {
                if (changeRoleDB != null)
                {
                    changeRoleDB.Dispose();
                }
            }
            disposed = true;
            base.Dispose(disposing);
        }
        #endregion

        #region " GetRolesByRoleID "
        /** \public     GetRolesByRoleID 
         *  \section    First Draft
         *  \author     Vijender Reddy Chintalapudi
         *  \date       09/19/2012
         *  \details    Get the Role based on roleid. 
         *  \param     roleID
         */
        public DataTable GetRolesByRoleID(String roleId)
        {
            return changeRoleDB.GetRolesByRoleID(roleId);
        }
        #endregion

        #region " GetAllRoles "
        /** \public     GetAllRoles 
         *  \section    First Draft
         *  \author     Shrutesh Vadiyala
         *  \date       6/22/2012
         *  \details    Get the Roles. 
         *  \param     stsid
         */
        public DataTable GetAllRoles(int stsid)
        {
            /** Calling method DataAccessLayer. changeRoleDB.GetAllRoles() */
            return changeRoleDB.GetAllRoles(stsid);
        }
        #endregion

        #region " GetUserRole "
        /** \public     GetUserRole  
         *  \section    First Draft
         *  \author     Shrutesh Vadiyala
         *  \date       6/22/2012
         *  \details    Get the user Role. 
         *  \param      stsid
         *  \param      role
         */
        public DataTable GetUserRole(int stsid, String role)
        {
            /** Calling method DataAccessLayer. changeRoleDB.GetUserRole() */
            return changeRoleDB.GetUserRole(stsid, role);
        }
        #endregion
    }
}
