﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Common;
using DataAccessLayer;

namespace BusinessLogicLayer
{
    public class ReferenceManager : BaseClass
    {
        #region " Private Properties "
        private ReferenceManagerDB _refMgrDB;
        private bool disposed = false;
        #endregion

        #region " Constructor "

        public ReferenceManager(string connectionString)
        {
            _refMgrDB = new ReferenceManagerDB(connectionString);
        }

        #endregion

        #region " Dispose Methods "

        protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            if (disposing)
            {
                if (_refMgrDB != null)
                {
                    _refMgrDB.Dispose();
                }
            }
            disposed = true;
            base.Dispose(disposing);
        }

        #endregion

        #region " Public Methods "

        #region " GetUserCredentials "
        public DataTable GetUserCredentials(string vzId)
        {
            return _refMgrDB.GetUserCredentials(vzId);
        }
        #endregion

        #region " GetStsId "
        public DataTable GetStsId(string userId)
        {
            return _refMgrDB.GetStsId(userId);
        }
        #endregion

        #region " SaveUserAccessHistory "
        /// <summary>
        /// INSERT THE LOGGED IN VZID  TO THE UerAccessHistory
        /// </summary>
        /// <param name="vzid"></param>
        /// <returns></returns>
        public int SaveUserAccessHistory(int loggedInStsId, string loggedInUserName, string action)
        {
            return _refMgrDB.SaveUserAccessHistory(loggedInStsId, loggedInUserName, action);
        }
        #endregion

        #region " GetMainNavigation "
        /// <summary>
        /// Returns Main navigation list based on role
        /// </summary>
        public DataTable GetMainNavigation(int roleId)
        {
            return _refMgrDB.GetMainNavigation(roleId);
        }
        #endregion

        #region " GetMainTabToHighlight "
        /// <summary>
        /// Returns Main tab info for highlighting
        /// </summary>
        public DataTable GetMainTabToHighlight(string pageName)
        {
            return _refMgrDB.GetMainTabToHighlight(pageName);
        }
        #endregion

        #region " GetRightLinks "
        /// <summary>
        /// Returns Main navigation list based on role
        /// </summary>
        public DataTable GetRightLinks(int roleId, string mainTabId)
        {
            return _refMgrDB.GetRightLinks(roleId, mainTabId);
        }
        #endregion

        #region " IsURLAccessible "
        public DataTable IsUrlAccessible(int roleId, string url)
        {
            return _refMgrDB.IsUrlAccessible(roleId, url);
        }
        #endregion

       

        #endregion
    }
}
