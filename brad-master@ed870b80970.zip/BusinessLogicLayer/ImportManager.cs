﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common;
using DataAccessLayer;
using System.Data;
using System.Data.SqlClient;

namespace BusinessLogicLayer
{
    public class ImportManager : BaseClass
    {
        #region " Private Properties "
        private ImportDB _importDB;
        private bool disposed = false;
        #endregion

        #region " Constructor "

        public ImportManager(string connectionString)
        {
            _importDB = new ImportDB(connectionString);
        }

        #endregion

        #region " Dispose Methods "

        protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            if (disposing)
            {
                if (_importDB != null)
                {
                    _importDB.Dispose();
                }
            }
            disposed = true;
            base.Dispose(disposing);
        }

        #endregion

        #region " Public Methods "

        #region " GetFormInfo "
        /** \public     GetFormInfo 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/11/2016
         *  \details    This method returns form information based on form and role.
         *  \param      formId int
         *  \param      roleId int
         *  \returns    DataTable
         */
        public DataTable GetFormInfo(int formId, int roleId)
        {
            /** Calling method DataAccessLayer._importDB.GetFormInfo */
            return _importDB.GetFormInfo(formId, roleId);
        }
        #endregion

        #region "InsertFormImportQuestionBank"
        /** \public    InsertFormImportQuestionBank 
        *  \section    First Draft
        *  \author     Bharath Bellam
        *  \date       03/14/2016
        *  \details    Insert uploaded Excel records into FormResponse
        *  \returns    
        */
        public void InsertFormImportQuestionBank(int formId, int roleId, int stsId)
        {
            _importDB.InsertFormImportQuestionBank(formId, roleId, stsId);
        }
        #endregion

        #region " ValidateFormImport "
        /** \public     ValidateFormImport 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/22/2016
         *  \details    This method returns form validation information 
         *  \returns    DataTable
         */
        public DataTable ValidateFormImport(int stsid)
        {
            /** Calling method DataAccessLayer._importDB.ValidateFormImport */
            return _importDB.ValidateFormImport(stsid);
        }
        #endregion
        #endregion
    }
}
