﻿using System;
using System.Data;
using Common;
using DataAccessLayer;

namespace BusinessLogicLayer
{
    public class DropDownDataManager : BaseClass
    {
        #region " Private Properties "
        private DropDownDataDB _dropDownDataDB;
        private bool disposed = false;
        #endregion

        #region " Constructor "

        public DropDownDataManager(string connectionString)
        {
            _dropDownDataDB = new DropDownDataDB(connectionString);
        }

        #endregion

        #region " Dispose Methods "

        protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            if (disposing)
            {
                if (_dropDownDataDB != null)
                {
                    _dropDownDataDB.Dispose();
                }
            }
            disposed = true;
            base.Dispose(disposing);
        }

        #endregion

        #region " GetAllDropDownDataByCategory "
        /// <summary>
        /// GetAllDropDownDataByCategory
        /// </summary>
        /// <param name="ddType"></param>
        /// <returns>DataTable</returns>
        public DataTable GetAllDropDownDataByCategory(string ddType)
        {
            return _dropDownDataDB.GetAllDropDownDataByCategory(ddType);
        }
        #endregion

        #region " UpdateDropdownData "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="category"></param>
        /// <param name="ddValues"></param>
        /// <param name="vzId"></param>
        public void UpdateDropdownData(string category, string ddValues, string vzId)
        {
            _dropDownDataDB.UpdateDropdownData(category, ddValues, vzId);
        }
        #endregion

        #region " DeleteDropdownVal "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ddId"></param>
        /// <param name="vzId"></param>
        /// <returns></returns>
        public DataTable DeleteDropdownVal(int ddId, string vzId)
        {
            return _dropDownDataDB.DeleteDropdownVal(ddId, vzId);
        }
        #endregion

        #region " GetDropDownCategories "
        /// <summary>
        /// GetDropDownCategories
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable GetDropDownCategories()
        {
            return _dropDownDataDB.GetDropDownCategories();
        }
        #endregion

        #region " GetSectionsDropDown "
        /// <summary>
        /// GetSectionsDropDown
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable GetSectionsDropDown()
        {
            return _dropDownDataDB.GetSectionsDropDown();
        }
        #endregion
    }
}
