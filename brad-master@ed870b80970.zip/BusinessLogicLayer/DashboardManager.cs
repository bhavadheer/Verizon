﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common;
using DataAccessLayer;
using System.Data;
using System.Data.SqlClient;

namespace BusinessLogicLayer
{
    public class DashboardManager : BaseClass
    {
        #region " Private Properties "
        private DashboardDB _dashboardDB;
        private bool disposed = false;
        #endregion

        #region " Constructor "

        public DashboardManager(string connectionString)
        {
            _dashboardDB = new DashboardDB(connectionString);
        }

        #endregion

        #region " Dispose Methods "

        protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            if (disposing)
            {
                if (_dashboardDB != null)
                {
                    _dashboardDB.Dispose();
                }
            }
            disposed = true;
            base.Dispose(disposing);
        }

        #endregion

        #region " Public Methods "

        #region " GetPersonnelList "
        /** \public     GetPersonnelList 
         *  \author     David Martinez
         *  \date       03/21/2016
         *  \desc       Retrieve personnel list
         *  \param      none
         */
        public DataTable GetPersonnelList()
        {
            /** Calling method DataAccessLayer._dashboardDB.GetPersonnelList() */
            return _dashboardDB.GetPersonnelList();
        }

        #endregion

        #region " GetFormsDropDownList "
        /** \public     GetFormsDropDownList 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method returns DropDown List based on ddType,ParentslectedValue and role
         *  \param      ddType string
         *  \param      roleId string
         *  \param      ParentSelectedValue int
         *  \returns    DataTable
         */
        public DataTable GetFormsDropDownList()
        {
            /** Calling method DataAccessLayer._dashboardDB.GetFormsDropDownList() */
            return _dashboardDB.GetFormsDropDownList();
        }
        #endregion

        #region " GetFormSectionDropDownList "
        /** \public     GetFormSectionDropDownList 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method returns DropDown List based on type and role.
         *  \param      ddType string
         *  \param      roleId string
         *  \returns    DataTable
         */
        public DataTable GetFormSectionDropDownList(int ddType, int roleId, int privilegeId)
        {
            /** Calling method DataAccessLayer._dashboardDB.GetFormSectionDropDownList */
            return _dashboardDB.GetFormSectionDropDownList(ddType, roleId, privilegeId);
        }
        #endregion

        #region " GetFormsSearch "
        /** \public     GetFormsSearch 
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    This method is called to bind the Dashboard Grid section.
         *  \param      FormName int
         *  \param      FormSection int
         *  \param      FormQuestions string
         *  \param      Creator string
         *  \param      DateFromCreated DateTime
         *  \param      DateToCreated DateTime
         *  \param      vzid string
         *  \param      connStr string
         *  \return     A Datatable.
         */
        public DataTable GetFormsSearch(int FormName, string FormInstance, string currentReportStatus,
                                        string analystName, DateTime DateFromCreated, DateTime DateToCreated,
                                        int ShowType, int stsId, string isUrgent, string currentReviewStatus)
        {
            /** Calling method DataAccessLayer._dashboardDB.GetFormsSearch */
            return _dashboardDB.GetFormsSearch(FormName, FormInstance, currentReportStatus, analystName,
                                                DateFromCreated, DateToCreated, ShowType, stsId, isUrgent,
                                                currentReviewStatus);
        }
        #endregion

        #region " GetGlobalSearch "
        /** \public     GetGlocalSearch 
         *  \author     David Martinez
         *  \date       03/10/2016
         *  \desc       Retrieve search results
         *  \param      inSearchParam string
         */
        public DataTable GetGlobalSearch(string inSearchParam, int? questID, int searchType)
        {
            return _dashboardDB.GetGlobalSearch(inSearchParam, questID, searchType);
        }
        #endregion

        #region " ExportGlobalSearchResults "
        /** \public     ExportGlobalSearchResults 
         *  \author     Bharath Bellam
         *  \date       08/15/2016
         *  \desc       To export global search results to excel
         *  \param      inSearchParam string
         */
        public DataTable ExportGlobalSearchResults(string inSearchParam, int? questID, int searchType)
        {
            return _dashboardDB.ExportGlobalSearchResults(inSearchParam, questID, searchType);
        }
        #endregion

        #region " DeleteForm "
        /** \public     DeleteForm 
         *  \author     Rajesh Srigakolapu
         *  \date       03/28/2017
         *  \details    This method is called to bind the Dashboard Grid section.
         *  \param      FormSection int
         *  \param      stsId int
         *  \param      connStr string
         *  \return     A Datatable.
         */
        public DataTable DeleteForm(string FormInstance, bool isActive, int stsId)
        {
            /** Calling method DataAccessLayer._dashboardDB.GetFormsSearch */
            return _dashboardDB.DeleteForm(FormInstance, isActive, stsId);
        }
        #endregion

        #region " GetGlobalFilter "
        /** \public     GetGlobalFilter 
         *  \section    First Draft
         *  \author     Rajesh Srigakolapu
         *  \date       09/13/2017
         *  \details    Used qry_GetDropdownQueGlobalCategory to Returns DropDown List based on ddType,ParentslectedValue and role
         *  \param      ddType string
         *  \param      roleId string
         *  \param      ParentSelectedValue int
         *  \returns    DataTable
         */
        public DataTable GetGlobalFilter()

        {
            /** Calling method DataAccessLayer._dashboardDB.GetFormSectionDropDownList */
            return _dashboardDB.GetGlobalFilter();
        }
        #endregion

        #region " GetFormQuestions "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formId"></param>
        /// <param name="sectionId"></param>
        /// <param name="roleId"></param>
        /// <returns></returns>
        public DataTable GetFormQuestions(int formId, int sectionId, int roleId)
        {
            return _dashboardDB.GetFormQuestions(formId, sectionId, roleId);

        }
        #endregion

        #region " GetFormQuestions "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="questionId"></param>
        /// <returns></returns>
        public DataTable GetFormQuestionById(int questionId)
        {
            return _dashboardDB.GetFormQuestionById(questionId);

        }
        #endregion

        #region " UpdateFormQuestions "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="questionId"></param>
        /// <param name="questionText"></param>
        /// <param name="isRequired"></param>
        /// <param name="stsId"></param>
        /// <returns></returns>
        public void UpdateFormQuestions(int questionId, string questionText, int isRequired, int stsId)
        {
            _dashboardDB.UpdateFormQuestions(questionId, questionText, isRequired, stsId);
        }
        #endregion

        #region " InsertFormQuestions "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="questionText"></param>
        /// <param name="ansControlType"></param>
        /// <param name="ddIdentifier"></param>
        /// <param name="isRequired"></param>
        /// <param name="formId"></param>
        /// <param name="sectionId"></param>
        /// <param name="stsId"></param>
        public void InsertFormQuestions(string questionText, int ansControlType, string ddIdentifier, int isRequired, string formId, string sectionId, int stsId)
        {
            _dashboardDB.InsertFormQuestions(questionText, ansControlType, ddIdentifier, isRequired, formId, sectionId, stsId);
        }
        #endregion

        #region " GetBRTTimeReport "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="businessRel"></param>
        /// <param name="formInstance"></param>
        /// <returns></returns>
        public DataTable GetBRTTimeReport(string businessRel, string formInstance)
        {
            return _dashboardDB.GetBRTTimeReport(businessRel, formInstance);

        }
        #endregion

        #region " GetBRTTimeReportExport "
        /// <summary>
        /// /
        /// </summary>
        /// <param name="businessRel"></param>
        /// <param name="formInstance"></param>
        /// <returns></returns>
        public DataTable GetBRTTimeReportExport(string businessRel, string formInstance)
        {
            return _dashboardDB.GetBRTTimeReportExport(businessRel, formInstance);

        }
        #endregion

        #region " GetQuestionsGlobalCategory "
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable GetQuestionsGlobalCategory()
        {
            return _dashboardDB.GetQuestionsGlobalCategory();
        }
        #endregion

        #region " InsertGlobalCatQuestions "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="questionIds"></param>
        /// <param name="stsId"></param>
        public void InsertGlobalCatQuestions(string questionIds, int stsId)
        {
            _dashboardDB.InsertGlobalCatQuestions(questionIds, stsId);
        }
        #endregion

        #region " ExportFormSearchResults "
        /** \public     ExportFormSearchResults 
         *  \author     Rajesh Srigakolapu
         *  \date       12/22/2017
         *  \desc       To export Forms search results to excel
         *  \param      inSearchParam string
         */
        public DataTable ExportFormSearchResults(int FormName, string FormInstance, string currentReportStatus,
                                                string analystName, DateTime DateFromCreated, DateTime DateToCreated,
                                                int ShowType, int userStsId, string isUrgent, string currentReviewStatus)
        {
            return _dashboardDB.ExportFormSearchResults(FormName, FormInstance, currentReportStatus,
                                                        analystName, DateFromCreated, DateToCreated,
                                                        ShowType, userStsId, isUrgent, currentReviewStatus);
        }
        #endregion

        #region " GetUnblockFormsSearch "
        /** \public     GetFormsSearch 
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    Used qry_FormsSearch and Based on Search Criteria it pulls all results from Database.
         *  \param      userStsId int
         *  \return     A Datatable.
         */
        public DataTable GetUnblockFormsSearch(int userStsId)
        {
            return _dashboardDB.GetUnblockFormsSearch(userStsId);
        }
        #endregion

        #endregion
    }
}
