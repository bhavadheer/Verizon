﻿using System;
using System.Collections.Generic;
using System.Data;
using DataAccessLayer;
using Common;

namespace BusinessLogicLayer
{
    public class NavigationManager : IDisposable
    {
        #region " Private Members "
        private bool disposed = false;
        private NavigationDB navDB = null;
        #endregion

        #region " Constructor "
        /// <summary>
        /// NavigationManager
        /// </summary>
        /// <param name="connectionString"></param>
        public NavigationManager(string connectionString)
        {
            navDB = new NavigationDB(connectionString);
        }
        #endregion

        #region " Destructor "
        /// <summary>
        /// NavigationManager dispose(false)
        /// </summary>
        ~NavigationManager()
        {
            this.Dispose(false);
        }
        #endregion

        #region " Public Methods "

        #region " Dispose Methods "

        #region " Dispose "
        /// <summary>
        /// Dispose NavigationDB object
        /// </summary>
        public void Dispose()
        {
            //call dispose of any object used in this class
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

        #region " Dispose(bool disposing) "
        /// <summary>
        /// Dispose NavigationDB object.
        /// It cleans resources both managed and native
        /// </summary>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    //call dispose of any object used in this class
                    if (navDB != null)
                    {
                        navDB.Dispose();
                    }
                }
            }

            disposed = true;
        }

        #endregion

        #endregion

        #region " GetUserCredentials "
        /// <summary>
        /// GetUserCredentials
        /// </summary>
        /// <param name="vzidOrEid"></param>
        /// <returns>DataTable</returns>
        public DataTable GetUserCredentials(string vzidOrEid)
        {
            return navDB.GetUserCredentials(vzidOrEid);
        }
        #endregion

        #region " GetUserRoles "
        /// <summary>
        /// GetUserRoles
        /// </summary>
        /// <param name="userStsId"></param>
        /// <returns>List<RoleType></returns>
        public List<RoleType> GetUserRoles(int userStsId)
        {
            return navDB.GetUserRoles(userStsId);
        }
        #endregion

        #region " GetUserAreas "
        /// <summary>
        /// GetUserAreas
        /// </summary>
        /// <param name="userStsId"></param>
        /// <param name="currentRole"></param>
        /// <returns>List<Location></returns>
        public List<Location> GetUserAreas(int userStsId, RoleType currentRole)
        {
            return navDB.GetUserAreas(userStsId, currentRole);
        }
        #endregion

        #region " GetUserAreas "
        /// <summary>
        /// GetUserAreas
        /// </summary>
        /// <param name="userStsId"></param>
        /// <param name="currentRole"></param>
        /// <returns>List<Location></returns>
        public List<Location> GetAllUserAreas(RoleType currentRole)
        {
            return navDB.GetUserAreas(-1, currentRole);
        }
        #endregion

        #region " GetMasterMenu "
        /// <summary>
        /// GetMasterMenu
        /// </summary>
        /// <param name="currentRole"></param>
        /// <param name="parentMenuId"></param>
        /// <returns>List<MenuData></returns>
        public List<MenuData> GetMasterMenu(int currentRole)
        {
            return navDB.GetMasterMenu(currentRole);
        }
        #endregion

        #region " SaveUserAccessHistory "
        public int SaveUserAccessHistory(string loggedInId, string loggedInUserName, string action, int loggedInStsId, string ipAddress)
        {
            return navDB.SaveUserAccessHistory(loggedInId, loggedInUserName, action, loggedInStsId, ipAddress);
        }
        #endregion

        public List<Announcement> GetAnnouncments(int userStsid)
        {
            return navDB.GetAnnouncments(userStsid);
        }

        #endregion
    }
}
