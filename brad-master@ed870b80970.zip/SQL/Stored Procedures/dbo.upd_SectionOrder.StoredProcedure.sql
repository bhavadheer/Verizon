-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Rajesh Srigakolapu
-- Create date: 1/30/2018
-- Description:	Update sections
-- =============================================
CREATE PROCEDURE dbo.upd_SectionOrder
	@sectionOrderInfo VARCHAR(2000),
	@stsId INT
AS
BEGIN
	DECLARE @splitSectionInfo VARCHAR(100);
	DECLARE @currentId INT;
	DECLARE @sectionId INT;
	DECLARE @sectionOrder INT;

	SELECT Id,
           [Value] INTO #temp1
	FROM dbo.Split(@sectionOrderInfo, '^');
	WHILE EXISTS (SELECT Id,
						   [Value]
					FROM #temp1)
	BEGIN
	
		SELECT TOP(1) @currentId = Id,  @splitSectionInfo = [Value] FROM #temp1 ORDER BY Id;

		SELECT TOP(1) @sectionId = [Value] FROM dbo.Split(@splitSectionInfo, ';') ORDER BY Id;
		SELECT TOP(2) @sectionOrder = [Value] FROM dbo.Split(@splitSectionInfo, ';') ORDER BY Id;

		UPDATE dbo.Section
		SET  
			SectionOrder = @sectionOrder,
			LastModDate = GETDATE(),
			LastModByStsId = @stsId
		WHERE SectionID = @sectionID;

		DELETE FROM #temp1 WHERE ID = @currentId;-- ORDER BY Id;
	END

	DROP TABLE #temp1;
END
GO
