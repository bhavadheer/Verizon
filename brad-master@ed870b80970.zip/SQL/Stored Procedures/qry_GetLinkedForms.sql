USE [BRT]

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- <author>Rajesh Srigakolapu</author>
-- <date>9/20/2017</date>  
-- <calling applications>ABC</calling applications>
-- <revisions> 
-- </revisions>  
-- ==============================================
CREATE PROCEDURE dbo.qry_GetLinkedForms
@masterFormInstance VARCHAR(100)
AS
BEGIN
	
	SELECT FR.FormInstance
	FROM dbo.FormResponse FR
	INNER JOIN dbo.FormSection FS ON FS.FormSectionID = FR.FormSectionID
	INNER JOIN dbo.Section S ON S.SectionID = FS.SectionID
	INNER JOIN dbo.Form F ON F.FormID = FS.FormID
	INNER JOIN dbo.FormQuestion FQ ON FQ.FormQuestionID = FS.FormQuestionID
	WHERE FQ.QuestionText = 'Please Enter Form Number for Main Review'
	AND AnswerText = @masterFormInstance;

END
GO
