/*    ==Scripting Parameters==

    Source Server Version : SQL Server 2012 (11.0.6020)
    Source Database Engine Edition : Microsoft SQL Server Enterprise Edition
    Source Database Engine Type : Standalone SQL Server

    Target Server Version : SQL Server 2012
    Target Database Engine Edition : Microsoft SQL Server Enterprise Edition
    Target Database Engine Type : Standalone SQL Server
*/

USE [BRT]
GO

/****** Object:  StoredProcedure [dbo].[ins_FormQuestions]    Script Date: 11/16/2017 1:19:42 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Rajesh Srigakolapu
-- Create date: 3/24/2016
-- Description:	Insert form additional questions
-- =============================================
CREATE PROCEDURE [dbo].[ins_FormQuestions] 
	@questionText VARCHAR(MAX), 
	@answerControlType INT,
	@ddIdentifier VARCHAR(50),
	@isRequired INT,
	@formId VARCHAR(20),
	@sectionId VARCHAR(100),
	@stsId INT,
	@questionId INT OUTPUT
	 
AS
BEGIN
	
	SET NOCOUNT ON; 

	DECLARE @questionNumber INT = 0;
	DECLARE @SecQuestionOrder INT = 0;
	
	SELECT @questionNumber = MAX(QuestionNumber) 
	FROM dbo.FormQuestion;

	SET @questionNumber = @questionNumber + 1;

	--Insert records to Form Question
	INSERT INTO [dbo].[FormQuestion](QuestionName, QuestionDescription, QuestionNumber,
								QuestionText,IsRequired, [Status], RevisionNo, AnswerControlType, DropDownIdentifier,
								CreatedDate, CreatedByStsId, LastModDate, LastModByStsId)
	VALUES(@questionText,@questionText,@questionNumber,@questionText,@isRequired,1,1,
			@answerControlType,@ddIdentifier,
			GETDATE(), @stsId, GETDATE(), @stsId);

	SELECT @questionId = FormQuestionID 
	FROM dbo.FormQuestion WHERE QuestionText = @questionText;

	SELECT ID,[value] INTO #temp1 
	FROM dbo.Split(@formId,'|') 
	WHERE VALUE <> '';

	SELECT ID,[value] INTO #temp2 
	FROM dbo.Split(@sectionId,'|') 
	WHERE VALUE <> '';

	--Insert records to Formsection table for RoleId 101
	INSERT INTO dbo.FormSection(FormID, FormQuestionID, SectionID, RoleID, PrivilegeID, 
							CreatedDate, CreatedBy, LastModDate, LastModBy, SecQuestionOrder)
	SELECT distinct f.[Value] as FormID, 
					@questionId, s.[Value] as SectionId, 
					101, 2, 
					GETDATE(),@stsId,
					GETDATE(),@stsId,
					MAX(fs.SecQuestionOrder) + 1
	FROM FormSection fs 
		INNER JOIN #temp1 f on f.Value = fs.FormID
		INNER JOIN #temp2 s on s.Value = fs.SectionID
		GROUP BY f.[Value], s.[Value];

	--Insert records to Formsection table for RoleId 100
	INSERT INTO dbo.FormSection(FormID, FormQuestionID, SectionID, RoleID, PrivilegeID, 
							CreatedDate, CreatedBy, LastModDate, LastModBy, SecQuestionOrder)
	SELECT distinct f.[Value] as FormID, 
					@questionId, s.[Value] as SectionId, 
					100, 2, 
					GETDATE(),@stsId,
					GETDATE(),@stsId,
					MAX(fs.SecQuestionOrder) + 1
	FROM FormSection fs 
		INNER JOIN #temp1 f on f.Value = fs.FormID
		INNER JOIN #temp2 s on s.Value = fs.SectionID
		GROUP BY f.[Value], s.[Value];

	DROP TABLE #temp1;
	DROP TABLE #temp2;
	
	SELECT @questionId;
END
GO


