/*    ==Scripting Parameters==

    Source Server Version : SQL Server 2012 (11.0.6020)
    Source Database Engine Edition : Microsoft SQL Server Enterprise Edition
    Source Database Engine Type : Standalone SQL Server

    Target Server Version : SQL Server 2012
    Target Database Engine Edition : Microsoft SQL Server Enterprise Edition
    Target Database Engine Type : Standalone SQL Server
*/

USE [BRT]
GO

/****** Object:  StoredProcedure [dbo].[qry_QuestionsGlobalCategory]    Script Date: 12/6/2017 2:20:23 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Rajesh Srigakolapu
-- Create date: 12/05/2017
-- Description:	qry_QuestionsGlobalCategory
-- exec [dbo].[qry_QuestionsGlobalCategory] 
-- =============================================
CREATE PROCEDURE [dbo].[qry_QuestionsGlobalCategory]
AS
BEGIN
	SELECT 
		FQ.FormQuestionID,
		QuestionText,
		FQ.DropDownIdentifier, 
		GSC.FormQuestionId, 
		ISNULL(GSC.Active, 0) as Active
	FROM dbo.FormQuestion FQ
	LEFT JOIN dbo.GlobalSearchCategory GSC 
		ON GSC.FormQuestionID = FQ.FormQuestionID
END
GO


