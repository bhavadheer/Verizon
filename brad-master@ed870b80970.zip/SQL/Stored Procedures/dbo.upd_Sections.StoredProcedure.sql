-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Rajesh Srigakolapu
-- Create date: 1/30/2018
-- Description:	Update sections
-- =============================================
CREATE PROCEDURE dbo.upd_Sections
	@sectionID INT,
	@sectionName VARCHAR(50), 
	@sectionDesc VARCHAR(300),
	@stsId INT
AS
BEGIN

	UPDATE dbo.Section
	SET  
		SectionName = @sectionName,
		SectionDescription = @sectionDesc,
		LastModDate = GETDATE(),
		LastModByStsId = @stsId
	WHERE SectionID = @sectionID;

END
GO
