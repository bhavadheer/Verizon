/*    ==Scripting Parameters==

    Source Server Version : SQL Server 2012 (11.0.3431)
    Source Database Engine Edition : Microsoft SQL Server Enterprise Edition
    Source Database Engine Type : Standalone SQL Server

    Target Server Version : SQL Server 2017
    Target Database Engine Edition : Microsoft SQL Server Standard Edition
    Target Database Engine Type : Standalone SQL Server
*/

USE [BRT]
GO
/****** Object:  StoredProcedure [dbo].[qry_FormsSearch]    Script Date: 2/20/2018 10:35:14 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
--- <author>Bharath Bellam</author>        
--- <date>03/02/2016</date>         
--- <summary>        
--- Description: Retrieve existing Forms records       
--- </summary>              
--- <revision>
---	03/21/2016 David Martinez  Added @formInstance parameter
---	03/23/2016 David Martinez  Added @creatorStsId parameter
---	03/25/2016 David Martinez  Added @showType parameter
--- <author>Rajesh Srigakolapu</author>        
--- <date>12/21/2017</date>         
--- <summary>        
--- Description: Added a new field Business Relationship as requested.
--- </summary>     
--- <author>Rajesh Srigakolapu</author>        
--- <date>2/20/2018</date>         
--- <summary>        
--- Description: Removed the date modification to add 5 hours..
--- </summary> 
--- </revision>
-- =============================================
--- exec [dbo].[qry_FormsSearch]  null, null,null, null, null, null, null, null,null,1398980
ALTER PROCEDURE [dbo].[qry_FormsSearch] 
	 @formId INT,            
     @currentReportStatus VARCHAR(500),-- int,
	 @formInstance VARCHAR(50),                 
	 @analystName VARCHAR(300),            
	 @dateFromCreated DATETIME,            
	 @dateToCreated DATETIME,
	 @showType INT = NULL,
	 @isUrgent VARCHAR(20) = NULL,
	 @currentReviewStatus VARCHAR(500),
	 @stsId INT           
AS
BEGIN

	DECLARE @showDelete INT = 0;

	IF EXISTS(SELECT * FROM dbo.PersonnelDeleteAbility WHERE STSId = @stsId)
	BEGIN
		SET @showDelete = 1;
	END

	--Company Legal Name
	SELECT 
		F.FormID, 
		F.Name,
		FS.FormsectionId,
		FS.SectionID,
		FR.FormInstance, 
		FR.AnswerText as LegalName,
		Ft.FormType,
		ft.AllowOverride,
		--CONVERT(VARCHAR(19),convert(datetime, dateadd(hour,5,ft.CreatedDate),101)) as CreateDate, 
		ft.CreatedDate AS CreateDate,
		CONVERT(DATE,ft.CreatedDate,126) as MonthYear, ft.FormType as FTID, 
		--CAST(CONVERT(VARCHAR(19),convert(datetime, dateadd(hour,5,ft.CreatedDate),101)) as datetime) as CreateDate1,
		ft.CreatedDate AS CreateDate1,
		ft.IsActive INTO #temp1
	FROM dbo.FormResponse FR
	INNER JOIN dbo.FormSection FS ON FS.FormSectionID = FR.FormSectionID
	INNER JOIN dbo.Form F ON FS.FormID = F.FormID
	INNER JOIN dbo.FormInstanceType FT ON FR.FormInstance = FT.FormInstance
	WHERE FS.FormQuestionID IN (15);

	--Current Report Status
	SELECT 
		F.FormID, 
		FR.FormInstance, 
		CASE WHEN AnswerText = '' THEN AnswerText ELSE dbo.userTranslateDropDownData(AnswerText) END as CurrentReportStatus
		INTO #temp2
	FROM dbo.FormResponse FR
	INNER JOIN dbo.FormSection FS ON FS.FormSectionID = FR.FormSectionID
	INNER JOIN dbo.Form F ON FS.FormID = F.FormID
	INNER JOIN dbo.FormInstanceType FT ON FR.FormInstance = FT.FormInstance
	INNER JOIN dbo.Personnel p on p.StsId = FT.CreatedByStsId
	WHERE FS.FormQuestionID IN (442);

	--Analyst Name
	SELECT 
		F.FormID, 
		FR.FormInstance, 
		CASE WHEN AnswerText = '' THEN AnswerText ELSE dbo.userTranslateDropDownDataForAnalysts(AnswerText) END as AnalystName,
		AnswerText as AnalystID
		INTO #temp3
	FROM dbo.FormResponse FR
	INNER JOIN dbo.FormSection FS ON FS.FormSectionID = FR.FormSectionID
	INNER JOIN dbo.Form F ON FS.FormID = F.FormID
	INNER JOIN dbo.FormInstanceType FT ON FR.FormInstance = FT.FormInstance
	INNER JOIN dbo.Personnel p on p.StsId = FT.CreatedByStsId
	WHERE FS.FormQuestionID IN (323) AND FS.SectionID = 16;

	-- Vendor Type
	SELECT 
		FR.FormInstance, 
		CASE WHEN AnswerText = '' THEN AnswerText ELSE dbo.userTranslateDropDownData(AnswerText) END as VendorType
		INTO #temp4
	FROM dbo.FormResponse FR
	INNER JOIN dbo.FormSection FS ON FS.FormSectionID = FR.FormSectionID
	INNER JOIN dbo.Form F ON FS.FormID = F.FormID
	INNER JOIN dbo.FormInstanceType FT ON FR.FormInstance = FT.FormInstance
	INNER JOIN dbo.Personnel p on p.StsId = FT.CreatedByStsId
	WHERE FS.FormQuestionID = 545;

	--Mark if Urgent - 435
	SELECT 
		FR.FormInstance, 
		CASE WHEN AnswerText = '' THEN AnswerText ELSE dbo.userTranslateDropDownData(AnswerText) END as MarkIfUrgent
		INTO #temp5
	FROM dbo.FormResponse FR
	INNER JOIN dbo.FormSection FS ON FS.FormSectionID = FR.FormSectionID
	INNER JOIN dbo.Form F ON FS.FormID = F.FormID
	INNER JOIN dbo.FormInstanceType FT ON FR.FormInstance = FT.FormInstance
	INNER JOIN dbo.Personnel p on p.StsId = FT.CreatedByStsId
	WHERE FS.FormQuestionID = 435;

	--Current Review Status
	SELECT 
		F.FormID, 
		FR.FormInstance, 
		CASE WHEN AnswerText = '' THEN AnswerText ELSE dbo.userTranslateDropDownData(AnswerText) END as CurrentReviewStatus
		INTO #temp7
	FROM dbo.FormResponse FR
	INNER JOIN dbo.FormSection FS ON FS.FormSectionID = FR.FormSectionID
	INNER JOIN dbo.Form F ON FS.FormID = F.FormID
	INNER JOIN dbo.FormInstanceType FT ON FR.FormInstance = FT.FormInstance
	INNER JOIN dbo.Personnel p on p.StsId = FT.CreatedByStsId
	WHERE FS.FormQuestionID IN (443) AND FS.SectionID = 34;

	--TIER
	SELECT 
		F.FormID, 
		FR.FormInstance, 
		CASE WHEN AnswerText = '' THEN AnswerText ELSE dbo.userTranslateDropDownData(AnswerText) END as Tier
		INTO #temp8
	FROM dbo.FormResponse FR
	INNER JOIN dbo.FormSection FS ON FS.FormSectionID = FR.FormSectionID
	INNER JOIN dbo.Form F ON FS.FormID = F.FormID
	INNER JOIN dbo.FormInstanceType FT ON FR.FormInstance = FT.FormInstance
	INNER JOIN dbo.Personnel p on p.StsId = FT.CreatedByStsId
	WHERE Fs.FormQuestionID IN (434) AND FS.SectionID = 28;

	--Notes
	SELECT 
		F.FormID, 
		FR.FormInstance, 
		FR.AnswerText as Notes
		INTO #temp9
	FROM dbo.FormResponse FR
	INNER JOIN dbo.FormSection FS ON FS.FormSectionID = FR.FormSectionID
	INNER JOIN dbo.Section S ON S.SectionID = FS.SectionID
	INNER JOIN dbo.Form F ON FS.FormID = F.FormID
	INNER JOIN dbo.FormQuestion FQ ON FQ.FormQuestionID = FS.FormQuestionID
	INNER JOIN dbo.FormInstanceType FT ON FR.FormInstance = FT.FormInstance
	INNER JOIN dbo.Personnel p on p.StsId = FT.CreatedByStsId
	WHERE FQ.FormQuestionID = 429 AND FS.SectionID = 28;

	
	IF @showDelete = 0
	BEGIN
		SELECT 
			t1.FormID as ID
			,t1.LegalName
			,t1.FormInstance
			,t1.[Name]
			--,Person
			,t1.CreateDate
			,CASE t1.FormType 
					  WHEN 0 THEN 'Manual' 
					  WHEN 1 THEN 'Manual'  
					  WHEN 2 THEN 'Imported' 
					  ELSE 'None' 
					END as FIType
			,t2.CurrentReportStatus
			,t1.FTID
			,@showDelete ShowDelete
			,t1.IsActive
			,t1.MonthYear
			,t1.FormsectionId
			,t1.FormType
			,t3.AnalystName
			,t4.VendorType
			,t5.MarkIfUrgent
			,t3.AnalystID
			,t8.Tier
			,t1.AllowOverride
			,t9.Notes
		FROM #temp1 t1
		LEFT JOIN #temp2 t2 ON t2.FormInstance = t1.FormInstance
		LEFT JOIN #temp3 t3 ON t3.FormInstance = t1.FormInstance
		LEFT JOIN #temp4 t4 ON t4.FormInstance = t1.FormInstance
		LEFT JOIN #temp5 t5 ON t5.FormInstance = t1.FormInstance
		LEFT JOIN #temp7 t7 ON t7.FormInstance = t1.FormInstance
		LEFT JOIN #temp8 t8 ON t8.FormInstance = t1.FormInstance
		LEFT JOIN #temp9 t9 ON t9.FormInstance = t1.FormInstance
		WHERE 
		(@formId IS NULL OR t1.FormID = @formId OR @formId = 0)
		AND (@currentReportStatus IS NULL OR t2.CurrentReportStatus = @currentReportStatus)
		AND (@formInstance IS NULL OR t1.FormInstance like @formInstance + '%')
		AND((ISNULL(@dateFromCreated, '') <> '' AND t1.CreateDate >= @dateFromCreated) OR (ISNULL(@dateFromCreated, '') = ''))
		AND((ISNULL(@dateToCreated, '') <> '' AND t1.CreateDate <= (@dateToCreated + 1) ) OR (ISNULL(@dateToCreated, '') = ''))
		AND (@analystName IS NULL OR t3.AnalystName = @analystName) 
		AND (@showType IS NULL OR t1.FormType = @showType)
		AND (@isUrgent IS NULL OR t5.MarkIfUrgent = @isUrgent)
		AND (@currentReviewStatus IS NULL OR t7.CurrentReviewStatus = @currentReviewStatus)
		AND t1.IsActive = 1
		ORDER BY t1.CreateDate1 DESC
	END
	ELSE
	BEGIN
		SELECT 
			t1.FormID AS ID
			,t1.LegalName
			,t1.FormInstance
			,t1.[Name]
			--,Person
			,t1.CreateDate
			,CASE t1.FormType 
					  WHEN 0 THEN 'Manual' 
					  WHEN 1 THEN 'Manual'  
					  WHEN 2 THEN 'Imported' 
					  ELSE 'None' 
					END AS FIType
			,t2.CurrentReportStatus
			,t1.FTID
			,@showDelete ShowDelete
			,t1.IsActive
			,t1.MonthYear
			,t1.FormsectionId
			,t1.FormType
			,t3.AnalystName
			,t4.VendorType
			,t5.MarkIfUrgent
			,t3.AnalystID
			,t8.[Tier]
			,t1.AllowOverride
			,t9.Notes
		FROM #temp1 t1
		LEFT JOIN #temp2 t2 ON t2.FormInstance = t1.FormInstance
		LEFT JOIN #temp3 t3 ON t3.FormInstance = t1.FormInstance
		LEFT JOIN #temp4 t4 ON t4.FormInstance = t1.FormInstance
		LEFT JOIN #temp5 t5 ON t5.FormInstance = t1.FormInstance
		LEFT JOIN #temp7 t7 ON t7.FormInstance = t1.FormInstance
		LEFT JOIN #temp8 t8 ON t8.FormInstance = t1.FormInstance
		LEFT JOIN #temp9 t9 ON t9.FormInstance = t1.FormInstance
		WHERE 
		(@formId IS NULL OR t1.FormID = @formId OR @formId = 0)
		AND (@currentReportStatus IS NULL OR t2.CurrentReportStatus = @currentReportStatus)
		AND (@formInstance IS NULL OR t1.FormInstance LIKE @formInstance + '%')
		AND((ISNULL(@dateFromCreated, '') <> '' AND t1.CreateDate >= @dateFromCreated) OR (ISNULL(@dateFromCreated, '') = ''))
		AND((ISNULL(@dateToCreated, '') <> '' AND t1.CreateDate <= (@dateToCreated + 1) ) OR (ISNULL(@dateToCreated, '') = ''))
		AND (@analystName IS NULL OR t3.AnalystName = @analystName) 
		AND (@showType IS NULL OR t1.FormType = @showType)
		AND (@isUrgent IS NULL OR t5.MarkIfUrgent = @isUrgent)
		AND (@currentReviewStatus IS NULL OR t7.CurrentReviewStatus = @currentReviewStatus)
		ORDER BY t1.CreateDate1 DESC
	END

	DROP TABLE #temp9;
	DROP TABLE #temp8;
	DROP TABLE #temp7;
	DROP TABLE #temp5;
	DROP TABLE #temp4;
	DROP TABLE #temp3;
	DROP TABLE #temp2;
	DROP TABLE #temp1;
END
