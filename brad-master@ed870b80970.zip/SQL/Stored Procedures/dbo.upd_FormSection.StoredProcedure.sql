/*    ==Scripting Parameters==

    Source Server Version : SQL Server 2012 (11.0.6020)
    Source Database Engine Edition : Microsoft SQL Server Enterprise Edition
    Source Database Engine Type : Standalone SQL Server

    Target Server Version : SQL Server 2017
    Target Database Engine Edition : Microsoft SQL Server Standard Edition
    Target Database Engine Type : Standalone SQL Server
*/

USE [BRT]
GO
/****** Object:  StoredProcedure [dbo].[upd_FormQuestions]    Script Date: 2/1/2018 8:35:42 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Rajesh Srigakolapu
-- Create date: 10/19/2017
-- Description:	Update form Questions
-- =============================================
-- EXEC [dbo].[upd_FormQuestions] 1,'',1

CREATE PROCEDURE [dbo].[upd_FormSection]
	@formSectionId INT,
	--@formId INT,
	--@formquestionId INT,
	--@oldSectionId INT,
	@newSectionID INT,
	@stsId INT
AS
BEGIN

	UPDATE dbo.FormSection SET	
		SectionID = @newSectionID,
		LastModBy = @stsId,
		LastModDate = GETDATE()
	WHERE
		FormSectionID = @formSectionId;
	--AND	FormId = @formId
	--AND	SectionID = @oldSectionId
	--AND	FormQuestionID = @formquestionId

END
