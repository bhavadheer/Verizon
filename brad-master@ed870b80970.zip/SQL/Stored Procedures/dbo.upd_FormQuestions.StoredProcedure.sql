/*    ==Scripting Parameters==

    Source Server Version : SQL Server 2012 (11.0.6020)
    Source Database Engine Edition : Microsoft SQL Server Enterprise Edition
    Source Database Engine Type : Standalone SQL Server

    Target Server Version : SQL Server 2017
    Target Database Engine Edition : Microsoft SQL Server Standard Edition
    Target Database Engine Type : Standalone SQL Server
*/

USE [BRT]
GO
/****** Object:  StoredProcedure [dbo].[qry_FormQuestionsBySectionId]    Script Date: 10/20/2017 9:20:08 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Rajesh Srigakolapu
-- Create date: 10/19/2017
-- Description:	Update form Questions
-- =============================================
-- EXEC [dbo].[upd_FormQuestions] 1,'',1

CREATE PROCEDURE [dbo].[upd_FormQuestions] 
	@formquestionId INT,
	@questionText VARCHAR(MAX),
	@isRequired INT,
	@stsId INT
AS
BEGIN

	UPDATE dbo.FormQuestion
	SET QuestionText = @questionText,
		QuestionDescription = @questionText,
		QuestionName = @questionText,
		IsRequired = @isRequired,
		LastModDate = GETDATE(),
		LastModByStsId = @stsId
	WHERE FormQuestionID = @formquestionId;

END
