USE [BRT]
GO
/****** Object:  StoredProcedure [dbo].[qry_GetLinkedForms]    Script Date: 9/22/2017 11:14:57 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- <author>Rajesh Srigakolapu</author>
-- <date>9/22/2017</date>  
-- <calling applications>ABC</calling applications>
-- <revisions> 
-- </revisions>  
-- ==============================================
CREATE PROCEDURE [dbo].[qry_GetBRTAnalystInfo]
@logonId VARCHAR(20)
AS
BEGIN
	
	SELECT LogonId, Email, WorkPhone
	FROM dbo.Personnel P 
	WHERE P.LogonId = @logonId;
	
END
