﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Reflection;

namespace Common
{
    public enum YesNoNA
    {
        NotSet,
        Yes,
        No,
        NotApplicable
    }

    public enum BusinessRelationshipType
    {
        NotSet,
        Customer,
        Vendor,
        Other
    }

    public enum VentureType
    {
        [DescriptionAttribute("Please Select")]
        NotSet,

        [DescriptionAttribute("One-off")]
        Oneoff,

        [DescriptionAttribute("On-going")]
        Ongoing
    }

    public enum POCKnownToRequestorStatus
    {
        [DescriptionAttribute("Please Select")]
        NotSet,

        [DescriptionAttribute("NO")]
        No,

        [DescriptionAttribute("YES- Business Relationship")]
        YesB,

        [DescriptionAttribute("YES - Personal Relationship")]
        YesP
    }

    public enum MKDenialType
    {
        [DescriptionAttribute("Please Select")]
        NotSet,

        [DescriptionAttribute("On list - Reject")]
        OnList,

        [DescriptionAttribute("Not on list - Pass")]
        NotOnList
    }

    public enum ContractTermType
    {
        [DescriptionAttribute("Please Select")]
        NotSet,

        [DescriptionAttribute("PO Terms")]
        PoTerms,

        [DescriptionAttribute("Verizon Terms")]
        VerizonTerms,

        [DescriptionAttribute("Supplier Terms")]
        SupplierTerms
    }

    public enum PaymentTerm
    {
        [DescriptionAttribute("Please Select")]
        NotSet,

        [DescriptionAttribute("30 Days")]
        ThirtyDays,

        [DescriptionAttribute("45 Days")]
        ForthyFiveDays,

        [DescriptionAttribute("60 Days")]
        SixtyDays,

        [DescriptionAttribute("90 Days")]
        NinetyDays
    }

    public enum BusinessDecisionType
    {
        [DescriptionAttribute("Please Select")]
        NotSet,

        [DescriptionAttribute("Accept Venodr/Customer/Individual")]
        Accept,

        [DescriptionAttribute("Reject Venodr/Customer/Individual")]
        Reject
    }

    public enum CategoryLevel1
    {
        [DescriptionAttribute("Please Select")]
        NotSet,

        [DescriptionAttribute("HR")]
        HR,

        [DescriptionAttribute("IT")]
        IT,

        [DescriptionAttribute("Marketing")]
        Marketing,

        [DescriptionAttribute("Networks")]
        Networks,

        [DescriptionAttribute("Professional Services")]
        ProfessionalServices
    }

    public enum CategoryLevel2
    {
        [DescriptionAttribute("Please Select")]
        NotSet,

        [DescriptionAttribute("Advertising & Media")]
        AdvertisingMedia,

        [DescriptionAttribute("Benefits")]
        Benefits,

        [DescriptionAttribute("BPO")]
        BPO,

        [DescriptionAttribute("Data Centres")]
        DataCentres,

        [DescriptionAttribute("Employee Expenses")]
        EmployeeExpenses,

        [DescriptionAttribute("Employee Services")]
        EmployeeServices,

        [DescriptionAttribute("Finance")]
        Finance,

        [DescriptionAttribute("FM & RE Operations")]
        FmReOperations,

        [DescriptionAttribute("General HR")]
        GeneralHR,

        [DescriptionAttribute("Government")]
        Government,

        [DescriptionAttribute("Hardware")]
        Hardware,

        [DescriptionAttribute("Insurance")]
        Insurance,

        [DescriptionAttribute("Learning & Development")]
        LearningDevelopment,

        [DescriptionAttribute("Legal")]
        Legal,

        [DescriptionAttribute("Logistics")]
        Logistics,

        [DescriptionAttribute("Management Consulting")]
        ManagementConsulting,

        [DescriptionAttribute("Market Research")]
        MarketResearch,

        [DescriptionAttribute("Other PS")]
        OtherPS,

        [DescriptionAttribute("Printing")]
        Printing,

        [DescriptionAttribute("Promotional & Sponsership Services")]
        PromotionalSponsershipServices,

        [DescriptionAttribute("Resourcing")]
        Resourcing,

        [DescriptionAttribute("Security")]
        Security,

        [DescriptionAttribute("Services")]
        Services,

        [DescriptionAttribute("Software")]
        Software,

        [DescriptionAttribute("Technical Consulting")]
        TechnicalConsulting,

        [DescriptionAttribute("Technical Facilities")]
        TechnicalFacilities,

        [DescriptionAttribute("Telco")]
        Telco,

        [DescriptionAttribute("VSAT")]
        VSAT
    }

    public enum CategoryLevel3
    {
        [DescriptionAttribute("Please Select")]
        NotSet,

        [DescriptionAttribute("3PL")]
        ThreePL,

        [DescriptionAttribute("Accounting Services")]
        AccountingServices,

        [DescriptionAttribute("Ancillary Materials")]
        AncillaryMaterials,

        [DescriptionAttribute("Application Software")]
        ApplicationSoftware,

        [DescriptionAttribute("Batch")]
        Batch,

        [DescriptionAttribute("Benefits Administration")]
        BenefitsAdministration,
        
        [DescriptionAttribute("Benefits Consulting")]
        BenefitsConsulting,

        [DescriptionAttribute("Building Services")]
        BuildingServices,

        [DescriptionAttribute("Bulk")]
        Bulk,

        [DescriptionAttribute("Cables & Fibre")]
        CablesFibre,

        [DescriptionAttribute("Consumables")]
        Consumables,

        [DescriptionAttribute("Corporate Cards")]
        CorporateCards,

        [DescriptionAttribute("Couriers")]
        Couriers,

        [DescriptionAttribute("CPE")]
        CPE,

        [DescriptionAttribute("Creative")]
        Creative,

        [DescriptionAttribute("Credit & Collections")]
        CreditCollections,

        [DescriptionAttribute("Customs")]
        Customs,

        [DescriptionAttribute("Data Centres & Cloud")]
        DataCentresCloud,

        [DescriptionAttribute("Desktop & IT")]
        DesktopIT,

        [DescriptionAttribute("Energy & Utilities")]
        EnergyUtilities,

        [DescriptionAttribute("Engineering")]
        Engineering,

        [DescriptionAttribute("Field Marketing")]
        FieldMarketing,

        [DescriptionAttribute("Finance Consulting")]
        FinanceConsulting,

        [DescriptionAttribute("Fleet")]
        Fleet,

        [DescriptionAttribute("Freight Forwarding")]
        FrieghtForwarding,

        [DescriptionAttribute("General")]
        General,
        
        [DescriptionAttribute("Government/tax & Licenses")]
        GovernmenttaxLicenses,
        
        [DescriptionAttribute("Health")]
        Health,
        
        [DescriptionAttribute("HSE")]
        Hse,
        
        [DescriptionAttribute("HVAC")]
        Hvac,
        
        [DescriptionAttribute("Indirect Sales")]
        IndirectSales,
        
        [DescriptionAttribute("Infrastructure")]
        Infrastructure,
        
        [DescriptionAttribute("Installation & Maintenance")]
        InstallationMaintenance,
        
        [DescriptionAttribute("Internal Events")]
        InternalEvents,
        
        [DescriptionAttribute("IT")]
        It,
        
        [DescriptionAttribute("Managed Services")]
        ManagedServices,
        
        [DescriptionAttribute("Management Training")]
        ManagementTraining,
        
        [DescriptionAttribute("Memberships & Subscriptions")]
        MembershipsSubscriptions,
        
        [DescriptionAttribute("Mobile Telecoms")]
        MobileTelecoms,
        
        [DescriptionAttribute("Multi Service")]
        MultiService,
        
        [DescriptionAttribute("Networks")]
        Networks,
        
        [DescriptionAttribute("Office Services")]
        OfficeServices,
        
        [DescriptionAttribute("Other")]
        Other,
        
        [DescriptionAttribute("Other PS")]
        OtherPs,
        
        [DescriptionAttribute("Payroll")]
        Payroll,
        
        [DescriptionAttribute("Permanent")]
        Permanent,
        
        [DescriptionAttribute("Postal Services")]
        PostalServices,
        
        [DescriptionAttribute("Power")]
        Power,
        
        [DescriptionAttribute("PR")]
        Pr,
        
        [DescriptionAttribute("Real Estate")]
        RealEstate,
        
        [DescriptionAttribute("Repair & Maint' (Infrastructure)")]
        RepairMaintInfrastructure,
        
        [DescriptionAttribute("Reprographics")]
        Reprographics,
        
        [DescriptionAttribute("Risk Mngmnt")]
        RiskMngmnt,
        
        [DescriptionAttribute("Security")]
        Security,
        
        [DescriptionAttribute("Security Equipment")]
        SecurityEquipment,
        
        [DescriptionAttribute("Security Services")]
        SecurityServices,
        
        [DescriptionAttribute("Services")]
        Services,
        
        [DescriptionAttribute("Subscriptions")]
        Subscriptions,
        
        [DescriptionAttribute("Support & Maintenance")]
        SupportMaintenance,
        
        [DescriptionAttribute("Tax & Audit Services")]
        TaxAuditServices,
        
        [DescriptionAttribute("Technical Training")]
        TechnicalTraining,
        
        [DescriptionAttribute("Temporary Labour")]
        TemporaryLabor,
        
        [DescriptionAttribute("Test Equipment")]
        TestEquipment,
        
        [DescriptionAttribute("Third Party Co-Location")]
        ThirdPartyCoLocation,
        
        [DescriptionAttribute("Translation Services")]
        TranslationServices,
        
        [DescriptionAttribute("Travel")]
        Travel,
        
        [DescriptionAttribute("VOIP")]
        Voip,
        
        [DescriptionAttribute("Warehousing")]
        Warehousing,
        
        [DescriptionAttribute("WEEE Disposal & Recycling")]
        WeeeDisposalRecycling,
        
        [DescriptionAttribute("X-FM")]
        Xfm
    }

    public enum CategoryLevel4
    {
        [DescriptionAttribute("Please Select")]
        NotSet,

        [DescriptionAttribute("A/V")]
        Av,

        [DescriptionAttribute("Agency")]
        Agency,
        
        [DescriptionAttribute("Airlines")]
        Airlines,
        
        [DescriptionAttribute("Ancillary Services")]
        AncillaryServices,
        
        [DescriptionAttribute("Ancillary Services & Installations")]
        AncillaryServicesInstallation,
        
        [DescriptionAttribute("Back Office")]
        BackOffice,
        
        [DescriptionAttribute("Building RM & Fit outs")]
        BuildingRmFitouts,
        
        [DescriptionAttribute("Cables & Fibre")]
        CablesFibre,
        
        [DescriptionAttribute("Car Hire")]
        CarHire,
        
        [DescriptionAttribute("Car Lease")]
        CarLease,
        
        [DescriptionAttribute("Catering")]
        Catering,
        
        [DescriptionAttribute("Channel VAD/VAR")]
        ChannelVadVar,
        
        [DescriptionAttribute("Cleaning")]
        Cleaning,

        [DescriptionAttribute("Construction")]
        Construction,

        [DescriptionAttribute("Consultancy / Audit")]
        ConsultancyAudit,
        
        [DescriptionAttribute("Control Systems")]
        ControlSystems,
        
        [DescriptionAttribute("CPE")]
        Cpe,
        
        [DescriptionAttribute("Design Consultancy")]
        DesignConsultancy,
        
        [DescriptionAttribute("Distributer/Reseller")]
        DistributerReseller,
        
        [DescriptionAttribute("DRUPS")]
        Drups,
        
        [DescriptionAttribute("Electricity & Gas")]
        ElectricityGas,
        
        [DescriptionAttribute("Energy Sourcing")]
        EnergySourcing,
        
        [DescriptionAttribute("Equipment")]
        Equipment,
        
        [DescriptionAttribute("Fire Protection Systems")]
        FireProtectionSystems,
        
        [DescriptionAttribute("Fleet Mgmt")]
        FleetMgmt,
        
        [DescriptionAttribute("Fuel Card")]
        FuelCard,
        
        [DescriptionAttribute("Furniture")]
        Furniture,
        
        [DescriptionAttribute("Generator Fuel")]
        GeneratorFuel,
        
        [DescriptionAttribute("Generators")]
        Generators,
        
        [DescriptionAttribute("Grounds Mtnce")]
        GroundsMtnce,
        
        [DescriptionAttribute("Hotels")]
        Hotels,

        [DescriptionAttribute("Installation & Maintenance")]
        InstallationMaintenance,
        
        [DescriptionAttribute("Lifts")]
        Lifts,
        
        [DescriptionAttribute("M&E")]
        ME,
        
        [DescriptionAttribute("Mailroom")]
        Mailroom,
        
        [DescriptionAttribute("Managed Services")]
        ManagedServices,
        
        [DescriptionAttribute("Manufacturer/OEM")]
        ManufacturerOem,
        
        [DescriptionAttribute("Misc. Fleet")]
        MiscFleet,
        
        [DescriptionAttribute("Misc. Travel")]
        MiscTravel,
        
        [DescriptionAttribute("Multi Functional Devices (MFD)")]
        MultiFuctionalDevices,
        
        [DescriptionAttribute("Occupational Health")]
        OccupationalHealth,
        
        [DescriptionAttribute("Office Planning & Moves")]
        OfficePlaningMoves,
        
        [DescriptionAttribute("Office Supplies")]
        OfficeSupplies,
        
        [DescriptionAttribute("Parking")]
        Parking,
        
        [DescriptionAttribute("PBX Maintenance")]
        PbxMaintenance,
        
        [DescriptionAttribute("Pest Control")]
        PestControl,
        
        [DescriptionAttribute("PowerDistibution")]
        PowerDistribution,
        
        [DescriptionAttribute("R&M")]
        RM,
        
        [DescriptionAttribute("Rail")]
        Rail,
        
        [DescriptionAttribute("Reception")]
        Reception,
        
        [DescriptionAttribute("Records Mgmt")]
        RecordsMgmt,
        
        [DescriptionAttribute("Regulatory Controls")]
        RegulatoryControls,
        
        [DescriptionAttribute("Rents & Rates")]
        RentsRates,
        
        [DescriptionAttribute("Taxi")]
        Taxi,
        
        [DescriptionAttribute("TMC")]
        Tmc,
        
        [DescriptionAttribute("Transformers Batteries")]
        TransformersBatteries,
        
        [DescriptionAttribute("UPS")]
        Ups,
        
        [DescriptionAttribute("Waste Management")]
        WasteManagement,
        
        [DescriptionAttribute("Water")]
        Water
    }

    public enum TypeOfCheck
    {
        [DescriptionAttribute("Please Select")]
        NotSet,

        [DescriptionAttribute("Basic")]
        Basic,

        [DescriptionAttribute("Comprehensive")]
        Comprehensive
    }

    public enum MainEntityCheck
    {
        [DescriptionAttribute("Please Select")]
        NotSet,

        [DescriptionAttribute("Not Done")]
        NotDone,

        [DescriptionAttribute("Complete")]
        Complete,

        [DescriptionAttribute("Not Available")]
        NotAvailable
    }

    public enum MainEntityCheck2
    {
        [DescriptionAttribute("Please Select")]
        NotSet,

        [DescriptionAttribute("Not Done")]
        NotDone,

        [DescriptionAttribute("Complete")]
        Complete
    }

    public enum NameTypes
    {
        [DescriptionAttribute("Please Select")]
        NotSet,

        [DescriptionAttribute("Chris Sharp (ABC-BRT Team Leader)")]
        ChrisSharp,

        [DescriptionAttribute("Nigel Millson-Crane (Head of Inv Intelligence)")]
        NigelMillson
    }
    
    public enum OverallRiskTypes
    {
        [DescriptionAttribute("Please Select")]
        NotSet,

        [DescriptionAttribute("Overall risk level - High")]
        OverallRiskLevelHigh,

        [DescriptionAttribute("Overall risk level - Low")]
        OverallRiskLevelLow
    }

    public enum EnvType
    {
        NotSet,
        Production,
        Dev,
        Test,
        Staging,
        BCP
    }

    public enum IsImported: int
    {
        No  = 0,
        Yes = 1
    }

    public enum InstanceType : int
    {
        Draft = 0,
        Submitted = 1,
        Imported = 2
    }
    
    public static class EnumDisplay
    {
    }

}
