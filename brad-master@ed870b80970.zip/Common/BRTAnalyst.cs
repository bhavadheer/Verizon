﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    [Serializable]
    public class BRTAnalyst
    {
        public string LogonId { get; set; }
        public string Email { get; set; }
        public string WorkPhone { get; set; }
    }
}
