﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common
{
    [Serializable]
    public class MyPortalExpandCollapse
    {
        #region " Private Variables "

        private string _section1;
        private string _section2;
        private string _vendorPOC1;
        private string _vendorPOC2;
        private string _section3;
        private string _section4;
        private string _section5;
        private string _section6;
        private string _section7;
        private string _section8;
        private string _keepSession;

        #endregion

        #region " Public Variables "

        public string KeepSession
        {
            get
            {
                return this._keepSession;
            }
            set
            {
                this._keepSession = value;

            }
        }

        public string Section1
        {
            get
            {
                return this._section1;
            }
            set
            {
                this._section1 = value;

            }
        }
        public string Section2
        {
            get
            {
                return this._section2;
            }
            set
            {
                this._section2 = value;

            }
        }
        public string VendorPOC1
        {
            get
            {
                return this._vendorPOC1;
            }
            set
            {
                this._vendorPOC1 = value;

            }
        }
        public string VendorPOC2
        {
            get
            {
                return this._vendorPOC2;
            }
            set
            {
                this._vendorPOC2 = value;

            }
        }
        public string section3
        {
            get
            {
                return this._section3;
            }
            set
            {
                this._section3 = value;

            }
        }
        public string Section4
        {
            get
            {
                return this._section4;
            }
            set
            {
                this._section4 = value;

            }
        }
        public string Section5
        {
            get
            {
                return this._section5;
            }
            set
            {
                this._section5 = value;

            }
        }
        public string Section6
        {
            get
            {
                return this._section6;
            }
            set
            {
                this._section6 = value;

            }
        }
        public string Section7
        {
            get
            {
                return this._section7;
            }
            set
            {
                this._section7 = value;

            }
        }
        public string Section8
        {
            get
            {
                return this._section8;
            }
            set
            {
                this._section8 = value;

            }
        }
        #endregion
    }
}
