﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    [Serializable]
    public class UserFormPartial
    {
        public int FormId { get; set; }
        public int FormQuestionId { get; set; }
        public int SectionId { get; set; }
        public int FormSectionId { get; set; }
        public string QuestionText { get; set; }
        public string DropdownIdentifier { get; set; }
        public string AnsCtrlType { get; set; }
        public string DDOptions { get; set; }

        public bool IsRequired { get; set; }
    }
}
