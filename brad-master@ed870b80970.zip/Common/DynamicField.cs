﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Common
{
    public enum DynControlType
    {
        Notset = 0,
        Button = 1,
        CheckBox = 4,
        DatePicker = 5,
        DropDown = 6,
        Radio = 823,
        TextBox = 3,
        FormNumber = 883,
        Attachment = 7,
        LinkedForms = 892
    }

    public enum DynCheckBoxType
    {
        Notset = 0,
        Check1,
        Check2,
        Check3
    }

    public enum DynButtonType
    {
        Notset = 0,
        CompanyRegistrationAttachment
    }

    public enum DynDropDownType
    {
        Notset = 0,
        BusinessRelationship,
        VendorInteraction
    }

    public enum DynRadioButtonType
    {
        Notset = 0,
        Radio1,
        Radio2,
        Radio3
    }

    public enum AttachmentIdentifier
    {
        FormLevel = 0,
        SectionLevel = 1,
        QuestionLevel = 2
    }

    public enum DynDataType
    {
        Numeric = 1,
        Email = 2,
        Text = 3
    }

    [Serializable]
    public class DynamicField : BaseClass
    {
        private bool disposed = false;

        public string Id { get; set; }
        public Int32 Sec { get; set; }
        public Int32 Form { get; set; }
        public String FieldName { get; set; }
        public String Text { get; set; }
        public int QuestionNumber { get; set; }
        public DynControlType CtrlType { get; set; }
        public DynButtonType BtnType { get; set; }
        public DynCheckBoxType CbType { get; set; }
        public string DdType { get; set; }
        public DynRadioButtonType RbType { get; set; }
        public Object FieldData { get; set; }
        public bool IsReadonly { get; set; }
        public bool IsRequired { get; set; }
        public String FormInstance { get; set; }

        public static T GetDynEnumTypeFromString<T>(string input, T defaultvalue) where T : struct
        {
            T result;
            if (Enum.TryParse<T>(input, out result))
            {
                if (IsFlagged<T>())
                {
                    if (Convert.ToInt32(result) < GetEnumSum<T>())
                    {
                        return result;
                    }
                }
                else
                {
                    if (Enum.IsDefined(typeof(T), result))
                    {
                        return result;
                    }
                }
            }

            return defaultvalue;
        }

        public static bool IsFlagged<T>()
        {
            return typeof(T).IsDefined(typeof(FlagsAttribute), false);
        }

        public static T GetEnumMax<T>() where T : struct
        {
            return (T)Enum.ToObject(typeof(T), Enum.GetValues(typeof(T)).Cast<int>().Last());
        }

        public static int GetEnumSum<T>() where T : struct
        {
            return (int)Enum.ToObject(typeof(T), Enum.GetValues(typeof(T)).Cast<int>().Sum());
        }

        protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            if (disposing)
            {
                //dispose the object
            }
            disposed = true;
            base.Dispose(disposing);
        }
    }
}