﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common
{
    [Serializable]
    public class Attachment
    {
        #region " Private Variables "

        private int _attachmentId;
        private int _formSectionId;
        private int _formId;
        private string _attachmentName;
        private Byte[] _attachment;

        #endregion

        #region " Public Variables "

        public int AttachmentId
        {
            get { return this._attachmentId; }
            set { this._attachmentId = value; }
        }

        public int FormId
        {
            get { return this._formId; }
            set { this._formId = value; }
        }

        public int FormSectionId
        {
            get { return this._formSectionId; }
            set { this._formSectionId = value; }
        }

        public string AttachmentName
        {
            get { return this._attachmentName; }
            set { this._attachmentName = value; }
        }

        public Byte[] AttachmentStream
        {
            get { return this._attachment; }
            set { this._attachment = value; }
        }

        #endregion
    }

    #region " Exception Handler Class"

    public class ABCException
    {
        public int StsId { get; set; }
        public string Name { get; set; }
        public string MethodName { get; set; }
        public string SpName { get; set; }
        public string PageName { get; set; }
        public string FormInstance { get; set; }
        public string SectionName { get; set; }
        //public string FormInstance { get; set; }

        public static string GetMoreInfoForException(ABCException exMessage)
        {
            var msg = "";

            msg += " Logged-in Person Stsid: " + exMessage.StsId;
            msg += " \n\r Logged-in Person Name: " + exMessage.Name;
            msg += " \n\r Method Name: " + exMessage.MethodName;
            if (exMessage.SpName != "")
            {
                msg += " \n\r Stored Procedure Name: " + exMessage.SpName;
            }
            if (exMessage.FormInstance != "")
            {
                msg += " \n\r Form Instance: " + exMessage.FormInstance;
            }
            if (exMessage.SectionName != "")
            {
                msg += " \n\r Section Name: " + exMessage.SectionName;
            }
            msg += " \n\r Page Name: " + exMessage.PageName + " \n\r ";

            return msg;
        }
    }
    
    #endregion

}