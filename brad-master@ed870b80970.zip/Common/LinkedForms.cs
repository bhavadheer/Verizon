﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class LinkedForms
    {
        #region " Public Members "
        private bool disposed = false;
        #endregion

        #region " Public Properties "
        public String FormInstance { get; set; }

        public String LegalName { get; set; }
        public String LinkText { get; set; }
        #endregion

        #region " Constructor "
        /// <summary>
        /// MenuData
        /// </summary>
        public LinkedForms()
        {
            FormInstance = String.Empty;
            LinkText = String.Empty;
        }
        #endregion

        #region " Destructor "
        /// <summary>
        /// ~MenuData
        /// </summary>
        ~LinkedForms()
        {
            this.Dispose(false);
        }
        #endregion

        #region " Dispose Methods "

        #region " Dispose "
        /// <summary>
        /// Dispose NavigationDB object
        /// </summary>
        public void Dispose()
        {
            //call dispose of any object used in this class
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

        #region " Dispose(bool disposing) "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    //call dispose of any object used in this class
                }
            }

            disposed = true;
        }

        #endregion

        #endregion
    }
}
