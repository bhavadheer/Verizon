﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Common
{
    [Serializable]
    public class FormSection
    {
        public int FormId { get; set; }
        public string FormName { get; set; }
        public int SectionId { get; set; }
        public String SectionName { get; set; }
        public String SectionDescription { get; set; }
        public int RevisionNo { get; set; }
    }
}
