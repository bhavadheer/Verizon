﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    [Serializable]
    public class Location : IEquatable<Location>, IDisposable
    {
        #region " Private Members "
        private bool disposed = false;
        #endregion

        #region " Public Properties "
        public Int32 LocationId { get; set; }
        public String LocationCode { get; set; }
        public String CountryCode { get; set; }
        public String Address { get; set; }
        #endregion

        #region " Destructor "
        /// <summary>
        /// ~Location
        /// </summary>
        ~Location()
        {
            this.Dispose(false);
        }
        #endregion

        #region " Dispose Methods "

        #region " Dispose "
        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            //call dispose of any object used in this class
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

        #region " Dispose(bool disposing) "
        /// <summary>
        /// Dispose(bool disposing)
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    //call dispose of any object used in this class
                }
            }

            disposed = true;
        }
        #endregion

        #endregion

        #region " Equals "
        /// <summary>
        /// Equals
        /// </summary>
        /// <param name="other"></param>
        /// <returns>bool</returns>
        public bool Equals(Location other)
        {
            return other != null && this.LocationCode == other.LocationCode && this.LocationId == other.LocationId;
        }
        #endregion
    }
}
