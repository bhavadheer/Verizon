﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;


namespace Common
{
    public enum RoleType : int
    {
        [DescriptionAttribute("None")]
        NotSet = 0,

        [DescriptionAttribute("BRTTeam")]
        BRTTeam = 101,

        [DescriptionAttribute("Administrator")]
        Administrator = 100
    }

    public static class EnumHelper
    {
        #region " GetEnumTypeFromString "
        /// <summary>
        /// GetEnumTypeFromString
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="input"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        public static T GetEnumTypeFromString<T>(string input, T defaultValue) where T : struct
        {
            T result;
            if (Enum.TryParse<T>(input, out result))
            {
                if (Enum.IsDefined(typeof(T), result))
                {
                    return result;
                }
            }

            return defaultValue;
        }
        #endregion

        #region " DisplayString "
        /// <summary>
        /// DisplayString
        /// </summary>
        /// <param name="value"></param>
        /// <returns>string</returns>
        public static string DisplayString(this Enum value)
        {
            //Using reflection to get the field info
            FieldInfo info = value.GetType().GetField(value.ToString());

            //Get the Description Attributes
            DescriptionAttribute[] attributes = (DescriptionAttribute[])info.GetCustomAttributes(typeof(DescriptionAttribute), false);

            //Only capture the description attribute if it is a concrete result (i.e. 1 entry)
            if (attributes.Length == 1)
            {
                return attributes[0].Description;
            }
            else //Use the value for display if not concrete result
            {
                return value.ToString();
            }
        }
        #endregion

        #region " EnumDictionary "
        /// <summary>
        /// EnumDictionary
        /// </summary>
        /// <param name="enumType"></param>
        /// <returns>Dictionary<Int32, String></returns>
        public static Dictionary<Int32, String> EnumDictionary<T>()
        {
            if (!typeof(T).IsEnum)
                throw new ArgumentException("Type must be an enum");

            return Enum.GetValues(typeof(T))
                .Cast<T>()
                .ToDictionary(t =>
                    (Int32)Convert.ChangeType(t, t.GetType()),
                    t => DisplayString((Enum)(Convert.ChangeType(t, t.GetType())))
                    );
        }
        #endregion

        #region " EnumDisplayValues "
        /// <summary>
        /// Enum Display Values
        /// </summary>
        /// <param name="enumType"></param>
        /// <returns></returns>
        public static IEnumerable<String> EnumDisplayValues(Array enumType)
        {
            List<String> dummyList = new List<String>();
            foreach (Enum e in enumType)
            {
                dummyList.Add(EnumHelper.DisplayString(e));
            }
            return dummyList;
        }
        #endregion

        #region " GetEnumTypeListFromString "
        /// <summary>
        /// GetEnumTypeListFromString
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="input"></param>
        /// <param name="splitChar"></param>
        /// <returns></returns>
        public static IEnumerable<T> GetEnumTypeListFromString<T>(string input, char[] splitChar) where T : struct
        {
            List<T> retList = new List<T>();

            string[] test = input.Split(splitChar);
            foreach (string sp in test)
            {
                T result;
                if (Enum.TryParse<T>(sp, out result))
                {
                    if (Enum.IsDefined(typeof(T), result))
                    {
                        if (!retList.Contains(result))
                        {
                            retList.Add(result);
                        }
                    }
                }
            }

            return retList;
        }
        #endregion

        #region " In "
        /// <summary>
        /// In
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="val"></param>
        /// <param name="values"></param>
        /// <returns></returns>
        public static bool In<T>(this T val, params T[] values) where T : struct
        {
            return values.Contains(val);
        }
        #endregion
    }
}
