﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class Announcement : IDisposable
    {
        #region " Private Members "
        private bool disposed = false;
        #endregion

        #region " Public Properties "
        public String AnnouncementId { get; set; }
        public String Title { get; set; }
        public String Description { get; set; }
        public Boolean Acknowledged { get; set; }
        #endregion

        #region " Constructor "
        /// <summary>
        /// Announcement
        /// </summary>
        public Announcement()
        {
            AnnouncementId = String.Empty;
            Title = String.Empty;
            Description = String.Empty;
            Acknowledged = false;
        }
        #endregion

        #region " Destructor "
        /// <summary>
        /// ~Announcement
        /// </summary>
        ~Announcement()
        {
            this.Dispose(false);
        }
        #endregion

        #region " Dispose Methods "

        #region " Dispose "
        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            //call dispose of any object used in this class
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

        #region " Dispose(bool disposing) "
        /// <summary>
        /// Dispose(bool disposing)
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    //call dispose of any object used in this class
                }
            }

            disposed = true;
        }
        #endregion

        #endregion
    }
}
