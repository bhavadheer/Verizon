﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    [Serializable]
    public class MenuData : IDisposable
    {
        #region " Private Members "
        private bool disposed = false;
        #endregion

        #region " Public Properties "
        public String MenuId { get; set; }
        public String CssClass { get; set; }
        public String PageURL { get; set; }
        public String DisplayName { get; set; }
        #endregion

        #region " Constructor "
        /// <summary>
        /// MenuData
        /// </summary>
        public MenuData()
        {
            MenuId = String.Empty;
            CssClass = String.Empty;
            PageURL = String.Empty;
            DisplayName = String.Empty;
        }
        #endregion

        #region " Destructor "
        /// <summary>
        /// ~MenuData
        /// </summary>
        ~MenuData()
        {
            this.Dispose(false);
        }
        #endregion

        #region " Dispose Methods "

        #region " Dispose "
        /// <summary>
        /// Dispose NavigationDB object
        /// </summary>
        public void Dispose()
        {
            //call dispose of any object used in this class
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

        #region " Dispose(bool disposing) "
        /// <summary>
        /// Dispose NavigationDB object.
        /// It cleans resources both managed and native
        /// </summary>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    //call dispose of any object used in this class
                }
            }

            disposed = true;
        }

        #endregion

        #endregion
    }
}
