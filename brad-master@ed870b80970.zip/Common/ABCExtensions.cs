﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using Telerik.Web.UI;
using System.Drawing;
using System.Web;
using System.Threading;
using System.Data;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
namespace Common
{
    public static class ABCExtensions
    {
        /// <summary>
        /// Extension method for formatting date to UK format.
        /// </summary>
        /// <param name="rdp"></param>
        /// <returns></returns>
        public static CultureInfo UKDate(this RadDatePicker rdp)
        {
            var ci = new System.Globalization.CultureInfo("") { DateTimeFormat = { ShortDatePattern = "dd/MM/yyyy" } };
            return ci;
        }

        /// <summary>
        /// Export DataTable to Excel file
        /// </summary>
        /// <param name="DataTable">Source DataTable</param>
        /// <param name="ExcelFilePath">Path to result file name</param>
        public static void ExportToExcel(this System.Data.DataTable DataTable, string ExcelFilePath = null)
        {
            try
            {
                //Export datatable to xml spreadsheet format to open in excel 
                var fileName = DateTime.Now.ToString("yyyyMMddHHmmss") + ".xml";
                var attachment = "attachment;filename=" + fileName;
                HttpContext.Current.Response.Clear();
                HttpContext.Current.Response.ClearContent();
                HttpContext.Current.Response.AddHeader("content-disposition", attachment);
                HttpContext.Current.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                HttpContext.Current.Response.Write(CreateXMLSpreadSheet(DataTable));
                HttpContext.Current.Response.Flush();
                HttpContext.Current.Response.SuppressContent = true;
                HttpContext.Current.ApplicationInstance.CompleteRequest();
            }
            catch (ThreadAbortException)
            {
                //do nothing thread aborted to export data to excel
            }
            catch (Exception)
            {
            }

        }

        /// <summary>
        /// Export DataTable to Excel file using OpenXML
        /// </summary>
        /// <param name="DataTable">Source DataTable</param>
        /// <param name="ExcelFilePath">Path to result file name</param>
        public static void ExportToExcelOpenXML(this System.Data.DataTable DataTable, string ExcelFilePath = null)
        {

            var workbook = SpreadsheetDocument.Create(ExcelFilePath, DocumentFormat.OpenXml.SpreadsheetDocumentType.Workbook);

            workbook.WorkbookPart.Workbook = new DocumentFormat.OpenXml.Spreadsheet.Workbook();

            workbook.WorkbookPart.Workbook.Sheets = new DocumentFormat.OpenXml.Spreadsheet.Sheets();


            var sheetPart = workbook.WorkbookPart.AddNewPart<WorksheetPart>();
            var sheetData = new DocumentFormat.OpenXml.Spreadsheet.SheetData();
            sheetPart.Worksheet = new DocumentFormat.OpenXml.Spreadsheet.Worksheet(sheetData);

            var stylesPart = workbook.WorkbookPart.AddNewPart<WorkbookStylesPart>();
            stylesPart.Stylesheet = new Stylesheet();

            Console.WriteLine("Creating styles");

            // blank font list
            stylesPart.Stylesheet.Fonts = new Fonts();
            stylesPart.Stylesheet.Fonts.Count = 1;
            stylesPart.Stylesheet.Fonts.AppendChild(new DocumentFormat.OpenXml.Spreadsheet.Font());

            // blank border list
            stylesPart.Stylesheet.Borders = new Borders();
            stylesPart.Stylesheet.Borders.Count = 1;
            stylesPart.Stylesheet.Borders.AppendChild(new Border());

            // blank cell format list
            stylesPart.Stylesheet.CellStyleFormats = new CellStyleFormats();
            stylesPart.Stylesheet.CellStyleFormats.Count = 1;
            stylesPart.Stylesheet.CellStyleFormats.AppendChild(new CellFormat() { NumberFormatId = UInt32Value.ToUInt32(49) });

            // cell format list
            stylesPart.Stylesheet.CellFormats = new CellFormats();
            // empty one for index 0, seems to be required
            stylesPart.Stylesheet.CellFormats.AppendChild(new CellFormat());
            // cell format references style format 0, font 0, border 0, fill 2 and applies the fill
            stylesPart.Stylesheet.CellFormats.AppendChild(new CellFormat { FormatId = 0, FontId = 0, BorderId = 0, FillId = 2, ApplyFill = true }).AppendChild(new Alignment { Horizontal = HorizontalAlignmentValues.Center });
            stylesPart.Stylesheet.CellFormats.Count = 2;

            stylesPart.Stylesheet.Save();


            var sheets = workbook.WorkbookPart.Workbook.GetFirstChild<DocumentFormat.OpenXml.Spreadsheet.Sheets>();
            var relationshipId = workbook.WorkbookPart.GetIdOfPart(sheetPart);

            uint sheetId = 1;
            if (sheets.Elements<DocumentFormat.OpenXml.Spreadsheet.Sheet>().Any())
            {
                sheetId =
                    sheets.Elements<DocumentFormat.OpenXml.Spreadsheet.Sheet>().Select(s => s.SheetId.Value).Max() + 1;
            }

            var sheet = new DocumentFormat.OpenXml.Spreadsheet.Sheet() { Id = relationshipId, SheetId = sheetId, Name = DataTable.TableName };
            sheets.Append(sheet);

            var headerRow = new DocumentFormat.OpenXml.Spreadsheet.Row();

            var columns = new List<string>();
            foreach (System.Data.DataColumn column in DataTable.Columns)
            {
                columns.Add(column.ColumnName);

                var cell = new Cell
                {
                    DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String,
                    CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(column.ColumnName)
                };
                headerRow.AppendChild(cell);
            }

            sheetData.AppendChild(headerRow);
            var index = 2;
            foreach (System.Data.DataRow dsrow in DataTable.Rows)
            {
                var newRow = new DocumentFormat.OpenXml.Spreadsheet.Row();
                foreach (String col in columns)
                {
                    var cell = CreateTextCell("Test", dsrow[col].ToString(), index);
                    newRow.AppendChild(cell);
                }
                sheetData.AppendChild(newRow);
                index++;
            }

            workbook.WorkbookPart.Workbook.Save();
            workbook.Close();
        }
        
        /// <summary>
        /// Recursively create directory
        /// </summary>
        /// <param name="dirInfo">Folder path to create.</param>
        public static void CreateDirectory(this System.IO.DirectoryInfo dirInfo)
        {
            if (dirInfo.Parent != null) CreateDirectory(dirInfo.Parent);
            if (!dirInfo.Exists) dirInfo.Create();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string GetTimeStamp(this DateTime value)
        {
            return value.ToString("yyyyMMddHHmmssffff");
        }

        

        /// <summary>
        /// Extension method for formatting date to UK format.
        /// </summary>
        /// <param name="rdp"></param>
        /// <returns></returns>
        public static string UKDate(this DateTime rdp)
        {
            var ci = rdp.ToString("dd/MM/yyyy", new CultureInfo("en-GB"));
            return ci;
        }

        public static string HtmlEncode(this string data)
        {
            return HttpUtility.HtmlEncode(data);
        }

        public static string HtmlDecode(this string data)
        {
            return HttpUtility.HtmlDecode(data);
        }


        #region " Private Methods "

        #region " CreateXMLSpreadSheet "
        /// <summary>
        /// Create XML Spread Sheet
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        private static string CreateXMLSpreadSheet(DataTable dt)
        {
            StringBuilder xmlString = null;
            //set row count, +1 for first row containing column names
            string rowCount = (dt.Rows.Count + 2).ToString();
            //Set the column count
            string columnCount = dt.Columns.Count.ToString();
            xmlString = new StringBuilder();

            //Standard header for data table - Alter to include advanced styles
            #region "xml header"
            xmlString.Append(@"<?xml version=""1.0""?>
                        <?mso-application progid=""Excel.Sheet""?>
                        <Workbook xmlns=""urn:schemas-microsoft-com:office:spreadsheet""
                         xmlns:o=""urn:schemas-microsoft-com:office:office""
                         xmlns:x=""urn:schemas-microsoft-com:office:excel""
                         xmlns:ss=""urn:schemas-microsoft-com:office:spreadsheet""
                         xmlns:html=""http://www.w3.org/TR/REC-html40""
                         xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:user=""urn:my-scripts"">
                         <DocumentProperties xmlns=""urn:schemas-microsoft-com:office:office"">
                          <Version>15.00</Version>
                         </DocumentProperties>
                         <OfficeDocumentSettings xmlns=""urn:schemas-microsoft-com:office:office"">
                          <AllowPNG/>
                         </OfficeDocumentSettings>
                         <ExcelWorkbook xmlns=""urn:schemas-microsoft-com:office:excel"">
                          <WindowHeight>11595</WindowHeight>
                          <WindowWidth>19200</WindowWidth>
                          <WindowTopX>0</WindowTopX>
                          <WindowTopY>0</WindowTopY>
                          <ProtectStructure>False</ProtectStructure>
                          <ProtectWindows>False</ProtectWindows>
                         </ExcelWorkbook>
                         <Styles>
                          <Style ss:ID=""Default"" ss:Name=""Normal"">
                           <Alignment ss:Vertical=""Bottom""/>
                           <Borders/>
                           <Font ss:FontName=""Calibri"" x:Family=""Swiss"" ss:Size=""11"" ss:Color=""#000000""/>
                           <Interior/>
                           <NumberFormat/>
                           <Protection/>
                          </Style>
                          <Style ss:ID=""s62"">
                           <Font ss:FontName=""Calibri"" x:Family=""Swiss"" ss:Size=""11"" ss:Color=""#000000""
                            ss:Bold=""1""/>
                          </Style>
                         </Styles>
                         <Worksheet ss:Name=""Table""><Table ss:ExpandedColumnCount=""");
            xmlString.Append(columnCount);
            xmlString.Append(@""" ss:ExpandedRowCount="""); xmlString.Append(rowCount);
            xmlString.Append(@""" x:FullColumns=""1""  x:FullRows=""1"" ss:DefaultRowHeight=""15"">");
            #endregion

            //Standard Column names as in datatable - Comment this for assigning own column names
            #region "Columns"
            xmlString.Append(@"<Row ss:StyleID=""s62"">");
            foreach (DataColumn c in dt.Columns)
            {
                xmlString.Append(@"<Cell NumberFormat=""@""><Data ss:Type=""String"">");
                xmlString.Append(c.ColumnName);
                xmlString.Append("</Data></Cell>");

            }
            xmlString.Append("</Row>");
            #endregion

            //Get values from each rows in datatable and convert to xml
            #region "Rows"
            int i = 0;
            foreach (DataRow dr in dt.Rows)
            {
                xmlString.Append("<Row>");
                for (i = 0; i < dt.Columns.Count; i++)
                {
                    xmlString.Append(@"<Cell><Data ss:Type=""String"">");
                    xmlString.Append(HtmlRemoval.StripTagsRegex(dr[i].ToString()));
                    xmlString.Append("</Data></Cell>");
                }
                xmlString.Append("</Row>");
            }
            #endregion

            //Standard footer - Alter to change advanced properties
            #region "xml footer"
            xmlString.Append(@"</Table>
              <WorksheetOptions xmlns=""urn:schemas-microsoft-com:office:excel"">
               <Print>
                <ValidPrinterInfo/>
                <HorizontalResolution>600</HorizontalResolution>
                <VerticalResolution>600</VerticalResolution>
               </Print>
               <Selected/>
               <Panes>
                <Pane>
                 <Number>3</Number>
                 <ActiveRow>6</ActiveRow>
                 <ActiveCol>8</ActiveCol>
                </Pane>
               </Panes>
               <ProtectObjects>False</ProtectObjects>
               <ProtectScenarios>False</ProtectScenarios>
              </WorksheetOptions>
             </Worksheet>
            </Workbook>");
            #endregion

            return xmlString.ToString();
        }
        #endregion

        static Cell CreateTextCell(string header, string text, int index)
        {
            //Create a new inline string cell.
            var c = new Cell
            {
                DataType = CellValues.InlineString,
                CellReference = header + index,
                StyleIndex = 1
            };
            //Add text to the text cell.
            var inlineString = new InlineString();
            var t = new Text
            {
                Text = text
            };
            inlineString.AppendChild(t);
            c.AppendChild(inlineString);
            return c;
        }

        private static Stylesheet CreateStylesheet()
        {
            var ss = new Stylesheet();

            var nfs = new NumberingFormats();
            var nformatDateTime = new NumberingFormat
            {
                NumberFormatId = UInt32Value.FromUInt32(49)
            };
            nfs.Append(nformatDateTime);
            ss.Append(nfs);

            return ss;
        }

        private static UInt32Value createCellFormat(
            Stylesheet styleSheet,
            UInt32Value fontIndex,
            UInt32Value fillIndex,
            UInt32Value numberFormatId)
        {
            var cellFormat = new CellFormat();

            if (fontIndex != null)
                cellFormat.FontId = fontIndex;

            if (fillIndex != null)
                cellFormat.FillId = fillIndex;

            if (numberFormatId != null)
            {
                cellFormat.NumberFormatId = numberFormatId;
                cellFormat.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            }

            styleSheet.CellFormats.Append(cellFormat);

            var result = styleSheet.CellFormats.Count;
            styleSheet.CellFormats.Count++;
            return result;
        }
        #endregion

    }
}
