﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common
{
    [Serializable]
    public class ExtraField : DynamicField
    {
        private bool disposed = false;

        public DynControlType QuestionField { get; set; }

        public DynControlType ButtonField { get; set; }

        protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            if (disposing)
            {
                //dispose the object
            }
            disposed = true;
            base.Dispose(disposing);
        }
    }
}
