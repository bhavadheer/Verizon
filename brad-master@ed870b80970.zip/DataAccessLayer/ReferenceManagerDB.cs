﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Data.Common;


namespace DataAccessLayer
{
    public class ReferenceManagerDB : BaseClass
    {
        #region " Private Members "
        private bool disposed = false;
        Database _dbToConnect = null;
        #endregion

        #region " Constructor "
        /** \public  ReferenceManagerDB 
         *  \details    Constructor to initilize the database object
         *  \param ConnectionString
         */
        public ReferenceManagerDB(string connectionstring)
        {
            _dbToConnect = new SqlDatabase(connectionstring);
        }
        #endregion

        #region " Dispose Methods "
        protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            if (disposing)
            {

            }
            disposed = true;
            base.Dispose(disposing);
        }
        #endregion

        #region " Public Methods "

        #region " GetUserCredentials "
        public DataTable GetUserCredentials(string vzid)
        {
            DataTable resultData = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_UserCredentials"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@vzid", DbType.String, vzid);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            resultData = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return resultData;
        }
        #endregion

        #region " GetStsId "
        public DataTable GetStsId(string userId)
        {
            DataTable resultData = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("Qry_STSPersonnelId"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@userId", DbType.String, userId);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            resultData = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return resultData;
        }
        #endregion

        #region " SaveUserAccessHistory "
        /// <summary>
        /// INSERT THE LOGGED IN StsId  TO THE UerAccessHistory
        /// </summary>
        /// <returns></returns>
        public int SaveUserAccessHistory(int loggedInStsId, string loggedInUserName, string action)
        {
            int isSaved = 0;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("ins_UserAccessHistory"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@loggedInStsId", DbType.Int32, loggedInStsId);
                    _dbToConnect.AddInParameter(sqlCmd, "@loggedInUserName", DbType.String, loggedInUserName);
                    _dbToConnect.AddInParameter(sqlCmd, "@action", DbType.String, action);
                    isSaved = _dbToConnect.ExecuteNonQuery(sqlCmd);
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isSaved;
        }
        #endregion

        #region " GetMainNavigation "
        public DataTable GetMainNavigation(int roleId)
        {
            DataTable resultData = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_AllMainTabs"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@roleId", DbType.Int32, roleId);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            resultData = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return resultData;
        }
        #endregion

        #region " GetMainTabToHighlight "
        public DataTable GetMainTabToHighlight(string pageName)
        {
            DataTable resultData = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_CurrentHighlightTab"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@pageName", DbType.String, pageName);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            resultData = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return resultData;
        }
        #endregion

        #region " GetRightLinks "
        public DataTable GetRightLinks(int roleId, string mainTabId)
        {
            DataTable resultData = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_AllRightLinks"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@roleId", DbType.Int32, roleId);
                    _dbToConnect.AddInParameter(sqlCmd, "@MainId", DbType.String, mainTabId);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            resultData = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return resultData;
        }
        #endregion

        #region " IsUrlAccessible "
        /// <summary>
        /// IsUrlAccessible
        /// </summary>
        /// <param name="roleId"></param>
        /// <param name="url"></param>
        /// <returns>DataTable</returns>
        public DataTable IsUrlAccessible(int roleId, string url)
        {
            DataTable resultData = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_PageAuthentication"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@roleId", DbType.Int32, roleId);
                    _dbToConnect.AddInParameter(sqlCmd, "@url", DbType.String, url);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            resultData = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return resultData;
        }
        #endregion

        

        #endregion
    }
}
