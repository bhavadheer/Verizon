﻿using System;
using System.Data;
using System.Data.SqlClient;
using Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Data.Common;

namespace DataAccessLayer
{
    public class DropDownDataDB : BaseClass
    {
        #region " Private Members "
        private bool disposed = false;
        Database _dbToConnect = null;
        #endregion

        #region " Constructor "
        /** \public  ReferenceManagerDB 
         *  \details    Constructor to initilize the database object
         *  \param ConnectionString
         */
        public DropDownDataDB(string connectionstring)
        {
            _dbToConnect = new SqlDatabase(connectionstring);
        }
        #endregion

        #region " Dispose Methods "
        protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            if (disposing)
            {

            }
            disposed = true;
            base.Dispose(disposing);
        }
        #endregion

        #region " GetAllDropDownDataByCategory "
        /// <summary>
        /// GetAllDropDownDataByCategory
        /// </summary>
        /// <param name="ddType"></param>
        /// <returns>DataTable</returns>
        public DataTable GetAllDropDownDataByCategory(string ddType)
        {
            DataTable resultData = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_GetDropdownDataByCategory"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@ddType", DbType.String, ddType);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            resultData = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultData;
        }
        #endregion

        #region " UpdateDropdownData "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="category"></param>
        /// <param name="ddValues"></param>
        /// <param name="vzId"></param>
        public void UpdateDropdownData(string category, string ddValues, string vzId)
        {
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("upd_DropdownValues"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@category", DbType.String, category);
                    _dbToConnect.AddInParameter(sqlCmd, "@DDValues", DbType.String, ddValues);
                    _dbToConnect.AddInParameter(sqlCmd, "@vzid", DbType.String, vzId);

                    var resultSet = _dbToConnect.ExecuteNonQuery(sqlCmd);
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " DeleteDropdownVal "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ddId"></param>
        /// <param name="vzId"></param>
        /// <returns></returns>
        public DataTable DeleteDropdownVal(int ddId, string vzId)
        {
            DataTable resultData = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("del_DropdownVal"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@ddId", DbType.Int32, ddId);
                    _dbToConnect.AddInParameter(sqlCmd, "@vzId", DbType.String, vzId);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            resultData = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultData;
        }
        #endregion

        #region " GetDropDownCategories "
        /// <summary>
        /// GetDropDownCategories
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable GetDropDownCategories()
        {
            DataTable resultData = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_GetDropdownCategories"))
                {
                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            resultData = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultData;
        }
        #endregion

        #region " GetSectionsDropDown "
        /// <summary>
        /// GetSectionsDropDown
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable GetSectionsDropDown()
        {
            DataTable resultData = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_GetFormSectionDropDown"))
                {
                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            resultData = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultData;
        }
        #endregion
    }
}
