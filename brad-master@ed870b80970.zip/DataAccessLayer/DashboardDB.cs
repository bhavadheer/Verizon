﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Common;

namespace DataAccessLayer
{
    public class DashboardDB : BaseClass
    {
        #region " Private Members "
        private bool disposed = false;
        Database _dbToConnect = null;
        #endregion

        #region " Constructor "
        /** \public  DashboardDB 
         *  \details    Constructor to initilize the database object
         *  \param ConnectionString
         */
        public DashboardDB(string connectionstring)
        {
            _dbToConnect = new SqlDatabase(connectionstring);
        }
        #endregion

        #region " Dispose Methods "
        protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            if (disposing)
            {

            }
            disposed = true;
            base.Dispose(disposing);
        }
        #endregion

        #region " Public Methods "

        #region " GetPersonnelList "
        /** \public     GetPersonnelList 
         *  \author     David Martinez
         *  \date       03/21/2016
         *  \desc       Retrieve personnel list
         *  \param      none
         */
        public DataTable GetPersonnelList()
        {
            DataTable _dt = null;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_GetPersonnel"))
                {
                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return _dt;

        }

        #endregion

        #region " GetFormsDropDownList "
        /** \public     GetFormsDropDownList 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    Used qry_GetFormsDropDown to Returns DropDown List based on ddType,ParentslectedValue and role
         *  \param      ddType string
         *  \param      roleId string
         *  \param      ParentSelectedValue int
         *  \returns    DataTable
         */
        public DataTable GetFormsDropDownList()
        {
            DataTable _dt = null;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_GetFormsDropDown"))
                {
                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return _dt;

        }
        #endregion

        #region " GetFormSectionDropDownList "
        /** \public     GetFormSectionDropDownList 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    Used qry_FormSections to Returns DropDown List based on type and role.
         *  \param      ddType string
         *  \param      roleId string
         *  \returns    DataTable
         */
        public DataTable GetFormSectionDropDownList(int ddType, int roleId, int privilegeId)
        {
            DataTable _dt = null;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_FormSections"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formId", DbType.Int32, ddType);
                    _dbToConnect.AddInParameter(sqlCmd, "@roleId", DbType.Int32, roleId);
                    _dbToConnect.AddInParameter(sqlCmd, "@privilegeId", DbType.Int32, privilegeId);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return _dt;


        }
        #endregion

        #region " GetFormsSearch "
        /** \public     GetFormsSearch 
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    Used qry_FormsSearch and Based on Search Criteria it pulls all results from Database.
         *  \param      FormName int
         *  \param      FormSection int
         *  \param      FormQuestions string
         *  \param      Creator string
         *  \param      DateFromCreated DateTime
         *  \param      DateToCreated DateTime
         *  \param      vzid string
         *  \param      connStr string
         *  \return     A Datatable.
         */
        public DataTable GetFormsSearch(int FormName, string FormInstance, string currentReportStatus,
                                        string analystName, DateTime DateFromCreated, DateTime DateToCreated,
                                        int ShowType, int userStsId, string isUrgent, string currentReviewStatus)
        {
            DataTable _dt = null;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_FormsSearch"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formId", DbType.Int32, FormName);
                    if (currentReportStatus == string.Empty)
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@currentReportStatus", DbType.String, DBNull.Value);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@currentReportStatus", DbType.String, currentReportStatus);
                    }

                    if (ShowType != 3)
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@showType", DbType.Int32, ShowType);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@showType", DbType.Int32, DBNull.Value);
                    }

                    if (!string.IsNullOrEmpty(analystName))
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@analystName", DbType.String, analystName);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@analystName", DbType.String, DBNull.Value);
                    }

                    if (!string.IsNullOrEmpty(FormInstance))
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, FormInstance);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, DBNull.Value);
                    }
                    if (DateFromCreated.ToShortDateString() == "1/1/1900")
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@dateFromCreated", DbType.DateTime, DBNull.Value);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@dateFromCreated", DbType.DateTime, DateFromCreated);
                    }
                    if (DateToCreated.ToShortDateString() == "1/1/1900")
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@dateToCreated", DbType.DateTime, DBNull.Value);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@dateToCreated", DbType.DateTime, DateToCreated);
                    }

                    if (!string.IsNullOrEmpty(isUrgent))
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@isUrgent", DbType.String, isUrgent);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@isUrgent", DbType.String, DBNull.Value);
                    }
                    if (currentReviewStatus == string.Empty)
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@currentReviewStatus", DbType.String, DBNull.Value);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@currentReviewStatus", DbType.String, currentReviewStatus);
                    }
                    _dbToConnect.AddInParameter(sqlCmd, "@stsId", DbType.Int32, userStsId);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return _dt;

        }
        #endregion

        #region " GetGlobalSearch "
        /** \public     GetGlocalSearch 
         *  \author     David Martinez
         *  \date       03/10/2016
         *  \desc       Retrieve search results
         *  \param      inSearchParam string
         */
        public DataTable GetGlobalSearch(string inSearchParam, int? questId, int searchType)
        {
            DataTable _dt = null;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_GlobalSearch"))
                {
                    sqlCmd.CommandTimeout = 360;
                    _dbToConnect.AddInParameter(sqlCmd, "@inSearch", DbType.String, inSearchParam);
                    if (questId != 0)
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@filterId", DbType.Int32, questId);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@filterId", DbType.Int32, DBNull.Value);
                    }

                    _dbToConnect.AddInParameter(sqlCmd, "@searchType", DbType.String, searchType);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return _dt;
        }
        #endregion

        #region " ExportGlobalSearchResults "
        /** \public     ExportGlobalSearchResults 
         *  \author     Bharath Bellam
         *  \date       08/15/2016
         *  \desc       To export global search results to excel
         *  \param      inSearchParam string
         */
        public DataTable ExportGlobalSearchResults(string inSearchParam, int? questId, int searchType)
        {
            DataTable _dt = null;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_ExportGlobalSearch"))
                {
                    sqlCmd.CommandTimeout = 360;
                    _dbToConnect.AddInParameter(sqlCmd, "@inSearch", DbType.String, inSearchParam);

                    if (questId != 0)
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@filterId", DbType.Int32, questId);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@filterId", DbType.Int32, DBNull.Value);
                    }
                    _dbToConnect.AddInParameter(sqlCmd, "@searchType", DbType.String, searchType);
                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return _dt;
        }
        #endregion

        #region " DeleteForm "
        /** \public     DeleteForm
         *  \details    Delete Form 
         *  \param      FormInstance
         *  \param      StsId
         *  \return     returns data table with outcome
        */
        public DataTable DeleteForm(string FormInstance, bool isActive, int StsId)
        {
            DataTable _dt = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("del_Form"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, FormInstance);
                    _dbToConnect.AddInParameter(sqlCmd, "@isActive", DbType.Boolean, isActive);
                    _dbToConnect.AddInParameter(sqlCmd, "@stsId", DbType.Int32, StsId);
                    _dbToConnect.ExecuteNonQuery(sqlCmd);
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _dt;
        }
        #endregion

        #region " GetGlobalFilter "
        /** \public     GetGlobalFilter 
         *  \section    First Draft
         *  \author     Rajesh Srigakolapu
         *  \date       09/13/2017
         *  \details    Used qry_GetDropdownQueGlobalCategory to Returns DropDown List based on ddType,ParentslectedValue and role
         *  \param      ddType string
         *  \param      roleId string
         *  \param      ParentSelectedValue int
         *  \returns    DataTable
         */
        public DataTable GetGlobalFilter()
        {
            DataTable _dt = null;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_GetDropdownQueGlobalCategory"))
                {
                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return _dt;

        }
        #endregion

        #region " GetFormQuestions "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formId"></param>
        /// <param name="sectionId"></param>
        /// <param name="roleId"></param>
        /// <returns></returns>
        public DataTable GetFormQuestions(int formId, int sectionId, int roleId)
        {
            DataTable _dt = null;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_FormQuestionsBySectionId"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formId", DbType.Int32, formId);
                    _dbToConnect.AddInParameter(sqlCmd, "@sectionId", DbType.Int32, sectionId);
                    _dbToConnect.AddInParameter(sqlCmd, "@roleId", DbType.Int32, roleId);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return _dt;

        }
        #endregion

        #region " GetFormQuestions "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="questionId"></param>
        /// <returns></returns>
        public DataTable GetFormQuestionById(int questionId)
        {
            DataTable _dt = null;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_FormQuestionsById"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@questionId", DbType.Int32, questionId);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return _dt;

        }
        #endregion

        #region " UpdateFormQuestions "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="questionId"></param>
        /// <param name="questionText"></param>
        /// <param name="isRequired"></param>
        /// <param name="stsId"></param>
        /// <returns></returns>
        public void UpdateFormQuestions(int questionId, string questionText, int isRequired, int stsId)
        {
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("upd_FormQuestions"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formquestionId", DbType.Int32, questionId);
                    _dbToConnect.AddInParameter(sqlCmd, "@questionText", DbType.String, questionText);
                    _dbToConnect.AddInParameter(sqlCmd, "@isRequired", DbType.Int32, isRequired);
                    _dbToConnect.AddInParameter(sqlCmd, "@stsId", DbType.Int32, stsId);

                    _dbToConnect.ExecuteDataSet(sqlCmd);
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region " InsertFormQuestions "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="questionText"></param>
        /// <param name="ansControlType"></param>
        /// <param name="ddIdentifier"></param>
        /// <param name="isRequired"></param>
        /// <param name="formId"></param>
        /// <param name="sectionId"></param>
        /// <param name="stsId"></param>
        public void InsertFormQuestions(string questionText, int ansControlType, string ddIdentifier, int isRequired, string formId, string sectionId, int stsId)
        {
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("ins_FormQuestions"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@questionText", DbType.String, questionText);
                    _dbToConnect.AddInParameter(sqlCmd, "@answerControlType", DbType.Int32, ansControlType);
                    if (!string.IsNullOrEmpty(ddIdentifier))
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@ddIdentifier", DbType.String, ddIdentifier);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@ddIdentifier", DbType.String, DBNull.Value);
                    }
                    _dbToConnect.AddInParameter(sqlCmd, "@isRequired", DbType.Int32, isRequired);
                    _dbToConnect.AddInParameter(sqlCmd, "@formId", DbType.String, formId);
                    _dbToConnect.AddInParameter(sqlCmd, "@sectionId", DbType.String, sectionId);
                    _dbToConnect.AddInParameter(sqlCmd, "@stsId", DbType.Int32, stsId);
                    _dbToConnect.AddOutParameter(sqlCmd, "@questionId", DbType.Int32, 20);

                    _dbToConnect.ExecuteDataSet(sqlCmd);
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region " GetBRTTimeReport "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="businessRel"></param>
        /// <param name="formInstance"></param>
        /// <returns></returns>
        public DataTable GetBRTTimeReport(string businessRel, string formInstance)
        {
            DataTable _dt = null;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_BRTTimeReport"))
                {
                    if (string.IsNullOrEmpty(businessRel))
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@businessRel", DbType.String, DBNull.Value);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@businessRel", DbType.String, businessRel);
                    }
                    if (string.IsNullOrEmpty(formInstance))
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, DBNull.Value);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, formInstance);
                    }
                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return _dt;

        }
        #endregion

        #region " GetBRTTimeReportExport "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="businessRel"></param>
        /// <param name="formInstance"></param>
        /// <returns></returns>
        public DataTable GetBRTTimeReportExport(string businessRel, string formInstance)
        {
            DataTable _dt = null;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_BRTTimeReportExport"))
                {
                    if (string.IsNullOrEmpty(businessRel))
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@businessRel", DbType.String, DBNull.Value);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@businessRel", DbType.String, businessRel);
                    }
                    if (string.IsNullOrEmpty(formInstance))
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, DBNull.Value);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, formInstance);
                    }
                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return _dt;

        }
        #endregion

        #region " GetQuestionsGlobalCategory "
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable GetQuestionsGlobalCategory()
        {
            DataTable _dt = null;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_QuestionsGlobalCategory"))
                {
                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return _dt;

        }
        #endregion

        #region " InsertGlobalCatQuestions "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="questionIds"></param>
        /// <param name="stsId"></param>
        public void InsertGlobalCatQuestions(string questionIds, int stsId)
        {
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("upd_GlobalSearchCategory"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formquestionId", DbType.String, questionIds);
                    _dbToConnect.AddInParameter(sqlCmd, "@stsId", DbType.Int32, stsId);

                    _dbToConnect.ExecuteDataSet(sqlCmd);
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region " ExportFormSearchResults "
        /** \public     ExportFormSearchResults 
         *  \author     Rajesh Srigakolapu
         *  \date       12/22/2017
         *  \desc       To export Forms search results to excel
         *  \param      inSearchParam string
         */
        public DataTable ExportFormSearchResults(int FormName, string FormInstance, string currentReportStatus,
                                                string analystName, DateTime DateFromCreated, DateTime DateToCreated,
                                                int ShowType, int userStsId, string isUrgent, string currentReviewStatus)
        {
            DataTable _dt = null;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_ExportFormsSearch"))
                {
                    sqlCmd.CommandTimeout = 360;
                    _dbToConnect.AddInParameter(sqlCmd, "@formId", DbType.Int32, FormName);
                    if (currentReportStatus == string.Empty)
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@currentReportStatus", DbType.String, DBNull.Value);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@currentReportStatus", DbType.String, currentReportStatus);
                    }

                    if (ShowType != 3)
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@showType", DbType.Int32, ShowType);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@showType", DbType.Int32, DBNull.Value);
                    }

                    if (!string.IsNullOrEmpty(analystName))
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@analystName", DbType.String, analystName);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@analystName", DbType.String, DBNull.Value);
                    }

                    if (!string.IsNullOrEmpty(FormInstance))
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, FormInstance);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, DBNull.Value);
                    }
                    if (DateFromCreated.ToShortDateString() == "1/1/1900")
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@dateFromCreated", DbType.DateTime, DBNull.Value);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@dateFromCreated", DbType.DateTime, DateFromCreated);
                    }
                    if (DateToCreated.ToShortDateString() == "1/1/1900")
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@dateToCreated", DbType.DateTime, DBNull.Value);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@dateToCreated", DbType.DateTime, DateToCreated);
                    }
                    if (!string.IsNullOrEmpty(isUrgent))
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@isUrgent", DbType.String, isUrgent);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@isUrgent", DbType.String, DBNull.Value);
                    }

                    if (currentReviewStatus == string.Empty)
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@currentReviewStatus", DbType.String, DBNull.Value);
                    }
                    else
                    {
                        _dbToConnect.AddInParameter(sqlCmd, "@currentReviewStatus", DbType.String, currentReviewStatus);
                    }

                    _dbToConnect.AddInParameter(sqlCmd, "@stsId", DbType.Int32, userStsId);
                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return _dt;
        }
        #endregion

        #region " GetFormsSearch "
        /** \public     GetFormsSearch 
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    Used qry_FormsSearch and Based on Search Criteria it pulls all results from Database.
         *  \param      FormName int
         *  \param      FormSection int
         *  \param      FormQuestions string
         *  \param      Creator string
         *  \param      DateFromCreated DateTime
         *  \param      DateToCreated DateTime
         *  \param      vzid string
         *  \param      connStr string
         *  \return     A Datatable.
         */
        public DataTable GetUnblockFormsSearch(int userStsId)
        {
            DataTable _dt = null;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_FormsSearch_Unblock"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@stsId", DbType.Int32, userStsId);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return _dt;

        }
        #endregion

        #endregion
    }
}
