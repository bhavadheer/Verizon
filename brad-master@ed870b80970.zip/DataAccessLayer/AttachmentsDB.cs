﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Transactions;
using System.Data.SqlClient;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;

namespace DataAccessLayer
{
    public class AttachmentsDB : IDisposable
    {

        #region Private Members
        private DataTable resultData = new DataTable();
        private DataSet resultSet = new DataSet();
        private bool _disposed = false;
        Database _dbToConnect = null;
        #endregion

        #region " Constructor "
        /** \public  ReferenceManagerDB 
         *  \details    Constructor to initilize the database object
         *  \param ConnectionString
         */
        public AttachmentsDB(string connectionstring)
        {
            _dbToConnect = new SqlDatabase(connectionstring);
        }
        #endregion

        #region " Destructor "
        /**\public  ~ReferenceManagerDB 
         * \details call dispose(false)
         */
        ~AttachmentsDB()
        {
            this.Dispose(false);
        }
        #endregion

        #region Protected Methods
        /**\protected  Dispose 
         * \details Dispose Navigation object
         * \details It cleans resources both managed and native
         */
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    /**call dispose of any object used in this class*/
                    if (resultData != null)
                    {
                        resultData.Dispose();
                    }
                    if (resultSet != null)
                    {
                        resultSet.Dispose();
                    }

                }
            }

            _disposed = true;
        }
        #endregion

        #region public  Dispose
        /**\public  Dispose 
         * \details Over riding method for the dispose interface.
         */
        public void Dispose()
        {
            /**call dispose of any object used in this class*/
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

        #region " GetAttachments "
        /** \public     GetAttachments
         *  \details    Get Attachments Data using StoredProcedure qry_Attachment.
         *  \param      CrId
         *  \param      StsId         
         *  \return     returns a data table  values.
         */
        public DataTable GetAttachments(int crId, int stsId)
        {
            try
            {
                DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_AttachmentByCRId");

                _dbToConnect.AddInParameter(sqlCmd, "@CRId", DbType.Int32, crId);
                _dbToConnect.AddInParameter(sqlCmd, "@StsId", DbType.Int32, stsId);
                resultSet = _dbToConnect.ExecuteDataSet(sqlCmd);
                if (resultSet != null && resultSet.Tables.Count > 0)
                {
                    resultData = resultSet.Tables[0];
                }

                return resultData;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        #endregion

        #region " InsertAttachmentWithStream "
        /** \public     InsertAttachment
         *  \details    insert Attachment Data using StoredProcedure ins_Attachment.
         *  \param      Attachment Common class objects   
         *  \param      stsId int 
         *  \return     returns data table with outcome
         */
        public DataTable InsertAttachmentWithStream(Attachment attachmentObj, string formInstance, int identifier, int stsId, Stream fs)
        {
            int attachmentId = -1;
            try
            {
                //Set 10 minute timeout for big files
                using (TransactionScope ts = new TransactionScope(TransactionScopeOption.Required, new TimeSpan(0, 10, 0)))
                {
                    using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("ins_Attachment"))
                    {
                        sqlCmd.CommandTimeout = 300; // set max timeout to 5 mins
                         _dbToConnect.AddInParameter(sqlCmd, "@FormSectionId", DbType.Int32, attachmentObj.FormSectionId);
                        if (attachmentObj.AttachmentName != string.Empty)
                        {
                            _dbToConnect.AddInParameter(sqlCmd, "@AttachmentName", DbType.String, attachmentObj.AttachmentName);
                        }
                        else
                        {
                            _dbToConnect.AddInParameter(sqlCmd, "@AttachmentName", DbType.String, DBNull.Value);
                        }

                        if (!attachmentObj.AttachmentStream.Equals(Byte.MinValue))
                        {
                            _dbToConnect.AddInParameter(sqlCmd, "@Attachment", DbType.Binary, attachmentObj.AttachmentStream);
                        }
                        else
                        {
                            _dbToConnect.AddInParameter(sqlCmd, "@Attachment", DbType.Binary, DBNull.Value);
                        }
                        _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, formInstance);
                        _dbToConnect.AddInParameter(sqlCmd, "@Identifier", DbType.String, identifier);

                        if (stsId != -1)
                        {
                            _dbToConnect.AddInParameter(sqlCmd, "@StsId", DbType.Int32, stsId);
                        }
                        else
                        {
                            _dbToConnect.AddInParameter(sqlCmd, "@StsId", DbType.Int32, DBNull.Value);
                        }

                        using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                        {
                            if (resultSet != null && resultSet.Tables.Count > 0)
                            {
                                resultData = resultSet.Tables[0];
                            }
                        }

                        if ((int)resultData.Rows[0]["ErrorCode"] == 0)
                        {
                            if (Int32.TryParse(resultData.Rows[0]["ErrorMessage"].ToString(), out attachmentId))
                            {

                                // set the Chunk size - will update database after each chunk is uploaded
                                const int SQL_IMAGE_BUFFER_SIZE = (1024 * 1024); //1 Meg Buffer
                                byte[] buffer = new byte[SQL_IMAGE_BUFFER_SIZE];
                                int offset = 0;
                                int count = 0;

                                //The 0 in the read is the offset of the Buffer not the File, so grab from 0 as the file pointer moves through the stream
                                while ((count = fs.Read(buffer, 0, SQL_IMAGE_BUFFER_SIZE)) > 0)
                                {
                                    using (DbCommand sqlCmd2 = _dbToConnect.GetStoredProcCommand("ins_AttachmentChunk"))
                                    {
                                        _dbToConnect.AddInParameter(sqlCmd2, "@AttachmentId", DbType.Int32, attachmentId);
                                        if (count == SQL_IMAGE_BUFFER_SIZE)
                                        {
                                            _dbToConnect.AddInParameter(sqlCmd2, "@buffer", DbType.Binary, buffer);
                                        }
                                        else
                                        {
                                            //To prevent extra junk from being appended at the end of file, just create a buffer to the size of the last read
                                            byte[] smallbuffer = new byte[count];
                                            Buffer.BlockCopy(buffer, 0, smallbuffer, 0, count);
                                            _dbToConnect.AddInParameter(sqlCmd2, "@buffer", DbType.Binary, smallbuffer);
                                        }
                                        _dbToConnect.AddInParameter(sqlCmd2, "@offset", DbType.Int32, offset);
                                        _dbToConnect.AddInParameter(sqlCmd2, "@count", DbType.Int32, count);
                                        _dbToConnect.ExecuteNonQuery(sqlCmd2);
                                    }

                                    //bump the offset for the file being written to in the DB. Used to identify where to append the next chunk in the dtabase record.
                                    offset += count;
                                }
                            }
                        }
                        ts.Complete();
                    }
                }
            }
            catch
            {
                throw;
            }

            return resultData;
        }
        #endregion
     
        #region " DeleteAttachment "
        /** \public     DeleteAttachment
         *  \details    Delete Attachment 
         *  \param      AttachmentId
         *  \param      stsId
         *  \return     returns data table with outcome
        */
        public DataTable DeleteAttachment(int attachmentId)
        {
            DataTable resultData = null;
            try
            {
                DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("del_Attachment");

                _dbToConnect.AddInParameter(sqlCmd, "@AttachmentId", DbType.Int32, attachmentId);
                resultSet = _dbToConnect.ExecuteDataSet(sqlCmd);
                if (resultSet != null && resultSet.Tables.Count > 0)
                {
                    resultData = resultSet.Tables[0];
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw;
            }
            return resultData;
        }
        #endregion

        #region " GetAttachmentsByID "
        /** \public     GetAttachmentsByID
         *  \details    Get Attachment by AttachmentId
         *  \param      AttachmentId 
         *  \return     returns a data table values.
         */
        public DataTable GetAttachmentsByID(int AttachmentId)
        {
            try
            {
                DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_AttachmentsByID");
                sqlCmd.CommandTimeout = 300; // set max timeout to 5 mins

                _dbToConnect.AddInParameter(sqlCmd, "@AttachmentId", DbType.Int32, AttachmentId);
                resultSet = _dbToConnect.ExecuteDataSet(sqlCmd);
                if (resultSet != null && resultSet.Tables.Count > 0)
                {
                    resultData = resultSet.Tables[0];
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch
            {
                throw;
            }
            return resultData;
        }
        #endregion
        
        #region " GetAttachmentsByFormVendor "
        /** \public     GetAttachmentsByFormVendor
         *  \details    Get Attachment by formid and vendorid
         *  \param      FormId 
         *  \param      VendorId
         *  \return     returns a data table values.
         */
        public DataTable GetAttachmentsByFormVendor(int FormSectionId)
        {
            try
            {
                DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_AttachmentsByFormVendor");
                sqlCmd.CommandTimeout = 300; // set max timeout to 5 mins

                _dbToConnect.AddInParameter(sqlCmd, "@FormSectionId", DbType.Int32, FormSectionId);
                resultSet = _dbToConnect.ExecuteDataSet(sqlCmd);
                if (resultSet != null && resultSet.Tables.Count > 0)
                {
                    resultData = resultSet.Tables[0];
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch
            {
                throw;
            }
            return resultData;
        }
        #endregion

        #region " GetAttachmentsByFormVendorQuestion "
        /** \public     GetAttachmentsByFormVendorQuestion
         *  \details    Get Attachment by formid, vendorid and questionid
         *  \param      FormId 
         *  \param      VendorId
         *  \param      FormQuestionId
         *  \return     returns a data table values.
         */
        public DataTable GetAttachmentsByFormVendorQuestion(int FormId, int VendorId, int FormQuestionId)
        {
            try
            {
                DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_AttachmentsByFormVendorQuestion");
                sqlCmd.CommandTimeout = 300; // set max timeout to 5 mins

                _dbToConnect.AddInParameter(sqlCmd, "@FormId", DbType.Int32, FormId);
                _dbToConnect.AddInParameter(sqlCmd, "@VendorId", DbType.Int32, VendorId);
                _dbToConnect.AddInParameter(sqlCmd, "@FormQuestionId", DbType.Int32, FormQuestionId);
                resultSet = _dbToConnect.ExecuteDataSet(sqlCmd);
                if (resultSet != null && resultSet.Tables.Count > 0)
                {
                    resultData = resultSet.Tables[0];
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch
            {
                throw;
            }
            return resultData;
        }
        #endregion

        #region " LoadAttachments "
        /// <summary>
        /// LoadAttachments
        /// </summary>
        /// <param name="formSectionId"></param>
        /// <param name="formInstance"></param>
        /// <param name="identifier"></param>
        /// <returns></returns>
        public DataTable LoadAttachments(int formSectionId, string formInstance, int identifier)
        {
            DataTable result = null;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_Attachments"))
                {

                    _dbToConnect.AddInParameter(sqlCmd, "@formSectionId", DbType.Int32, formSectionId);
                    _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, formInstance);
                    _dbToConnect.AddInParameter(sqlCmd, "@identifier", DbType.Int32, identifier);
                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            result = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }
        #endregion
    }
}

