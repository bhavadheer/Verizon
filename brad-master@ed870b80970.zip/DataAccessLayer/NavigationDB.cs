﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Common;
using System.Collections.Specialized;
using Verizon.QueryStringEncryption;
using System.Configuration;

namespace DataAccessLayer
{
    public class NavigationDB : IDisposable
    {
        #region " Private Members "
        private bool disposed = false;
        private Database _dbToConnect = null;
        #endregion

        #region " Constructor "
        /// <summary>
        /// NavigationDB
        /// </summary>
        /// <param name="connectionString"></param>
        public NavigationDB(string connectionString)
        {
            _dbToConnect = new SqlDatabase(connectionString);
        }
        #endregion

        #region " Destructor "
        /// <summary>
        /// ~NavigationDB
        /// </summary>
        ~NavigationDB()
        {
            this.Dispose(false);
        }
        #endregion

        #region " Public Methods "

        #region " Dispose Methods "

        #region " Dispose "
        /// <summary>
        /// Dispose NavigationDB object
        /// </summary>
        public void Dispose()
        {
            //call dispose of any object used in this class
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

        #region " Dispose(bool disposing) "
        /// <summary>
        /// Dispose NavigationDB object.
        /// It cleans resources both managed and native
        /// </summary>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    //call dispose of any object used in this class
                }
            }

            disposed = true;
        }
        #endregion

        #endregion

        #region " GetUserCredentials "
        /// <summary>
        /// GetUserCredentials
        /// </summary>
        /// <param name="vzidOrEid"></param>
        /// <returns>DataTable</returns>
        public DataTable GetUserCredentials(string vzidOrEid)
        {
            DataTable resultData = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_UserCredentials"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@vzid", DbType.String, vzidOrEid);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            resultData = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultData;
        }
        #endregion

        #region " GetUserRoles "
        /// <summary>
        /// GetUserRoles
        /// </summary>
        /// <param name="userStsId"></param>
        /// <returns>List<RoleType></returns>
        public List<RoleType> GetUserRoles(int userStsId)
        {
            List<RoleType> rt = new List<RoleType>();
            //DataTable resultData = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_AllRoles"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@stsid", DbType.Int32, userStsId);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        using (DataTable resultData = resultSet.Tables[0])
                        {
                            int index = 0;
                            //resultData = resultSet.Tables[0];
                            foreach (DataRow dr in resultData.AsEnumerable())
                            {
                                rt.Add(EnumHelper.GetEnumTypeFromString<RoleType>(dr["RoleId"].ToString(), RoleType.NotSet));
                            }
                        }
                        //if (resultSet != null && resultSet.Tables.Count > 0)
                        //{
                        //    resultData = resultSet.Tables[0];
                        //}
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            //return resultData;

            //rt.Add(RoleType.BRTTeam);
            //rt.Add(RoleType.Administrator);

            return rt;
        }
        #endregion

        #region " GetUserAreas "
        /// <summary>
        /// GetUserAreas
        /// </summary>
        /// <param name="userStsId"></param>
        /// <param name="currentRole"></param>
        /// <returns>List<Location></returns>
        public List<Location> GetUserAreas(int userStsId, RoleType currentRole)
        {
            List<Location> locList = new List<Location>();

            for (int x = 1; x < 20; x++)
            {
                Location loc = new Location();
                loc.LocationId = x;
                loc.LocationCode = String.Format("LocationCode{0}", x);

                switch (x % 4)
                {
                    case 0:
                        loc.CountryCode = "Netherlands";
                        break;

                    case 1:
                        loc.CountryCode = "Belgium";
                        break;

                    case 2:
                        loc.CountryCode = "France";
                        break;

                    case 3:
                        loc.CountryCode = "England";
                        break;
                }

                if (currentRole.In(RoleType.Administrator))
                {
                    locList.Add(loc);
                }
                else
                {
                    if ((x % 3) == 0)
                    {
                        locList.Add(loc);
                    }
                }
            }

            return locList.OrderBy(m => m.CountryCode).ThenBy(n => n.LocationCode).ToList();
        }
        #endregion

        #region " GetMasterMenu "
        /// <summary>
        /// GetMasterMenu
        /// </summary>
        /// <param name="currentRole"></param>
        /// <param name="parentMenuId"></param>
        /// <returns>List<MenuData></returns>
        public List<MenuData> GetMasterMenu(int roleId)
        {
            List<MenuData> mnu = new List<MenuData>();

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_AllMainTabs"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@roleId", DbType.Int32, roleId);
                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            using (DataTable resultData = resultSet.Tables[0])
                            {
                                int index = 0;
                                //resultData = resultSet.Tables[0];
                                foreach (DataRow dr in resultData.AsEnumerable())
                                {
                                    string displayName = dr["DisplayName"].ToString();

                                    string id = dr["NavId"].ToString();
                                    string formId = dr["DisplayOrder"].ToString();
                                    NameValueCollection nvc_Querystring = new NameValueCollection();
                                    nvc_Querystring.Add("FormId", formId);
                                    string url = dr["NavigationURL"].ToString() + "?" + CryptoQueryStringHandler.EncryptQueryStrings(nvc_Querystring, ConfigurationManager.AppSettings["CryptoKey"]);
                                    mnu.Add(new MenuData()
                                    {
                                        DisplayName = displayName,
                                        MenuId = id,
                                        PageURL = url,
                                        CssClass = index == 0 ? "fa fa-sm fa-home" : "fa fa-sm fa-pencil-square-o"
                                    });
                                    index++;
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return mnu;
            //List<MenuData> mnu = new List<MenuData>();

            //switch (parentMenuId)
            //{
            //    //Root Menu
            //    case "":
            //        using (MenuData row = new MenuData())
            //        {
            //            row.MenuId = "mnu_0000";
            //            row.CssClass = "fa fa-lg fa-home";
            //            row.PageURL = "~/Home/Index.aspx";
            //            row.DisplayName = "Home";
            //            mnu.Add(row);
            //        }

            //        using (MenuData row = new MenuData())
            //        {
            //            row.MenuId = "mnu_0001";
            //            row.CssClass = "fa fa-eye";
            //            row.PageURL = "~/ICE/ICE_Mobile.aspx";
            //            row.DisplayName = "ICE";
            //            mnu.Add(row);
            //        }

            //        using (MenuData row = new MenuData())
            //        {
            //            row.MenuId = "mnu_0002";
            //            row.CssClass = "fa fa-book";
            //            row.PageURL = "~/ISS/ISS_Dashboard.aspx";
            //            row.DisplayName = "ISS";
            //            mnu.Add(row);
            //        }

            //        using (MenuData row = new MenuData())
            //        {
            //            row.MenuId = "mnu_0003";
            //            row.CssClass = "fa fa-bar-chart";
            //            row.PageURL = "~/Reports/Reports_Mobile.aspx";
            //            row.DisplayName = "Reports";
            //            mnu.Add(row);
            //        }

            //        if (currentRole.In(RoleType.Administrator))
            //        {
            //            using (MenuData row = new MenuData())
            //            {
            //                row.MenuId = "mnu_0004";
            //                row.CssClass = "fa fa-cogs";
            //                row.PageURL = "~/Administration/Admin_Mobile.aspx";
            //                row.DisplayName = "Administration";
            //                mnu.Add(row);
            //            }
            //        }
            //        break;

            //    case "mnu_0001":
            //        {
            //            using (MenuData row = new MenuData())
            //            {
            //                row.MenuId = "mnu_0001_0001";
            //                row.CssClass = string.Empty;
            //                row.PageURL = "~/Home/Index.aspx";
            //                row.DisplayName = "ICE Child 1";
            //                mnu.Add(row);
            //            }
            //        } break;
            //}

            //return mnu;
        }
        #endregion

        #region " GetUserCredentials "
        /// <summary>
        /// GetUserCredentials
        /// </summary>
        /// <param name="vzidOrEid"></param>
        /// <returns>int</returns>
        public int SaveUserAccessHistory(string loggedInId, string loggedInUserName, string action, int loggedInStsId, string ipAddress)
        {
            int isSaved = 0;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("ins_UserAccessHistory"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@loggedInId", DbType.String, loggedInId);
                    _dbToConnect.AddInParameter(sqlCmd, "@loggedInUserName", DbType.String, loggedInUserName);
                    _dbToConnect.AddInParameter(sqlCmd, "@Action", DbType.String, action);
                    _dbToConnect.AddInParameter(sqlCmd, "@loggedInStsId", DbType.Int32, loggedInStsId);
                    _dbToConnect.AddInParameter(sqlCmd, "@IPaddress", DbType.String, ipAddress);
                    isSaved = _dbToConnect.ExecuteNonQuery(sqlCmd);
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isSaved;
        }
        #endregion

        public List<Announcement> GetAnnouncments(int userStsid)
        {
            List<Announcement> annList = new List<Announcement>();

            using (Announcement ann = new Announcement())
            {
                ann.AnnouncementId = "ann_0001";
                ann.Title = "New STS Bootstrap Framework available";
                ann.Acknowledged = false;
                ann.Description = "The new framework is available to use in new projects";

                annList.Add(ann);
            }

            return annList;
        }

        #endregion
    }
}
