﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Data.Common;

namespace DataAccessLayer
{
    public class SectionDB : BaseClass
    {
        #region " Private Members "
        private bool disposed = false;
        Database _dbToConnect = null;
        #endregion

        #region " Constructor "
        /** \public  ReferenceManagerDB 
         *  \details    Constructor to initilize the database object
         *  \param ConnectionString
         */
        public SectionDB(string connectionstring)
        {
            _dbToConnect = new SqlDatabase(connectionstring);
        }
        #endregion

        #region " Dispose Methods "
        protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            if (disposing)
            {

            }
            disposed = true;
            base.Dispose(disposing);
        }
        #endregion

        #region " GetSectionsByForm "
        public DataTable GetSections()
        {
            var sectionList = new DataTable();
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_Sections"))
                {
                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            sectionList = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }

            return sectionList;
        }
        #endregion

        #region " UpdateSections "
        public void UpdateSections(int sectionId, string sectionName, string sectionDesc, int stsId)
        {
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("upd_Sections"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@sectionID", DbType.Int32, sectionId);
                    _dbToConnect.AddInParameter(sqlCmd, "@sectionName", DbType.String, sectionName);
                    _dbToConnect.AddInParameter(sqlCmd, "@sectionDesc", DbType.String, sectionDesc);
                    _dbToConnect.AddInParameter(sqlCmd, "@stsId", DbType.Int32, stsId);

                    _dbToConnect.ExecuteNonQuery(sqlCmd);

                }
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }
        }
        #endregion

        #region " UpdateSections "
        public void UpdateSectionOrder(string sectionOrderInfo, int stsId)
        {
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("upd_SectionOrder"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@sectionOrderInfo", DbType.String, sectionOrderInfo);
                    _dbToConnect.AddInParameter(sqlCmd, "@stsId", DbType.Int32, stsId);

                    _dbToConnect.ExecuteNonQuery(sqlCmd);

                }
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }
        }
        #endregion

        #region " UpdateFormSections "
        public void UpdateFormSections(int formSectionId,int newSectionId, int stsId)
        {
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("upd_FormSection"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formSectionId", DbType.Int32, formSectionId);
                    _dbToConnect.AddInParameter(sqlCmd, "@newSectionID", DbType.Int32, newSectionId);
                    _dbToConnect.AddInParameter(sqlCmd, "@stsId", DbType.Int32, stsId);

                    _dbToConnect.ExecuteNonQuery(sqlCmd);

                }
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }
        }
        #endregion

        #region " UpdateSectionQuestionOrder "
        public void UpdateSectionQuestionOrder(string sectionQuesOrderInfo, int stsId)
        {
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("upd_SectionQuestionOrder"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@sectionQuesOrderInfo", DbType.String, sectionQuesOrderInfo);
                    _dbToConnect.AddInParameter(sqlCmd, "@stsId", DbType.Int32, stsId);

                    _dbToConnect.ExecuteNonQuery(sqlCmd);

                }
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }
        }
        #endregion


    }
}
