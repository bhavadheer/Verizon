﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Data.Common;

namespace DataAccessLayer
{
    public class ChangeRoleDB : BaseClass
    {
        /*! \class      ChangeRoleDB
        *  \implements  IDisposable
        *  \brief      Change the Role
        *  \section    First Draft
        *  \author     Shrutesh Vadiyala
        *  \date       6/22/2012
        *  \details    Change the Roles.
        *  \subsection Second Revision
        *  \author     
        *  \date      
        *  \details   
        */
        #region Private Members
        private bool disposed = false;
        Database _dbToConnect = null;
        #endregion

        #region " Constructor "
        /** \public  ChangeRoleDB 
         *  \details    Constructor to initilize the database object
         *  \param ConnectionString
         */
        public ChangeRoleDB(string connectionstring)
        {
            _dbToConnect = new SqlDatabase(connectionstring);
        }
        #endregion

        #region " Dispose Methods "
        protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            if (disposing)
            {

            }
            disposed = true;
            base.Dispose(disposing);
        }
        #endregion

        #region " GetRolesByRoleID "
        /** \public     GetRolesByRoleID
         *  \section    First Draft
         *  \author     Vijender Reddy Chintalapudi
         *  \date       09/19/2012
         *  \details    Get roles depending on roleID
         *  \param      roleID
         */
        public DataTable GetRolesByRoleID(String roleId)
        {
            DataTable resultData = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qryGetSelectedRole"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@roleId", DbType.String, roleId);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            resultData = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultData;
        }

        #endregion

        #region " GetAllRoles "
        /** \public     GetAllRoles
         *  \section    First Draft
         *  \author     Shrutesh Vadiyala
         *  \date       6/22/2012
         *  \details    Get All the roles.
         *  \param      stsid int
         */
        public DataTable GetAllRoles(int stsid)
        {
            DataTable resultData = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_AllRoles"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@stsid", DbType.Int32, stsid);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            resultData = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultData;
        }

        #endregion

        #region " GetUserRole "
        /** \public     GetUserRole
         *  \section    First Draft
         *  \author     Shrutesh Vadiyala
         *  \date       6/22/2012
         *  \details    Get the User roles.  
         *  \param      stsid
         *  \param      role
         */
        public DataTable GetUserRole(int stsid, String role)
        {
            DataTable resultData = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_ChangeCurrentRole"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@stsid", DbType.Int32, stsid);
                    _dbToConnect.AddInParameter(sqlCmd, "@role", DbType.String, role);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            resultData = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultData;
        }

        #endregion
    }
}
