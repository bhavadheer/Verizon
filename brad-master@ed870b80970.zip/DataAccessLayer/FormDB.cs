﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Data.Common;
namespace DataAccessLayer
{
    public class FormDB : BaseClass
    {
        #region " Private Members "
        private bool disposed = false;
        Database _dbToConnect = null;
        #endregion

        #region " Constructor "
        /** \public  ReferenceManagerDB 
         *  \details    Constructor to initilize the database object
         *  \param ConnectionString
         */
        public FormDB(string connectionstring)
        {
            _dbToConnect = new SqlDatabase(connectionstring);
        }
        #endregion

        #region " Dispose Methods "
        protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            if (disposing)
            {

            }
            disposed = true;
            base.Dispose(disposing);
        }
        #endregion

        #region " GetSectionsByForm "
        public List<FormSection> GetSectionsByForm(int formId, int roleId, int privilegeId)
        {
            var sectionList = new List<FormSection>();
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_FormSections"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formId", DbType.Int32, formId);
                    _dbToConnect.AddInParameter(sqlCmd, "@roleId", DbType.Int32, roleId);
                    _dbToConnect.AddInParameter(sqlCmd, "@privilegeId", DbType.Int32, privilegeId);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            using (DataTable resultData = resultSet.Tables[0])
                            {
                                foreach (DataRow dr in resultData.AsEnumerable())
                                {
                                    var _formid = Convert.ToInt32(dr["formId"]);
                                    var _formDescription = dr["FormDescription"].ToString();
                                    var _sectionId = Convert.ToInt16(dr["SectionId"]);
                                    var _sectionDescription = dr["SectionDescription"].ToString();
                                    sectionList.Add(new FormSection()
                                    {
                                        FormId = _formid,
                                        FormName = _formDescription,
                                        SectionId = _sectionId,
                                        SectionDescription = _sectionDescription,
                                    });
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }

            return sectionList;
        }
        #endregion

        #region " GetDynamicFields "
        /// <summary>
        /// GetDynamicFields
        /// </summary>
        /// <param name="formId"></param>
        /// <param name="sectionId"></param>
        /// <param name="currentRole"></param>
        /// <param name="formInstance"></param>
        /// <returns></returns>
        public List<DynamicField> GetDynamicFields(int formId, int sectionId, int currentRole, string formInstance)
        {
            var dynamicFields = new List<DynamicField>();

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_DynamicFields"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formId", DbType.Int32, formId);
                    _dbToConnect.AddInParameter(sqlCmd, "@sectionId", DbType.Int32, sectionId);
                    _dbToConnect.AddInParameter(sqlCmd, "@RoleId", DbType.Int32, currentRole);
                    _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, formInstance);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            using (DataTable resultData = resultSet.Tables[0])
                            {
                                foreach (DataRow dr in resultData.AsEnumerable())
                                {
                                    var _questionNumber = Convert.ToInt32(dr["QuestionNumber"]);
                                    var _id = dr["id"].ToString();
                                    var _fieldName = dr["FieldName"].ToString();
                                    var _fieldData = dr["FieldData"];
                                    var _text = dr["Question"].ToString();
                                    var _ctype = DynamicField.GetDynEnumTypeFromString<DynControlType>(dr["ControlType"].ToString(), DynControlType.Notset);
                                    var _btn = DynamicField.GetDynEnumTypeFromString<DynButtonType>(dr["ButtonType"].ToString(), DynButtonType.Notset);
                                    var _chk = DynamicField.GetDynEnumTypeFromString<DynCheckBoxType>(dr["CheckBoxType"].ToString(), DynCheckBoxType.Notset);
                                    //DynDropDownType _drp = DynamicField.GetDynEnumTypeFromString<DynDropDownType>(dr["DropDownType"].ToString(), DynDropDownType.Notset);
                                    var dropDownCategory = dr["DropDownIdentifier"].ToString();
                                    var _rbt = DynamicField.GetDynEnumTypeFromString<DynRadioButtonType>(dr["RadioButtonType"].ToString(), DynRadioButtonType.Notset);
                                    var _questionRoles = dr["RoleID"].ToString();
                                    var isRequired = dr["IsRequired"].ToString() == "1" ? true : false;
                                    using (var dynamicField1 = new DynamicField()
                                    {
                                        Id = _id,
                                        Form = formId,
                                        Sec = sectionId,
                                        QuestionNumber = _questionNumber,
                                        FieldName = _fieldName,
                                        FieldData = _fieldData,
                                        Text = _text,
                                        CtrlType = _ctype,
                                        BtnType = _btn,
                                        CbType = _chk,
                                        DdType = dropDownCategory,
                                        RbType = _rbt,
                                        IsReadonly = _questionRoles.Contains(currentRole.ToString()),
                                        IsRequired = isRequired
                                    })
                                    {
                                        dynamicFields.Add(dynamicField1);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw new Exception("DB Layer Exception", sqlException);
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }

            return dynamicFields;
        }
        #endregion

        #region " SaveAnswers "
        /// <summary>
        /// SaveAnswers
        /// </summary>
        /// <param name="formSectionId"></param>
        /// <param name="formInstance"></param>
        /// <param name="answerText"></param>
        /// <param name="loggedInStsId"></param>
        public void SaveAnswers(int formSectionId, string formInstance, string answerText, int loggedInStsId)
        {
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("ins_FormResponse"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formSectionId", DbType.Int32, formSectionId);
                    _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, formInstance);
                    _dbToConnect.AddInParameter(sqlCmd, "@answerText", DbType.String, answerText);
                    _dbToConnect.AddInParameter(sqlCmd, "@stsId", DbType.Int32, loggedInStsId);

                    _dbToConnect.ExecuteNonQuery(sqlCmd);
                }
            }
            catch (SqlException sqlException)
            {
                throw new Exception("DB Layer Exception", sqlException);
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }
        }
        #endregion

        #region " GetNextFormInstance "
        /// <summary>
        /// GetNextFormInstance
        /// </summary>
        /// <param name="formId"></param>
        /// <returns></returns>
        public string GetNextFormInstance(int formId)
        {
            var instance = string.Empty;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_NextFormInstance"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formId", DbType.Int32, formId);
                    _dbToConnect.AddOutParameter(sqlCmd, "@nextFormInstance", DbType.String, 50);

                    _dbToConnect.ExecuteNonQuery(sqlCmd);

                    instance = Convert.ToString(_dbToConnect.GetParameterValue(sqlCmd, "@nextFormInstance"));

                }
            }
            catch (SqlException sqlException)
            {
                throw new Exception("DB Layer Exception", sqlException);
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }

            return instance;
        }
        #endregion

        #region " GetFormInstances "
        /// <summary>
        /// GetFormInstances
        /// </summary>
        /// <param name="formId"></param>
        /// <returns></returns>
        public DataTable GetFormInstances(int formId)
        {
            DataTable _dt = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_FormInstance"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formId", DbType.Int32, formId);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw new Exception("DB Layer Exception", sqlException);
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }

            return _dt;
        }
        #endregion

        #region " GetAuditHistory "
        /// <summary>
        /// GetAuditHistory
        /// </summary>
        /// <param name="formInstance"></param>
        /// <returns></returns>
        public DataTable GetAuditHistory(string formInstance)
        {
            DataTable _dt = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_AuditHistory"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, formInstance);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw new Exception("DB Layer Exception", sqlException);
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }

            return _dt;
        }
        #endregion

        #region " GetBRTLock "
        /// <summary>
        /// GetBRTLock
        /// </summary>
        /// <param name="formInstance"></param>
        /// <param name="StsId"></param>
        /// <returns></returns>
        public DataTable GetBRTLock(string formInstance, int StsId)
        {
            DataTable _dt = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_GetBRTLock"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@FormInstance", DbType.String, formInstance);
                    _dbToConnect.AddInParameter(sqlCmd, "@StsId", DbType.Int32, StsId);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw new Exception("DB Layer Exception", sqlException);
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }

            return _dt;
        }
        #endregion

        #region " InsertBRTLock "
        /// <summary>
        /// InsertBRTLock
        /// </summary>
        /// <param name="formInstance"></param>
        /// <param name="stsId"></param>
        /// <returns></returns>
        public DataTable InsertBRTLock(string formInstance, int stsId)
        {
            DataTable _dt = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("ins_BRTLock"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@FormInstance", DbType.String, formInstance);
                    _dbToConnect.AddInParameter(sqlCmd, "@StsId", DbType.Int32, stsId);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw new Exception("DB Layer Exception", sqlException);
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }

            return _dt;
        }
        #endregion

        #region " DeleteBRTLock "
        /// <summary>
        /// DeleteBRTLock
        /// </summary>
        /// <param name="FormInstance"></param>
        /// <param name="StsId"></param>
        /// <returns></returns>
        public DataTable DeleteBRTLock(string FormInstance, int StsId)
        {
            DataTable _dt = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("del_BRTLock"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, FormInstance);
                    _dbToConnect.AddInParameter(sqlCmd, "@stsId", DbType.Int32, StsId);
                    _dbToConnect.ExecuteNonQuery(sqlCmd);
                }
            }
            catch (SqlException sqlException)
            {
                throw new Exception("DB Layer Exception", sqlException);
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }

            return _dt;
        }
        #endregion

        #region " InsertAdditionalQuestion "
        /// <summary>
        /// InsertAdditionalQuestion
        /// </summary>
        /// <param name="questionText"></param>
        /// <param name="responseText"></param>
        /// <param name="formId"></param>
        /// <param name="sectionId"></param>
        /// <param name="formInstance"></param>
        /// <param name="stsid"></param>
        /// <returns>Int32</returns>
        public Int32 InsertAdditionalQuestion(string questionText, string responseText, int formId, int sectionId, string formInstance, int stsid)
        {
            var questionId = 0;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("ins_AdditionalQuestions"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@questionText", DbType.String, questionText);
                    _dbToConnect.AddInParameter(sqlCmd, "@responseText", DbType.String, responseText);
                    _dbToConnect.AddInParameter(sqlCmd, "@formId", DbType.Int32, formId);
                    _dbToConnect.AddInParameter(sqlCmd, "@sectionId", DbType.Int32, sectionId);
                    _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, formInstance);
                    _dbToConnect.AddInParameter(sqlCmd, "@stsId", DbType.Int32, stsid);

                    _dbToConnect.AddOutParameter(sqlCmd, "@questionId", DbType.String, 20);

                    _dbToConnect.ExecuteNonQuery(sqlCmd);

                    questionId = Convert.ToInt32(_dbToConnect.GetParameterValue(sqlCmd, "@questionId"));

                }
            }
            catch (SqlException sqlException)
            {
                throw new Exception("DB Layer Exception", sqlException);
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }

            return questionId;
        }
        #endregion

        #region 'SaveFormInstanceType'

        public void SaveFormInstanceType(string FormInstance, int FormInstanceType, bool AllowOverride, int LoggedInStsId)
        {
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("upd_FormInstanceType"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, FormInstance);
                    _dbToConnect.AddInParameter(sqlCmd, "@formInstanceType", DbType.Int32, FormInstanceType);
                    _dbToConnect.AddInParameter(sqlCmd, "@allowOverride", DbType.Boolean, AllowOverride);
                    _dbToConnect.AddInParameter(sqlCmd, "@stsId", DbType.Int32, LoggedInStsId);
                    _dbToConnect.ExecuteNonQuery(sqlCmd);
                }
            }
            catch (SqlException sqlException)
            {
                throw new Exception("DB Layer Exception", sqlException);
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }
        }
        #endregion

        #region " GetFormsSearchAudit "
        /** \public     GetFormsSearchAudit 
         *  \author     Bharath Bellam
         *  \date       03/02/2016
         *  \details    Used qry_FormsSearch and Based on Search Criteria it pulls all results from Database.
         *  \param      FormName int
         *  \param      FormSection int
         *  \param      FormQuestions string
         *  \param      Creator string
         *  \param      DateFromCreated DateTime
         *  \param      DateToCreated DateTime
         *  \param      vzid string
         *  \param      connStr string
         *  \return     A Datatable.
         */
        public DataTable GetFormsSearchAudit(int FormName, string FormInstance, int FormSection, string FormQuestions, int CreatorStsId, DateTime DateFromCreated,
                                            DateTime DateToCreated, int isImport)
        {
            DataTable _dt = null;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_FormsSearchAudit"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formId", DbType.Int32, FormName);
                    _dbToConnect.AddInParameter(sqlCmd, "@formSectionId", DbType.Int32, FormSection);
                    _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, FormInstance);
                    _dbToConnect.AddInParameter(sqlCmd, "@formQuestions", DbType.String, FormQuestions);
                    _dbToConnect.AddInParameter(sqlCmd, "@creatorStsId", DbType.Int32, CreatorStsId);
                    _dbToConnect.AddInParameter(sqlCmd, "@dateFromCreated", DbType.DateTime, DateFromCreated);
                    _dbToConnect.AddInParameter(sqlCmd, "@dateToCreated", DbType.DateTime, DateToCreated);
                    _dbToConnect.AddInParameter(sqlCmd, "@isImport", DbType.Int32, isImport);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return _dt;

        }
        #endregion

        #region " GetBRTLock "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formInstance"></param>
        /// <param name="formId"></param>
        /// <param name="sectionId"></param>
        /// <returns></returns>
        public DataTable GetValidationResponse(string formInstance, int formId, int sectionId)
        {
            DataTable _dt = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_FormQuestionValidation"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@FormInstance", DbType.String, formInstance);
                    _dbToConnect.AddInParameter(sqlCmd, "@formId", DbType.Int32, formId);
                    _dbToConnect.AddInParameter(sqlCmd, "@sectionId", DbType.Int32, sectionId);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw new Exception("DB Layer Exception", sqlException);
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }

            return _dt;
        }
        #endregion

        #region " UpdateFormReportStatus "
        /// <summary>
        /// SaveAnswers
        /// </summary>
        /// <param name="formid"></param>
        /// <param name="sectionId"></param>
        /// <param name="formInstance"></param>
        /// <param name="loggedInStsId"></param>
        public void UpdateFormReportStatus(int formid, int sectionId, string formInstance, int loggedInStsId)
        {
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("upd_FormReportStatus"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formID", DbType.Int32, formid);
                    _dbToConnect.AddInParameter(sqlCmd, "@sectionID", DbType.Int32, sectionId);
                    _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, formInstance);
                    _dbToConnect.AddInParameter(sqlCmd, "@stsId", DbType.Int32, loggedInStsId);
                    _dbToConnect.ExecuteNonQuery(sqlCmd);
                }
            }
            catch (SqlException sqlException)
            {
                throw new Exception("DB Layer Exception", sqlException);
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }
        }
        #endregion

        #region " GetLinkedForms "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="masterFormInstance"></param>
        /// <returns></returns>
        public List<LinkedForms> GetLinkedForms(string masterFormInstance)
        {
            var sectionList = new List<LinkedForms>();
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_GetLinkedForms"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@masterFormInstance", DbType.String, masterFormInstance);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            using (DataTable resultData = resultSet.Tables[0])
                            {
                                foreach (DataRow dr in resultData.AsEnumerable())
                                {
                                    var lnkForm = new LinkedForms
                                    {
                                        FormInstance = dr["FormInstance"].ToString(),
                                        LegalName = dr["LegalName"].ToString(),
                                        LinkText = dr["LinkText"].ToString()
                                    };
                                    sectionList.Add(lnkForm);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }

            return sectionList;
        }
        #endregion

        #region " GetBRTAnalysts "
        /// <summary>
        /// GetBRTAnalysts
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable GetBRTAnalysts()
        {
            DataTable resultData = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_GetBRTAnalysts"))
                {

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            resultData = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultData;
        }
        #endregion

        #region " GetBRTAnalystInfo "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="logonId"></param>
        /// <returns></returns>
        public DataTable GetBRTAnalystInfo(string logonId)
        {
            DataTable resultData = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_GetBRTAnalystInfo"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@logonId", DbType.String, logonId);
                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            resultData = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultData;
        }
        #endregion

        #region " CheckDropDownDependency "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formSectionId"></param>
        /// <returns></returns>
        public DataTable CheckDropDownDependency(int formSectionId)
        {
            DataTable resultData = null;

            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_CheckDropDownDependency"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formSectionId", DbType.Int32, formSectionId);
                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            resultData = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return resultData;
        }
        #endregion

        #region " GetFormCompanyName "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formInstance"></param>
        /// <returns></returns>
        public List<LinkedForms> GetFormCompanyName(string formInstance)
        {
            var sectionList = new List<LinkedForms>();
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_GetFormCompanyName"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, formInstance);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            using (DataTable resultData = resultSet.Tables[0])
                            {
                                foreach (DataRow dr in resultData.AsEnumerable())
                                {
                                    var lnkForm = new LinkedForms
                                    {
                                        FormInstance = dr["FormInstance"].ToString(),
                                        LegalName = dr["LegalName"].ToString(),
                                        LinkText = dr["LinkText"].ToString()
                                    };
                                    sectionList.Add(lnkForm);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }

            return sectionList;
        }
        #endregion

        #region " GetUserFormPartial "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formId"></param>
        /// <returns></returns>
        public List<UserFormPartial> GetUserFormPartial(int formId)
        {
            var questionList = new List<UserFormPartial>();
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_UserFormPartial"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formId", DbType.Int32, formId);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            using (DataTable resultData = resultSet.Tables[0])
                            {
                                foreach (DataRow dr in resultData.AsEnumerable())
                                {
                                    var lnkForm = new UserFormPartial
                                    {
                                        FormId = Convert.ToInt32(dr["FormId"]),
                                        FormQuestionId = Convert.ToInt32(dr["FormQuestionID"]),
                                        SectionId = Convert.ToInt32(dr["SectionID"]),
                                        FormSectionId = Convert.ToInt32(dr["FormSectionID"]),
                                        QuestionText = dr["QuestionText"].ToString(),
                                        DropdownIdentifier = dr["DropDownIdentifier"].ToString(),
                                        AnsCtrlType = dr["AnsCtrlType"].ToString(),
                                        DDOptions = dr["DDOptions"].ToString(),
                                        IsRequired = Convert.ToBoolean(dr["IsRequired"])
                                    };
                                    questionList.Add(lnkForm);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }

            return questionList;
        }
        #endregion

        #region 'InsertUserPartialForm'
        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputData"></param>
        /// <param name="formId"></param>
        /// <param name="LoggedInStsId"></param>
        /// <returns></returns>
        public string InsertUserPartialForm(string inputData, int formId, int LoggedInStsId)
        {
            var newFormInstance = string.Empty;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("ins_UserPartialForm"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@inputData", DbType.String, inputData);
                    _dbToConnect.AddInParameter(sqlCmd, "@FormId", DbType.Int32, formId);
                    _dbToConnect.AddInParameter(sqlCmd, "@stsId", DbType.Int32, LoggedInStsId);
                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            newFormInstance = resultSet.Tables[0].Rows[0]["Column1"].ToString();
                        }
                    }
                }
            }
            catch (SqlException sqlException)
            {
                throw new Exception("DB Layer Exception", sqlException);
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }
            return newFormInstance;
        }
        #endregion

        #region 'InsertAuditViewPrint'
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formInstance"></param>
        /// <param name="LoggedInStsId"></param>
        /// <param name="loggedinUser"></param>
        /// <param name="eventType"></param>
        /// <returns></returns>
        public void InsertAuditViewPrint(string formInstance, int LoggedInStsId, string loggedinUser, string eventType)
        {
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("ins_AuditViewPrint"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@FormInstance", DbType.String, formInstance);
                    _dbToConnect.AddInParameter(sqlCmd, "@loggedInStsId", DbType.Int32, LoggedInStsId);
                    _dbToConnect.AddInParameter(sqlCmd, "@loggedInUser", DbType.String, loggedinUser);
                    _dbToConnect.AddInParameter(sqlCmd, "@EventType", DbType.String, eventType);
                    _dbToConnect.ExecuteNonQuery(sqlCmd);
                }
            }
            catch (SqlException sqlException)
            {
                throw new Exception("DB Layer Exception", sqlException);
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }
        }
        #endregion

        #region " GetAuditViewPrint "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formInstance"></param>
        /// <returns></returns>
        public DataTable GetAuditViewPrint(string formInstance)
        {
            var questionList = new DataTable();
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_AuditViewPrint"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, formInstance);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            using (DataTable resultData = resultSet.Tables[0])
                            {
                                questionList = resultData;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }

            return questionList;
        }
        #endregion

        #region " GetAuditViewPrintExport "
        /// <summary>
        /// 
        /// </summary>
        /// <param name="DateFromCreated"></param>
        /// <param name="DateToCreated"></param>
        /// <returns></returns>
        public DataTable GetAuditViewPrintExport(DateTime DateFromCreated, DateTime DateToCreated)
        {
            var questionList = new DataTable();
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_AuditViewPrintExport"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@dateFromCreated", DbType.DateTime, DateFromCreated);
                    _dbToConnect.AddInParameter(sqlCmd, "@dateToCreated", DbType.DateTime, DateToCreated);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            using (DataTable resultData = resultSet.Tables[0])
                            {
                                questionList = resultData;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }

            return questionList;
        }
        #endregion

        #region " UpdateFormReviewStatus "
        /// <summary>
        /// SaveAnswers
        /// </summary>
        /// <param name="formid"></param>
        /// <param name="sectionId"></param>
        /// <param name="formInstance"></param>
        /// <param name="loggedInStsId"></param>
        public void UpdateFormReviewStatus(int formid, int sectionId, string formInstance, int loggedInStsId)
        {
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("upd_FormReviewStatus"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formID", DbType.Int32, formid);
                    _dbToConnect.AddInParameter(sqlCmd, "@sectionID", DbType.Int32, sectionId);
                    _dbToConnect.AddInParameter(sqlCmd, "@formInstance", DbType.String, formInstance);
                    _dbToConnect.AddInParameter(sqlCmd, "@stsId", DbType.Int32, loggedInStsId);
                    _dbToConnect.ExecuteNonQuery(sqlCmd);
                }
            }
            catch (SqlException sqlException)
            {
                throw new Exception("DB Layer Exception", sqlException);
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }
        }
        #endregion

        #region " GetFormSectionIdByQuestion "
        public int GetFormSectionIdByQuestion(int formId, int sectionId, int formquestionId)
        {
            var formSectionId = 0;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_FormSectionByQuestionandSection"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formId", DbType.Int32, formId);
                    _dbToConnect.AddInParameter(sqlCmd, "@sectionId", DbType.Int32, sectionId);
                    _dbToConnect.AddInParameter(sqlCmd, "@formquestionID", DbType.Int32, formquestionId);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            using (DataTable resultData = resultSet.Tables[0])
                            {
                                if (resultData.Rows.Count > 0)
                                {
                                    formSectionId = Convert.ToInt32(resultData.Rows[0]["FormSectionID"]);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("DB Layer Exception", ex);
            }

            return formSectionId;
        }
        #endregion
    }
}
