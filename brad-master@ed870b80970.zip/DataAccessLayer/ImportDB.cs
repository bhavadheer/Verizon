﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Common;

namespace DataAccessLayer
{
    public class ImportDB : BaseClass
    {
        #region " Private Members "
        private bool disposed = false;
        Database _dbToConnect = null;
        #endregion

        #region " Constructor "
        /** \public  ImportDB 
         *  \details    Constructor to initilize the database object
         *  \param ConnectionString
         */
        public ImportDB(string connectionstring)
        {
            _dbToConnect = new SqlDatabase(connectionstring);
        }
        #endregion

        #region " Dispose Methods "
        protected override void Dispose(bool disposing)
        {
            if (disposed)
                return;
            if (disposing)
            {

            }
            disposed = true;
            base.Dispose(disposing);
        }
        #endregion

        #region " Public Methods "

        #region " GetFormInfo "
        /** \public     GetFormInfo 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/11/2016
         *  \details    Used qry_GetFormInformation to return form information based on formId and roleId
         *  \param      formId int
         *  \param      roleId int
         *  \returns    DataTable
         */
        public DataTable GetFormInfo(int formId, int roleId)
        {
            DataTable _dt = null;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_GetFormInformation"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formId", DbType.Int32, formId);
                    _dbToConnect.AddInParameter(sqlCmd, "@roleId", DbType.Int32, roleId);

                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return _dt;

        }
        #endregion

        #region " InsertFormImportQuestionBank "
        /** \public     InsertFormImportQuestionBank 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/14/2016
         *  \details    This method uses ins_FormImportQuestionBank to insert uploaded Excel records into FormResponse.
         *  \param      formId int
         *  \param      roleId int
         *  \param      stsId int
         *  \return     
         */
        public void InsertFormImportQuestionBank(int formId, int roleId, int stsId)
        {
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("ins_FormImportQuestionBank"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@formId", DbType.Int32, formId);
                    _dbToConnect.AddInParameter(sqlCmd, "@roleid", DbType.String, roleId);
                    _dbToConnect.AddInParameter(sqlCmd, "@stsid", DbType.Int32, stsId);

                    _dbToConnect.ExecuteNonQuery(sqlCmd);
                }
            }
            catch (SqlException sqlException)
            {
                throw sqlException;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        #endregion

        #region " ValidateFormImport "
        /** \public     ValidateFormImport 
         *  \section    First Draft
         *  \author     Bharath Bellam
         *  \date       03/22/2016
         *  \details    Used qry_ValidateFormImportQuestionBank to validate the form import
         *  \returns    DataTable
         */
        public DataTable ValidateFormImport(int stsid)
        {
            DataTable _dt = null;
            try
            {
                using (DbCommand sqlCmd = _dbToConnect.GetStoredProcCommand("qry_ValidateFormImportQuestionBank"))
                {
                    _dbToConnect.AddInParameter(sqlCmd, "@stsId", DbType.Int32, stsid);
                    using (DataSet resultSet = _dbToConnect.ExecuteDataSet(sqlCmd))
                    {
                        if (resultSet != null && resultSet.Tables.Count > 0)
                        {
                            _dt = resultSet.Tables[0];
                        }
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return _dt;

        }
        #endregion

        #endregion
    }
}
